"""
services/db_init.py — Automatic Oracle DDL on startup

Called from main.py lifespan. Creates all 5 tables IF they don't exist.
Completely idempotent — safe to run on every startup.

Uses oracledb from prath env (3.4.0).
"""
import logging
from backend.config import check_oracle, ORACLE_USER, ORACLE_PASSWORD, ORACLE_DSN

log = logging.getLogger("db_init")

# ── DDL statements (CREATE IF NOT EXISTS via PL/SQL) ──────────────────

_TABLES = {
    "BI_CHAT_SESSION": """
        CREATE TABLE BI_CHAT_SESSION (
            SESSION_ID       VARCHAR2(64)    NOT NULL,
            USER_ID          VARCHAR2(50)    NOT NULL,
            SCORECARD_ID     VARCHAR2(100)   NOT NULL,
            SCORECARD_NAME   VARCHAR2(200),
            LEGAL_ENTITY     VARCHAR2(20),
            REGION           VARCHAR2(20),
            DASHBOARD_TYPE   VARCHAR2(50),
            CREATED_DT       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
            LAST_ACTIVE_DT   TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
            MESSAGE_COUNT    NUMBER(6,0)     DEFAULT 0 NOT NULL,
            STATUS           VARCHAR2(20)    DEFAULT 'ACTIVE' NOT NULL,
            CONSTRAINT PK_BI_CHAT_SESSION PRIMARY KEY (SESSION_ID)
        )
    """,
    "BI_CHAT_HISTORY": """
        CREATE TABLE BI_CHAT_HISTORY (
            ID               NUMBER          GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            SESSION_ID       VARCHAR2(64)    NOT NULL,
            USER_ID          VARCHAR2(50)    NOT NULL,
            SCORECARD_ID     VARCHAR2(100)   NOT NULL,
            ROLE             VARCHAR2(20)    NOT NULL,
            CONTENT          CLOB            NOT NULL,
            CHART_TYPE       VARCHAR2(30),
            MODEL_VERSION    VARCHAR2(100),
            QUERY_METHOD     VARCHAR2(20),
            INPUT_TOKENS     NUMBER(8,0),
            OUTPUT_TOKENS    NUMBER(8,0),
            RESPONSE_TIME_MS NUMBER(8,0),
            CONFIDENCE       NUMBER(4,3),
            CREATED_DT       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL
        )
    """,
    "BI_API_AUDIT": """
        CREATE TABLE BI_API_AUDIT (
            ID               NUMBER          GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            ENDPOINT         VARCHAR2(200)   NOT NULL,
            HTTP_METHOD      VARCHAR2(10)    NOT NULL,
            USER_ID          VARCHAR2(50),
            SCORECARD_ID     VARCHAR2(100),
            STATUS_CODE      NUMBER(3,0),
            RESPONSE_TIME_MS NUMBER(8,0),
            ERROR_MESSAGE    CLOB,
            CLIENT_IP        VARCHAR2(50),
            CREATED_DT       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL
        )
    """,
    "BI_SNAPSHOT_LOG": """
        CREATE TABLE BI_SNAPSHOT_LOG (
            ID               NUMBER          GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            VIEW_ID          VARCHAR2(100)   NOT NULL,
            SCORECARD_ID     VARCHAR2(100),
            USER_ID          VARCHAR2(50),
            FETCH_TYPE       VARCHAR2(10),
            SUCCESS          NUMBER(1)       DEFAULT 1,
            ERROR_MESSAGE    CLOB,
            BYTES_RETURNED   NUMBER(12,0),
            RESPONSE_TIME_MS NUMBER(8,0),
            CREATED_DT       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL
        )
    """,
    "BI_DATA_CONTEXT": """
        CREATE TABLE BI_DATA_CONTEXT (
            SOURCE_ID        VARCHAR2(100)   NOT NULL,
            CHUNK_ID         VARCHAR2(100)   NOT NULL,
            SOURCE_NAME      VARCHAR2(200),
            CHUNK_TYPE       VARCHAR2(50),
            CONTENT          CLOB,
            TOTAL_ROWS       NUMBER(10,0),
            TOTAL_COLS       NUMBER(6,0),
            EXTRACTED_DT     TIMESTAMP       DEFAULT SYSTIMESTAMP,
            CONSTRAINT PK_BI_DATA_CONTEXT PRIMARY KEY (SOURCE_ID, CHUNK_ID)
        )
    """,
}

# Indexes to create (idempotent)
_INDEXES = [
    ("IDX_BI_SESS_USER",    "BI_CHAT_SESSION", "USER_ID"),
    ("IDX_BI_SESS_SC",      "BI_CHAT_SESSION", "SCORECARD_ID"),
    ("IDX_BI_SESS_DT",      "BI_CHAT_SESSION", "CREATED_DT"),
    ("IDX_BI_SESS_STATUS",  "BI_CHAT_SESSION", "STATUS"),
    ("IDX_BI_HIST_SESSION", "BI_CHAT_HISTORY", "SESSION_ID"),
    ("IDX_BI_HIST_USER",    "BI_CHAT_HISTORY", "USER_ID"),
    ("IDX_BI_HIST_SC",      "BI_CHAT_HISTORY", "SCORECARD_ID"),
    ("IDX_BI_HIST_DT",      "BI_CHAT_HISTORY", "CREATED_DT"),
    ("IDX_BI_AUDIT_DT",     "BI_API_AUDIT",    "CREATED_DT"),
    ("IDX_BI_AUDIT_USER",   "BI_API_AUDIT",    "USER_ID"),
    ("IDX_BI_SNAP_VIEW",    "BI_SNAPSHOT_LOG",  "VIEW_ID"),
    ("IDX_BI_CTX_SRC",      "BI_DATA_CONTEXT",  "SOURCE_ID"),
]


def _table_exists(cursor, table_name: str) -> bool:
    """Check if table exists in current schema."""
    cursor.execute(
        "SELECT COUNT(*) FROM USER_TABLES WHERE TABLE_NAME = :1",
        [table_name],
    )
    return cursor.fetchone()[0] > 0


def _index_exists(cursor, index_name: str) -> bool:
    """Check if index exists in current schema."""
    cursor.execute(
        "SELECT COUNT(*) FROM USER_INDEXES WHERE INDEX_NAME = :1",
        [index_name],
    )
    return cursor.fetchone()[0] > 0


def auto_init_db() -> dict:
    """
    Auto-create all required Oracle tables and indexes on startup.
    Completely idempotent — skips anything that already exists.

    Returns: {"tables_created": [...], "indexes_created": [...], "errors": [...]}
    """
    if not check_oracle():
        log.info("Oracle not configured — skipping DB init")
        return {"tables_created": [], "indexes_created": [], "skipped": True}

    import oracledb

    result = {"tables_created": [], "indexes_created": [], "errors": []}

    try:
        conn = oracledb.connect(
            user=ORACLE_USER, password=ORACLE_PASSWORD, dsn=ORACLE_DSN,
        )
        cursor = conn.cursor()
        log.info("┌─ DB AUTO-INIT ─────────────────────────────────────────")

        # Create tables
        for table_name, ddl in _TABLES.items():
            if _table_exists(cursor, table_name):
                log.info(f"│ ✓ {table_name} — already exists")
            else:
                try:
                    cursor.execute(ddl)
                    conn.commit()
                    result["tables_created"].append(table_name)
                    log.info(f"│ ✓ {table_name} — CREATED")
                except Exception as e:
                    result["errors"].append(f"{table_name}: {e}")
                    log.error(f"│ ✗ {table_name} — FAILED: {e}")

        # Create indexes
        for idx_name, table_name, col_name in _INDEXES:
            if _index_exists(cursor, idx_name):
                continue  # silent skip — indexes are secondary
            try:
                cursor.execute(f"CREATE INDEX {idx_name} ON {table_name} ({col_name})")
                conn.commit()
                result["indexes_created"].append(idx_name)
            except Exception:
                pass  # index creation failure is non-critical

        if result["indexes_created"]:
            log.info(f"│ Created {len(result['indexes_created'])} indexes")

        cursor.close()
        conn.close()

        log.info(f"│ Tables: {len(_TABLES)} checked, {len(result['tables_created'])} created")
        log.info("└────────────────────────────────────────────────────────")

    except Exception as e:
        log.error(f"DB auto-init FAILED: {e}")
        result["errors"].append(str(e))

    return result
