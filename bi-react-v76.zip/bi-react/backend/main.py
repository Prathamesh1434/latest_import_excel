"""
main.py — v7.5

Application entrypoint with:
- Lifespan: restores scorecards from disk on startup
- SSE endpoint for real-time onboarding progress
- CORS middleware
- All router mounts
- React SPA static file serving from dist/
"""
import asyncio
import json
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from backend.config import setup_logging
setup_logging()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

from backend.routers.api import router as api_router
from backend.routers.onboard import router as onboard_router, get_progress
from backend.routers.data import router as data_router
from backend.routers.chat import router as chat_router
from backend.routers.docs import router as docs_router
from backend.routers.auth import router as auth_router

from backend.services.scorecard_registry import restore_all_from_disk

log = logging.getLogger("main")

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DIST_DIR = PROJECT_ROOT / "dist"


# ══════ LIFESPAN ══════

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: restore all scorecards from storage/ directory."""
    log.info("=" * 60)
    log.info("B&I CDE Intelligence Platform v7.5 starting...")
    log.info("=" * 60)
    count = restore_all_from_disk()
    log.info(f"Startup complete. Restored {count} scorecards from disk.")
    log.info(f"React dist present: {DIST_DIR.exists()}")
    log.info("=" * 60)
    yield
    log.info("Shutting down...")


# ══════ APP ══════

app = FastAPI(
    title="B&I CDE Intelligence Platform",
    description="Standalone Enterprise Data Intelligence Platform v7.5",
    version="7.5.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"],
)


# ══════ API ROUTERS (registered before catch-all) ══════

app.include_router(api_router, tags=["API"])
app.include_router(auth_router, prefix="/auth", tags=["Auth"])
app.include_router(onboard_router, prefix="/scorecards", tags=["Onboard"])
app.include_router(data_router, prefix="/data", tags=["Data"])
app.include_router(chat_router, prefix="/chat", tags=["Chat"])
app.include_router(docs_router, prefix="/docs", tags=["Docs"])


# ══════ SSE PROGRESS ══════

@app.get("/progress/{scorecard_id}")
async def sse_progress(scorecard_id: str):
    """Server-Sent Events stream for real-time onboarding progress."""

    async def event_stream():
        last_step = -1
        timeout_count = 0
        max_timeout = 120

        while timeout_count < max_timeout:
            progress = get_progress(scorecard_id)
            current_step = progress.get("step", 0)

            if current_step != last_step:
                data = json.dumps(progress)
                yield f"data: {data}\n\n"
                last_step = current_step

                if progress.get("status") in ("done", "error"):
                    break

            await asyncio.sleep(0.3)
            timeout_count += 1

        yield f"data: {json.dumps({'step': 7, 'label': 'Complete', 'status': 'done'})}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ══════ REACT SPA STATIC FILES ══════
# Mounted AFTER all API routes so API takes priority.
# Catch-all returns index.html enabling React Router client-side routing.

if DIST_DIR.exists():
    assets_dir = DIST_DIR / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")

    @app.get("/{full_path:path}")
    async def serve_react_app(full_path: str):
        """Catch-all: serve React SPA. API routes above take precedence."""
        requested_file = DIST_DIR / full_path
        if requested_file.is_file():
            return FileResponse(str(requested_file))
        index_path = DIST_DIR / "index.html"
        if index_path.exists():
            return FileResponse(str(index_path), media_type="text/html")
        return HTMLResponse(
            "<h1>React app not built.</h1>"
            "<p>Run: <code>cd frontend && npm install && npm run build</code></p>",
            status_code=404,
        )
else:
    @app.get("/")
    def root_no_build():
        return {
            "service": "B&I CDE Intelligence Platform",
            "version": "7.5.0",
            "status": "React app not built. Run: cd frontend && npm install && npm run build",
            "api_docs": "/api/docs",
        }

    log.warning(
        f"React dist/ not found at {DIST_DIR}. "
        "Run: cd frontend && npm install && npm run build"
    )
