"""
routers/data.py — v7.4

Data query, filter, KRI, dynamic pivot/aggregation,
month-over-month comparison, pivot sheet data, trend data,
export, and compare endpoints.
"""
import io
import math
import logging
from datetime import datetime
from typing import Dict, Any, List
from fastapi import APIRouter, HTTPException, Request, Header, File, UploadFile, Form
from fastapi.responses import StreamingResponse
import pandas as pd

from backend.services.scorecard_registry import (
    get_scorecard, list_all, persist_to_disk, persist_month_to_disk, STORAGE_DIR
)
from backend.services.data_service import calculate_kri, load_data, load_all_sheets, process_all_sheets, clean_column_name, build_column_map
from backend.routers.auth import check_role

log = logging.getLogger("data")

router = APIRouter()


@router.get("/{scorecard_id}/schema")
def get_schema(scorecard_id: str):
    """Return detected schema and visual config."""
    sc = get_scorecard(scorecard_id)
    return {
        "schema": sc.get("schema"),
        "visual_config": sc.get("visual_config"),
    }


@router.get("/{scorecard_id}/summary")
def get_summary(scorecard_id: str):
    """Return summary stats: row count, column count, RAG distribution."""
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    schema = sc.get("schema", {})

    rag_dist = {}
    if schema.get("rag_status"):
        rag_col = schema["rag_status"][0]
        rag_dist = df[rag_col].value_counts().to_dict()

    return {
        "scorecard_id": scorecard_id,
        "display_name": sc.get("display_name", scorecard_id),
        "row_count": sc.get("row_count", 0),
        "col_count": sc.get("col_count", 0),
        "schema": schema,
        "rag_distribution": rag_dist,
        "onboarded_at": sc.get("onboarded_at", ""),
    }


@router.get("/{scorecard_id}/column-map")
def get_column_map(scorecard_id: str):
    """Return mapping of raw column names to clean display names."""
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    col_map = build_column_map(list(df.columns))
    return col_map


@router.post("/{scorecard_id}/data-table")
async def get_data_table(scorecard_id: str, request: Request):
    """
    Paginated, filterable, sortable data table with clean column names.
    Body: {page: 1, per_page: 50, sort_col: str, sort_dir: 'asc'|'desc',
           filters: [{column: str, operator: str, value: str}]}
    Returns: {rows: [...], total_rows: int, page: int, total_pages: int,
              columns: [{raw: str, clean: str, dtype: str}], column_map: {}}
    """
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    body = await request.json()

    page = max(1, body.get("page", 1))
    per_page = min(200, max(10, body.get("per_page", 50)))
    sort_col = body.get("sort_col")
    sort_dir = body.get("sort_dir", "asc")
    filters = body.get("filters", [])

    # Apply filters — case-insensitive column name matching with fallback variants
    filtered = df.copy()
    for f in filters:
        col = f.get("column", "")
        op = f.get("operator", "equals")
        val = f.get("value", "")
        if not val:
            continue
        # Case-insensitive column resolution + common alias fallbacks
        resolved_col = None
        if col in filtered.columns:
            resolved_col = col
        else:
            # Try case-insensitive match
            for c in filtered.columns:
                if c.lower() == col.lower():
                    resolved_col = c
                    break
        # Try common column aliases for drill-through
        if resolved_col is None:
            ALIASES = {
                "immutable_cde": ["immutable_cde", "IMMUTABLE_CDE", "cde_name", "CDE_NAME", "cde", "CDE", "rule_name"],
                "rag_status": ["rag_status", "RAG_STATUS", "status", "STATUS", "rag", "RAG", "kri_status"],
            }
            for alias_key, variants in ALIASES.items():
                if col.lower() == alias_key.lower():
                    for v in variants:
                        if v in filtered.columns:
                            resolved_col = v
                            break
                    break
        if resolved_col is None:
            continue
        col = resolved_col
        col_series = filtered[col].astype(str)
        if op == "equals":
            filtered = filtered[col_series == str(val)]
        elif op == "not_equals":
            filtered = filtered[col_series != str(val)]
        elif op == "contains":
            filtered = filtered[col_series.str.contains(str(val), case=False, na=False)]
        elif op == "greater_than":
            try:
                filtered = filtered[pd.to_numeric(filtered[col], errors="coerce") > float(val)]
            except ValueError:
                pass
        elif op == "less_than":
            try:
                filtered = filtered[pd.to_numeric(filtered[col], errors="coerce") < float(val)]
            except ValueError:
                pass
        elif op == "in":
            vals = [v.strip() for v in str(val).split(",")]
            filtered = filtered[col_series.isin(vals)]

    # Sort
    if sort_col and sort_col in filtered.columns:
        try:
            numeric = pd.to_numeric(filtered[sort_col], errors="coerce")
            if numeric.notna().sum() > len(filtered) * 0.5:
                filtered = filtered.assign(_sort_key=numeric)
                filtered = filtered.sort_values("_sort_key", ascending=(sort_dir == "asc"), na_position="last")
                filtered = filtered.drop(columns=["_sort_key"])
            else:
                filtered = filtered.sort_values(sort_col, ascending=(sort_dir == "asc"), na_position="last")
        except Exception:
            filtered = filtered.sort_values(sort_col, ascending=(sort_dir == "asc"), na_position="last")

    total_rows = len(filtered)
    total_pages = max(1, (total_rows + per_page - 1) // per_page)
    start = (page - 1) * per_page
    end = start + per_page

    page_df = filtered.iloc[start:end]
    rows = _clean_for_json(page_df.fillna("").to_dict(orient="records"))

    # Column metadata with clean names
    col_map = build_column_map(list(df.columns))
    columns = []
    for col in df.columns:
        dtype = "text"
        if pd.api.types.is_numeric_dtype(df[col]):
            dtype = "numeric"
        elif "date" in col.lower() or "month" in col.lower():
            dtype = "date"
        columns.append({"raw": col, "clean": col_map.get(col, col), "dtype": dtype})

    return {
        "rows": rows,
        "total_rows": total_rows,
        "page": page,
        "total_pages": total_pages,
        "per_page": per_page,
        "columns": columns,
        "column_map": col_map,
    }


@router.get("/{scorecard_id}/column-values/{column_name}")
def get_column_values(scorecard_id: str, column_name: str, limit: int = 100):
    """Get unique values for a column (for filter dropdowns)."""
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    if column_name not in df.columns:
        raise HTTPException(404, f"Column '{column_name}' not found")
    vals = df[column_name].dropna().astype(str).unique().tolist()
    vals = sorted([v for v in vals if v.strip()])[:limit]
    return {"column": column_name, "values": vals, "total": len(vals)}


@router.post("/{scorecard_id}/export-csv")
async def export_filtered_csv(scorecard_id: str, request: Request):
    """Export filtered data as CSV with clean column names."""
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    body = await request.json()
    filters = body.get("filters", [])

    filtered = df.copy()
    for f in filters:
        col = f.get("column", "")
        op = f.get("operator", "equals")
        val = f.get("value", "")
        if col not in filtered.columns or not val:
            continue
        col_series = filtered[col].astype(str)
        if op == "equals":
            filtered = filtered[col_series == str(val)]
        elif op == "contains":
            filtered = filtered[col_series.str.contains(str(val), case=False, na=False)]

    # Clean column names for export
    col_map = build_column_map(list(filtered.columns))
    export_df = filtered.rename(columns=col_map)

    buf = io.StringIO()
    export_df.to_csv(buf, index=False)
    buf.seek(0)
    return StreamingResponse(
        iter([buf.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={scorecard_id}_export.csv"}
    )


@router.get("/{scorecard_id}/filters")
def get_filters(scorecard_id: str):
    """Return dynamic filter options populated from actual data."""
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    schema = sc.get("schema", {})

    filters = {}
    key_fields = {"date", "report_name", "immutable_cde", "product", "legal_entity", "system"}
    target_cols = set(schema.get("dimension", []))

    for col in df.columns:
        if col.lower() in key_fields or col in target_cols:
            try:
                vals = df[col].dropna().unique().tolist()
                vals = [str(v) for v in vals if str(v).strip()]
                if 0 < len(vals) < 200:
                    filters[col] = sorted(vals)
            except Exception:
                pass

    return filters


def _apply_filters(df: pd.DataFrame, filters: Dict) -> pd.DataFrame:
    """Apply filter dict to DataFrame."""
    result = df.copy()
    for k, v in filters.items():
        if k not in result.columns or not v:
            continue
        if isinstance(v, list):
            if "All" not in v and "ALL" not in v and "(All)" not in v:
                result = result[result[k].astype(str).isin([str(x) for x in v])]
        else:
            sv = str(v)
            if sv not in ("All", "ALL", "(All)"):
                result = result[result[k].astype(str) == sv]
    return result


def _clean_for_json(data):
    """Replace NaN/Inf with None for JSON serialization."""
    if isinstance(data, list):
        for row in data:
            if isinstance(row, dict):
                for k, v in row.items():
                    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
                        row[k] = None
    return data


@router.post("/{scorecard_id}/query")
async def post_query(scorecard_id: str, request: Request):
    """Query data with filters. Returns rows as list of dicts."""
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    body = await request.json()
    filters = body.get("filters", {})
    limit = body.get("limit", 200)

    filtered = _apply_filters(df, filters)
    result = filtered.head(limit).fillna("").to_dict(orient="records")
    return _clean_for_json(result)


@router.get("/{scorecard_id}/kri")
def get_kri(scorecard_id: str):
    """Calculate KRI for the scorecard."""
    sc = get_scorecard(scorecard_id)
    return calculate_kri(sc.get("df"), sc.get("schema", {}))


@router.get("/{scorecard_id}/landing")
def get_landing(scorecard_id: str):
    """Return landing page data: KPIs, trends, RAG distribution."""
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    schema = sc.get("schema", {})

    kpis = {"total_rules": 0, "failed_rules": 0, "pass_rate": 0}
    kri_data = calculate_kri(df, schema)
    if kri_data:
        total = kri_data.get("total", len(df))
        failed = kri_data.get("failed", 0)
        kpis["total_rules"] = total
        kpis["failed_rules"] = failed
        kpis["pass_rate"] = ((total - failed) / total * 100) if total > 0 else 0

    trends = []
    if schema.get("date") and schema.get("rag_status"):
        date_col = schema["date"][0]
        rag_col = schema["rag_status"][0]
        try:
            fail_df = df[df[rag_col].str.lower() == "red"]
            if not fail_df.empty:
                grouped = fail_df.groupby(date_col).size().reset_index(name="failures")
                trends = _clean_for_json(grouped.to_dict(orient="records"))
        except Exception:
            pass

    rag_dist = {}
    if schema.get("rag_status"):
        rag_col = schema["rag_status"][0]
        rag_dist = df[rag_col].value_counts().to_dict()

    return {"kpis": kpis, "trends": trends, "rag_distribution": rag_dist}


@router.post("/{scorecard_id}/filtered_kpis")
async def get_filtered_kpis(scorecard_id: str, request: Request):
    """Calculate KPIs with filters applied."""
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    schema = sc.get("schema", {})
    body = await request.json()
    filters = body.get("filters", {})
    filtered = _apply_filters(df, filters)

    kpis = {"total_rules": 0, "failed_rules": 0, "pass_rate": 0}
    kri_data = calculate_kri(filtered, schema)
    if kri_data:
        total = kri_data.get("total", len(filtered))
        failed = kri_data.get("failed", 0)
        kpis["total_rules"] = total
        kpis["failed_rules"] = failed
        kpis["pass_rate"] = ((total - failed) / total * 100) if total > 0 else 0

    rag_dist = {}
    if schema.get("rag_status"):
        rag_col = schema["rag_status"][0]
        rag_dist = filtered[rag_col].value_counts().to_dict()

    return {"kpis": kpis, "rag_distribution": rag_dist}


# ══════════════════════════════════════════════════════════════════
# DYNAMIC PIVOT & AGGREGATION
# ══════════════════════════════════════════════════════════════════

@router.get("/{scorecard_id}/pivot/config")
def get_pivot_config(scorecard_id: str):
    """
    Return available columns for pivot configuration.
    Groups columns into rows/columns/values candidates.
    """
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    schema = sc.get("schema", {})

    dim_cols = schema.get("dimension", []) + schema.get("identifier", [])
    measure_cols = schema.get("measure", [])
    date_cols = schema.get("date", [])
    status_cols = schema.get("rag_status", [])

    # All categorical columns (low cardinality) can be rows/columns
    cat_cols = []
    for col in df.columns:
        if df[col].nunique() <= 50 and pd.api.types.is_string_dtype(df[col]):
            cat_cols.append(col)

    # All numeric columns can be values
    num_cols = [col for col in df.columns if pd.api.types.is_numeric_dtype(df[col])]

    return {
        "row_candidates": list(set(dim_cols + status_cols + cat_cols + date_cols)),
        "column_candidates": list(set(dim_cols + status_cols + cat_cols + date_cols)),
        "value_candidates": num_cols,
        "agg_functions": ["sum", "mean", "count", "min", "max", "median", "std"],
        "schema": schema,
    }


@router.post("/{scorecard_id}/pivot")
async def create_pivot(scorecard_id: str, request: Request):
    """
    Create a dynamic pivot table.

    Body:
      rows: list of column names for index
      columns: list of column names for columns (optional)
      values: list of column names for values
      agg_func: aggregation function (sum, mean, count, min, max, median, std)
      filters: optional filter dict
    """
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    body = await request.json()

    rows = body.get("rows", [])
    columns = body.get("columns", [])
    values = body.get("values", [])
    agg_func = body.get("agg_func", "sum")
    filters = body.get("filters", {})

    if not rows:
        raise HTTPException(400, "At least one row dimension is required")
    if not values:
        raise HTTPException(400, "At least one value column is required")

    # Validate columns exist
    for col in rows + columns + values:
        if col not in df.columns:
            raise HTTPException(400, f"Column '{col}' not found in data")

    # Apply filters first
    filtered = _apply_filters(df, filters)
    if filtered.empty:
        return {"pivot_data": [], "chart_data": None, "summary": {}}

    try:
        # Build pivot
        pivot_kwargs = {
            "index": rows,
            "values": values,
            "aggfunc": agg_func,
        }
        if columns:
            pivot_kwargs["columns"] = columns

        pivot_df = pd.pivot_table(filtered, **pivot_kwargs, fill_value=0)

        # Flatten MultiIndex columns if needed
        if isinstance(pivot_df.columns, pd.MultiIndex):
            pivot_df.columns = [" / ".join(str(c) for c in col).strip() for col in pivot_df.columns.values]

        # Reset index so rows become columns
        pivot_df = pivot_df.reset_index()

        # Prepare output
        pivot_data = _clean_for_json(pivot_df.fillna(0).to_dict(orient="records"))

        # Build chart data for visualization
        chart_data = _build_pivot_chart(pivot_df, rows, values, agg_func, columns)

        # Summary stats
        summary = {
            "total_rows": len(pivot_df),
            "agg_func": agg_func,
            "row_dims": rows,
            "col_dims": columns,
            "value_cols": values,
        }

        # Add grand totals
        for val_col in values:
            matching_cols = [c for c in pivot_df.columns if val_col in str(c) and c not in rows]
            for mc in matching_cols:
                if pd.api.types.is_numeric_dtype(pivot_df[mc]):
                    summary[f"grand_total_{mc}"] = float(pivot_df[mc].sum())
                    summary[f"grand_avg_{mc}"] = float(pivot_df[mc].mean())

        return {
            "pivot_data": pivot_data,
            "pivot_columns": list(pivot_df.columns),
            "chart_data": chart_data,
            "summary": summary,
        }

    except Exception as e:
        log.error(f"Pivot failed: {e}")
        raise HTTPException(500, f"Pivot creation failed: {str(e)}")


def _build_pivot_chart(pivot_df: pd.DataFrame, rows: List[str], values: List[str],
                       agg_func: str, columns: List[str]) -> Dict[str, Any]:
    """Build Chart.js compatible chart data from pivot result."""
    if pivot_df.empty:
        return None

    # Use first row dimension as labels
    labels = pivot_df[rows[0]].astype(str).tolist()[:30]  # Limit to 30 labels

    # Find value columns (numeric, not in rows)
    numeric_cols = [c for c in pivot_df.columns if c not in rows and pd.api.types.is_numeric_dtype(pivot_df[c])]

    if not numeric_cols:
        return None

    COLORS = ["#0057A8", "#C8102E", "#047857", "#D97706", "#6D28D9", "#0891B2", "#BE185D", "#4338CA"]

    datasets = []
    for i, col in enumerate(numeric_cols[:8]):  # Max 8 series
        datasets.append({
            "label": str(col),
            "data": [round(float(v), 2) if pd.notna(v) else 0 for v in pivot_df[col].head(30)],
            "color": COLORS[i % len(COLORS)],
        })

    # Choose chart type
    chart_type = "bar"
    if len(labels) > 12:
        chart_type = "line"
    if len(numeric_cols) == 1 and len(labels) <= 8:
        # Could be a pie chart if it's a distribution
        if agg_func == "count" or agg_func == "sum":
            chart_type = "doughnut"

    result = {
        "chart_type": chart_type,
        "title": f"{agg_func.upper()} of {', '.join(values)} by {', '.join(rows)}",
        "subtitle": f"{len(pivot_df)} groups" + (f" × {', '.join(columns)}" if columns else ""),
        "labels": labels,
        "datasets": datasets,
    }

    # For pie/doughnut, flatten to single series
    if chart_type in ("pie", "doughnut") and datasets:
        result["data"] = datasets[0]["data"]
        result["colors"] = COLORS[:len(labels)]

    return result


@router.post("/{scorecard_id}/aggregate")
async def aggregate_data(scorecard_id: str, request: Request):
    """
    Simple groupby aggregation without full pivot.

    Body:
      group_by: list of column names
      agg: dict of {column: agg_function} or single agg_func for all numeric
      filters: optional filter dict
    """
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    body = await request.json()

    group_by = body.get("group_by", [])
    agg = body.get("agg", "sum")
    filters = body.get("filters", {})

    if not group_by:
        raise HTTPException(400, "group_by is required")

    filtered = _apply_filters(df, filters)

    try:
        if isinstance(agg, dict):
            result_df = filtered.groupby(group_by).agg(agg).reset_index()
        else:
            # Apply agg to all numeric columns
            numeric_df = filtered.groupby(group_by)
            if agg == "count":
                result_df = numeric_df.size().reset_index(name="count")
            else:
                result_df = numeric_df.agg(agg, numeric_only=True).reset_index()

        # Flatten MultiIndex columns
        if isinstance(result_df.columns, pd.MultiIndex):
            result_df.columns = ["_".join(str(c) for c in col).strip("_") for col in result_df.columns.values]

        data = _clean_for_json(result_df.fillna(0).to_dict(orient="records"))

        # Build chart
        labels = result_df[group_by[0]].astype(str).tolist()[:30]
        num_cols = [c for c in result_df.columns if c not in group_by and pd.api.types.is_numeric_dtype(result_df[c])]

        COLORS = ["#0057A8", "#C8102E", "#047857", "#D97706", "#6D28D9"]
        chart = {
            "chart_type": "bar" if len(labels) <= 15 else "line",
            "title": f"{agg if isinstance(agg,str) else 'Aggregation'} by {', '.join(group_by)}",
            "labels": labels,
            "datasets": [
                {"label": col, "data": [round(float(v), 2) for v in result_df[col].head(30)], "color": COLORS[i % 5]}
                for i, col in enumerate(num_cols[:5])
            ],
        }

        return {"data": data, "chart": chart, "columns": list(result_df.columns)}

    except Exception as e:
        raise HTTPException(500, f"Aggregation failed: {str(e)}")


# ══════════════════════════════════════════════════════════════════
# MONTH DATA & COMPARISON
# ══════════════════════════════════════════════════════════════════

@router.post("/{scorecard_id}/add-month")
async def add_month_data(
    scorecard_id: str,
    month_label: str = Form(""),
    reporting_month: str = Form(""),
    data_file: UploadFile = File(...),
    x_user_id: str = Header(default="PG23137"),
):
    """
    Upload monthly data for comparison. Multi-sheet Excel supported.
    reporting_month or month_label: e.g. "2026-01", "2026-02" (YYYY-MM)
    """
    sc = get_scorecard(scorecard_id)
    rm = reporting_month or month_label
    if not rm:
        from fastapi import HTTPException as HE
        raise HE(status_code=400, detail="reporting_month or month_label is required")

    content = await data_file.read()
    all_sheets, primary_df, _schema, _vc, sheet_meta = process_all_sheets(
        content, data_file.filename
    )

    # Derive month display label
    MONTH_NAMES = {
        "01": "Jan", "02": "Feb", "03": "Mar", "04": "Apr",
        "05": "May", "06": "Jun", "07": "Jul", "08": "Aug",
        "09": "Sep", "10": "Oct", "11": "Nov", "12": "Dec",
    }
    parts = rm.split("-")
    display_label = f"{MONTH_NAMES.get(parts[1], parts[1])} {parts[0]}" if len(parts) >= 2 else rm

    now_iso = datetime.utcnow().isoformat()

    # Store in registry
    months = sc.get("months", {})
    months[rm] = {
        "month_label": rm,
        "reporting_month": rm,
        "display_label": display_label,
        "df": primary_df,
        "sheets": all_sheets,
        "sheet_meta": sheet_meta,
        "filename": data_file.filename,
        "uploaded_at": now_iso,
        "row_count": len(primary_df),
        "col_count": len(primary_df.columns),
    }
    sc["months"] = months
    sc["file_modified"] = now_iso

    # Persist to disk
    persist_month_to_disk(scorecard_id, rm)

    log.info(f"Added month '{rm}' for '{scorecard_id}': {len(primary_df)} rows, {len(all_sheets)} sheets")

    return {
        "status": "ok",
        "scorecard_id": scorecard_id,
        "month_label": rm,
        "reporting_month": rm,
        "display_label": display_label,
        "row_count": len(primary_df),
        "col_count": len(primary_df.columns),
        "sheet_count": len(all_sheets),
        "sheet_names": list(all_sheets.keys()),
    }


@router.post("/{scorecard_id}/upload-period")
async def upload_period_file(
    scorecard_id: str,
    period_label: str = Form(...),
    data_file: UploadFile = File(...),
    x_user_id: str = Header(default="PG23137"),
):
    """Legacy period upload endpoint. Redirects to add-month logic."""
    sc = get_scorecard(scorecard_id)

    content = await data_file.read()
    sheets = load_all_sheets(content, data_file.filename)
    primary_df = sheets.get("raw", list(sheets.values())[0])

    # Store in months
    months = sc.get("months", {})
    months[period_label] = {
        "month_label": period_label,
        "df": primary_df,
        "sheets": sheets,
        "filename": data_file.filename,
        "uploaded_at": datetime.utcnow().isoformat(),
        "row_count": len(primary_df),
        "col_count": len(primary_df.columns),
    }
    sc["months"] = months

    # Also save to legacy periods dir for backward compat
    periods_dir = STORAGE_DIR / scorecard_id / "periods"
    periods_dir.mkdir(parents=True, exist_ok=True)
    primary_df.to_csv(periods_dir / f"{period_label}.csv", index=False)

    periods = sc.get("periods", {})
    periods[period_label] = {
        "filename": data_file.filename,
        "uploaded_at": datetime.utcnow().isoformat(),
        "row_count": len(primary_df),
        "col_count": len(primary_df.columns),
    }
    sc["periods"] = periods

    persist_month_to_disk(scorecard_id, period_label)

    return {
        "status": "ok",
        "scorecard_id": scorecard_id,
        "period_label": period_label,
        "row_count": len(primary_df),
        "col_count": len(primary_df.columns),
    }


@router.get("/{scorecard_id}/months")
def list_months(scorecard_id: str):
    """List all month data for a scorecard."""
    sc = get_scorecard(scorecard_id)
    months = sc.get("months", {})
    result = []
    for label, data in sorted(months.items()):
        result.append({
            "month_label": label,
            "filename": data.get("filename", ""),
            "uploaded_at": data.get("uploaded_at", ""),
            "row_count": data.get("row_count", 0),
            "col_count": data.get("col_count", 0),
            "sheet_names": list(data.get("sheets", {}).keys()),
        })
    return result


@router.get("/{scorecard_id}/periods")
def list_periods(scorecard_id: str):
    """List all uploaded period/month files for a scorecard."""
    sc = get_scorecard(scorecard_id)
    # Combine legacy periods dir + months registry
    result = []
    months = sc.get("months", {})
    for label, data in sorted(months.items()):
        result.append({
            "period_label": label,
            "filename": data.get("filename", ""),
            "uploaded_at": data.get("uploaded_at", ""),
            "row_count": data.get("row_count", 0),
        })
    # Also check legacy periods dir
    periods_dir = STORAGE_DIR / scorecard_id / "periods"
    if periods_dir.exists():
        for f in sorted(periods_dir.iterdir()):
            if f.suffix == ".csv":
                label = f.stem
                if label not in months:
                    meta = sc.get("periods", {}).get(label, {})
                    result.append({
                        "period_label": label,
                        "filename": meta.get("filename", f.name),
                        "uploaded_at": meta.get("uploaded_at", ""),
                        "row_count": meta.get("row_count", 0),
                    })
    return result


@router.get("/{scorecard_id}/sheets")
def list_sheets(scorecard_id: str):
    """List all sheets in the scorecard."""
    sc = get_scorecard(scorecard_id)
    sheets = sc.get("sheets", {})
    result = []
    for name, df in sheets.items():
        if isinstance(df, pd.DataFrame):
            result.append({
                "sheet_name": name,
                "row_count": len(df),
                "col_count": len(df.columns),
                "columns": list(df.columns),
            })
    return result


@router.get("/{scorecard_id}/sheets/{sheet_name}/data")
def get_sheet_data(scorecard_id: str, sheet_name: str, limit: int = 200):
    """Get data from a specific sheet."""
    sc = get_scorecard(scorecard_id)
    sheets = sc.get("sheets", {})
    if sheet_name not in sheets:
        raise HTTPException(404, f"Sheet '{sheet_name}' not found")
    df = sheets[sheet_name]
    data = df.head(limit).fillna("").to_dict(orient="records")
    return _clean_for_json(data)


@router.get("/{scorecard_id}/pivot-data/{sheet_name}")
def get_pivot_data(scorecard_id: str, sheet_name: str, month: str = ""):
    """
    Return parsed pivot data for the given original sheet name.
    Optional ?month=2026-02 to get month-specific data.
    """
    sc = get_scorecard(scorecard_id)
    sheet_meta = sc.get("sheet_meta", {})

    # Determine data source
    if month:
        months = sc.get("months", {})
        if month not in months:
            raise HTTPException(404, f"Month '{month}' not found")
        source = months[month]
        sheets = source.get("sheets", {})
        month_meta = source.get("sheet_meta", sheet_meta)
    else:
        sheets = sc.get("sheets", {})
        month_meta = sheet_meta

    if sheet_name not in sheets:
        raise HTTPException(404, f"Sheet '{sheet_name}' not found")

    df = sheets[sheet_name]
    meta = month_meta.get(sheet_name, {})

    data = _clean_for_json(df.fillna(0).to_dict(orient="records"))
    return {
        "sheet_name": sheet_name,
        "data": data,
        "columns": list(df.columns),
        "row_count": len(df),
        "meta": {k: v for k, v in meta.items() if k != "df"},
    }


@router.get("/{scorecard_id}/pivot-trend/{sheet_name}")
def get_pivot_trend(scorecard_id: str, sheet_name: str,
                   metric: str = "Row_Total", cde: str = ""):
    """
    Return multi-month trend data for a given pivot sheet, metric, and CDE.
    Returns Chart.js-ready line chart data.
    """
    sc = get_scorecard(scorecard_id)
    months = sc.get("months", {})
    sheet_meta = sc.get("sheet_meta", {})

    if len(months) < 1:
        return {"labels": [], "datasets": [], "message": "No month data available"}

    MONTH_NAMES = {
        "01": "Jan", "02": "Feb", "03": "Mar", "04": "Apr",
        "05": "May", "06": "Jun", "07": "Jul", "08": "Aug",
        "09": "Sep", "10": "Oct", "11": "Nov", "12": "Dec",
    }
    labels = []
    values = []

    for ml in sorted(months.keys()):
        md = months[ml]
        m_sheets = md.get("sheets", {})
        m_meta = md.get("sheet_meta", sheet_meta)

        if sheet_name not in m_sheets:
            continue

        sdf = m_sheets[sheet_name]
        smeta = m_meta.get(sheet_name, {})
        dim_col = smeta.get("dim_column", sdf.columns[0] if len(sdf.columns) > 0 else "")
        gt = smeta.get("grand_total", {})

        # Format month label
        parts = ml.split("-")
        month_lbl = f"{MONTH_NAMES.get(parts[1], parts[1])} {parts[0]}" if len(parts) >= 2 else ml
        labels.append(month_lbl)

        # Get value — case-insensitive metric lookup
        if not cde or cde.lower() in ("all", "(all)", "grand total"):
            # Case-insensitive lookup in grand_total
            metric_val = 0
            for k, v in gt.items():
                if k.lower() == metric.lower():
                    try:
                        metric_val = float(v) if v is not None else 0
                    except (TypeError, ValueError):
                        metric_val = 0
                    break
            val = metric_val
        else:
            matched = sdf[sdf[dim_col].astype(str).str.lower() == cde.lower()]
            if len(matched) > 0:
                # Case-insensitive column lookup
                metric_col = next((c for c in matched.columns if c.lower() == metric.lower()), None)
                if metric_col:
                    raw_val = matched.iloc[0][metric_col]
                    try:
                        fv = float(raw_val)
                        val = int(fv) if fv == int(fv) else fv
                    except (TypeError, ValueError):
                        val = 0
                else:
                    val = 0
            else:
                val = 0
        values.append(val)

    return {
        "labels": labels,
        "datasets": [{
            "label": sheet_name,
            "data": values,
            "borderColor": "#003B6F",
            "backgroundColor": "rgba(0,59,111,0.06)",
            "fill": True,
            "tension": 0.3,
        }],
        "metric": metric,
        "cde": cde or "All",
        "sheet_name": sheet_name,
    }


@router.post("/{scorecard_id}/mom-compare")
async def month_over_month(scorecard_id: str, request: Request):
    """
    Compare two periods for the same scorecard.

    Body:
      period_a: label of first period (e.g. "2026-01" or "previous")
      period_b: label of second period (e.g. "2026-02" or "current")
      key_columns: list of columns to match rows between periods
      compare_columns: list of columns to compare values (optional, defaults to all numeric + RAG)
    """
    sc = get_scorecard(scorecard_id)
    schema = sc.get("schema", {})
    body = await request.json()

    period_a = body.get("period_a", "")
    period_b = body.get("period_b", "")
    key_columns = body.get("key_columns", [])
    compare_columns = body.get("compare_columns", [])

    if not period_a or not period_b:
        raise HTTPException(400, "Both period_a and period_b are required")

    periods_dir = STORAGE_DIR / scorecard_id / "periods"

    # Load DataFrames — check periods dir first, then use main data as fallback
    df_a = _load_period(scorecard_id, period_a, periods_dir, sc)
    df_b = _load_period(scorecard_id, period_b, periods_dir, sc)

    if df_a is None:
        raise HTTPException(404, f"Period '{period_a}' not found")
    if df_b is None:
        raise HTTPException(404, f"Period '{period_b}' not found")

    # Auto-detect key columns if not provided
    if not key_columns:
        key_columns = schema.get("identifier", [])
        if not key_columns:
            # Try common key column names
            for candidate in ["rule_id", "source_system_rule_name", "immutable_cde", "id", "name"]:
                if candidate in df_a.columns and candidate in df_b.columns:
                    key_columns.append(candidate)
                    break

    if not key_columns:
        # Last resort: use first column
        common_cols = [c for c in df_a.columns if c in df_b.columns]
        if common_cols:
            key_columns = [common_cols[0]]

    # Auto-detect compare columns
    if not compare_columns:
        rag_cols = schema.get("rag_status", [])
        measure_cols = schema.get("measure", [])
        compare_columns = list(set(rag_cols + measure_cols))
        if not compare_columns:
            # Use all common numeric + string columns (excluding keys)
            common = [c for c in df_a.columns if c in df_b.columns and c not in key_columns]
            compare_columns = common[:10]

    # Perform comparison
    try:
        result = _compare_periods(df_a, df_b, key_columns, compare_columns, period_a, period_b, schema)
        return result
    except Exception as e:
        log.error(f"MoM comparison failed: {e}")
        raise HTTPException(500, f"Comparison failed: {str(e)}")


def _load_period(scorecard_id: str, label: str, periods_dir, sc) -> pd.DataFrame:
    """Load a period DataFrame from disk or use current data."""
    if label in ("current", "main", "latest"):
        return sc.get("df")

    period_file = periods_dir / f"{label}.csv"
    if period_file.exists():
        df = pd.read_csv(period_file)
        for col in df.columns:
            if pd.api.types.is_string_dtype(df[col]):
                df[col] = df[col].fillna("")
        return df

    return None


def _compare_periods(df_a, df_b, key_cols, compare_cols, label_a, label_b, schema) -> Dict:
    """
    Diff two DataFrames and produce a comprehensive comparison report.
    """
    # Overall stats
    stats_a = {"rows": len(df_a), "cols": len(df_a.columns)}
    stats_b = {"rows": len(df_b), "cols": len(df_b.columns)}

    # RAG distribution comparison
    rag_comparison = None
    rag_cols = schema.get("rag_status", [])
    if rag_cols:
        rag_col = rag_cols[0]
        if rag_col in df_a.columns and rag_col in df_b.columns:
            dist_a = df_a[rag_col].value_counts().to_dict()
            dist_b = df_b[rag_col].value_counts().to_dict()
            all_statuses = sorted(set(list(dist_a.keys()) + list(dist_b.keys())))
            rag_comparison = {
                "statuses": all_statuses,
                "period_a": {s: dist_a.get(s, 0) for s in all_statuses},
                "period_b": {s: dist_b.get(s, 0) for s in all_statuses},
            }

    # KRI comparison
    kri_a = calculate_kri(df_a, schema)
    kri_b = calculate_kri(df_b, schema)

    # Row-level diff (if key columns exist)
    changes = []
    new_rows = 0
    removed_rows = 0
    changed_rows = 0
    status_flips = []

    if key_cols and all(c in df_a.columns for c in key_cols) and all(c in df_b.columns for c in key_cols):
        # Create composite key
        key_a = df_a[key_cols].astype(str).agg("|".join, axis=1)
        key_b = df_b[key_cols].astype(str).agg("|".join, axis=1)

        keys_in_a = set(key_a.values)
        keys_in_b = set(key_b.values)

        new_keys = keys_in_b - keys_in_a
        removed_keys = keys_in_a - keys_in_b
        common_keys = keys_in_a & keys_in_b

        new_rows = len(new_keys)
        removed_rows = len(removed_keys)

        # Compare common rows
        df_a_indexed = df_a.set_index(key_a)
        df_b_indexed = df_b.set_index(key_b)

        for key in list(common_keys)[:200]:  # Limit to 200 for performance
            row_a = df_a_indexed.loc[key]
            row_b = df_b_indexed.loc[key]

            # Handle case where key isn't unique (take first)
            if isinstance(row_a, pd.DataFrame):
                row_a = row_a.iloc[0]
            if isinstance(row_b, pd.DataFrame):
                row_b = row_b.iloc[0]

            row_changes = []
            for col in compare_cols:
                if col in row_a.index and col in row_b.index:
                    val_a = row_a[col]
                    val_b = row_b[col]

                    if str(val_a) != str(val_b):
                        change = {
                            "column": col,
                            "old_value": str(val_a),
                            "new_value": str(val_b),
                        }

                        # Detect status flips
                        if col in rag_cols:
                            change["is_status_flip"] = True
                            status_flips.append({
                                "key": key,
                                "from": str(val_a),
                                "to": str(val_b),
                            })

                        # Calculate numeric delta
                        try:
                            num_a = float(val_a)
                            num_b = float(val_b)
                            change["delta"] = round(num_b - num_a, 4)
                            change["pct_change"] = round(((num_b - num_a) / num_a * 100), 2) if num_a != 0 else None
                        except (ValueError, TypeError):
                            pass

                        row_changes.append(change)

            if row_changes:
                changed_rows += 1
                if len(changes) < 50:  # Limit detail rows
                    changes.append({
                        "key": key,
                        "changes": row_changes,
                    })

    # Build comparison chart data
    chart_data = _build_comparison_charts(df_a, df_b, schema, label_a, label_b, rag_comparison, kri_a, kri_b)

    return {
        "period_a": {"label": label_a, **stats_a, "kri": kri_a},
        "period_b": {"label": label_b, **stats_b, "kri": kri_b},
        "rag_comparison": rag_comparison,
        "summary": {
            "new_rows": new_rows,
            "removed_rows": removed_rows,
            "changed_rows": changed_rows,
            "total_status_flips": len(status_flips),
            "status_flips_detail": status_flips[:20],
        },
        "changes": changes,
        "charts": chart_data,
    }


def _build_comparison_charts(df_a, df_b, schema, label_a, label_b, rag_comp, kri_a, kri_b) -> List[Dict]:
    """Build visual chart data for MoM comparison."""
    charts = []

    # 1. RAG Distribution comparison (grouped bar)
    if rag_comp:
        statuses = rag_comp["statuses"]
        STATUS_COLORS = {
            "Red": "#C8102E", "Amber": "#D97706", "Green": "#047857",
            "Dark Green": "#065F46", "red": "#C8102E", "amber": "#D97706",
            "green": "#047857", "dark green": "#065F46",
        }
        charts.append({
            "chart_type": "bar",
            "title": "RAG Distribution Comparison",
            "subtitle": f"{label_a} vs {label_b}",
            "labels": statuses,
            "datasets": [
                {"label": label_a, "data": [rag_comp["period_a"].get(s, 0) for s in statuses], "color": "#0057A8"},
                {"label": label_b, "data": [rag_comp["period_b"].get(s, 0) for s in statuses], "color": "#C8102E"},
            ],
        })

    # 2. KRI Trend (if both have KRI)
    if kri_a and kri_b:
        charts.append({
            "chart_type": "bar",
            "title": "KRI Comparison",
            "subtitle": f"Failure rate: {label_a} vs {label_b}",
            "labels": ["Total Rules", "Failed Rules", "KRI %"],
            "datasets": [
                {"label": label_a, "data": [kri_a.get("total", 0), kri_a.get("failed", 0), round(kri_a.get("kri", 0) * 100, 1)], "color": "#0057A8"},
                {"label": label_b, "data": [kri_b.get("total", 0), kri_b.get("failed", 0), round(kri_b.get("kri", 0) * 100, 1)], "color": "#C8102E"},
            ],
        })

    # 3. Measure column comparison (pick top 3 numeric cols)
    measure_cols = schema.get("measure", [])
    for col in measure_cols[:3]:
        if col in df_a.columns and col in df_b.columns:
            try:
                avg_a = float(df_a[col].mean())
                avg_b = float(df_b[col].mean())
                sum_a = float(df_a[col].sum())
                sum_b = float(df_b[col].sum())
                charts.append({
                    "chart_type": "bar",
                    "title": f"{col} Comparison",
                    "subtitle": f"Sum & Average",
                    "labels": ["Sum", "Average"],
                    "datasets": [
                        {"label": label_a, "data": [round(sum_a, 2), round(avg_a, 2)], "color": "#0057A8"},
                        {"label": label_b, "data": [round(sum_b, 2), round(avg_b, 2)], "color": "#C8102E"},
                    ],
                })
            except Exception:
                pass

    return charts


# ══════════════════════════════════════════════════════════════════
# EXPORT & CROSS-SCORECARD COMPARE
# ══════════════════════════════════════════════════════════════════

@router.get("/{scorecard_id}/export")
async def export_csv(scorecard_id: str, x_user_id: str = Header(default="PG23137")):
    """Export current data as CSV download."""
    from backend.routers.auth import get_user
    u = get_user(x_user_id)
    if u and u.get("role") == "viewer":
        raise HTTPException(403, "Viewers cannot export data")

    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    if df is None:
        raise HTTPException(404, "No data available")

    stream = io.StringIO()
    df.to_csv(stream, index=False)
    stream.seek(0)

    return StreamingResponse(
        iter([stream.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={scorecard_id}_export.csv"},
    )


@router.get("/compare")
async def compare_scorecards(ids: str = ""):
    """Compare 2+ scorecards side by side."""
    if not ids:
        sc_ids = list(list_all().keys())
    else:
        sc_ids = [s.strip() for s in ids.split(",") if s.strip()]

    if len(sc_ids) < 2:
        return {"error": "Need at least 2 scorecards to compare", "comparison": []}

    comparison = []
    for sid in sc_ids:
        try:
            sc = get_scorecard(sid)
            df = sc.get("df")
            schema = sc.get("schema", {})
            kri = calculate_kri(df, schema)

            rag_dist = {}
            if schema.get("rag_status"):
                rag_col = schema["rag_status"][0]
                rag_dist = df[rag_col].value_counts().to_dict()

            comparison.append({
                "scorecard_id": sid,
                "display_name": sc.get("display_name", sid),
                "total_rules": kri.get("total", len(df)),
                "failed_rules": kri.get("failed", 0),
                "kri_score": kri.get("kri", 0),
                "pass_rate": (1 - kri.get("kri", 0)) * 100,
                "rag_distribution": rag_dist,
                "row_count": len(df),
                "col_count": len(df.columns),
            })
        except Exception as e:
            log.warning(f"Compare: skipping {sid}: {e}")

    return {"comparison": comparison}
