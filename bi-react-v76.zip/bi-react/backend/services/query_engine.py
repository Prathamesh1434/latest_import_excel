"""
services/query_engine.py -- v7.4

Full 3-tier query routing engine:
  Tier 1 (DIRECT/PANDAS)  -- $0, <50ms  -- pattern-match + pandas ops
  Tier 2 (SEMANTIC/TF-IDF) -- $0, <100ms -- cosine similarity on indexed docs
  Tier 3 (LLM/GEMINI)     -- ~$0.002, 1-3s -- Vertex AI with T1+T2 context

Enhancements in v7.4:
  - Pivot-aware T1 queries with markdown table output
  - chart_data field in all responses (null if no chart)
  - Proactive summary handler
  - _detect_target_sheet() matches original sheet names via sheet_meta
  - Sheet comparison using original names
"""
import time
import re
import json
import difflib
import logging
import pandas as pd
from typing import Dict, Any, List, Optional, Tuple

log = logging.getLogger("query_engine")


# ============================================================
# FUZZY COLUMN MATCHING
# ============================================================

def _fuzzy_match_column(user_ref: str, columns: List[str], threshold: float = 0.5) -> Optional[str]:
    """
    Match a user's column reference to an actual column name.
    Tries: exact, case-insensitive, underscore-replaced, substring, then difflib fuzzy.
    """
    ref = user_ref.lower().strip()

    # 1. Exact match (case-insensitive)
    for col in columns:
        if col.lower() == ref:
            return col

    # 2. Underscore/space normalization
    ref_norm = ref.replace("_", " ").replace("-", " ")
    for col in columns:
        col_norm = col.lower().replace("_", " ").replace("-", " ")
        if col_norm == ref_norm:
            return col

    # 3. Substring match (user says "rule_names" matches "source_system_rule_name")
    for col in columns:
        col_lower = col.lower()
        if ref in col_lower or ref_norm in col_lower.replace("_", " "):
            return col

    # 4. Reverse substring (column name contained in user ref)
    for col in columns:
        col_norm = col.lower().replace("_", " ")
        if col_norm in ref_norm and len(col_norm) > 3:
            return col

    # 5. difflib fuzzy matching
    matches = difflib.get_close_matches(ref, [c.lower() for c in columns], n=1, cutoff=threshold)
    if matches:
        for col in columns:
            if col.lower() == matches[0]:
                return col

    # 6. Word overlap
    ref_words = set(ref_norm.split())
    best_col = None
    best_overlap = 0
    for col in columns:
        col_words = set(col.lower().replace("_", " ").split())
        overlap = len(ref_words & col_words)
        if overlap > best_overlap and overlap >= 1:
            best_overlap = overlap
            best_col = col
    if best_col and best_overlap >= 1:
        return best_col

    return None


def _extract_column_ref(question: str, columns: List[str]) -> Optional[str]:
    """Find a column name referenced in the question using fuzzy matching."""
    q = question.lower()

    # Try direct column name references
    for col in columns:
        if col.lower() in q or col.lower().replace("_", " ") in q:
            return col

    # Extract potential column references from question
    patterns = [
        r"(?:all|the|show|list|give|get|display)\s+(?:me\s+)?(?:the\s+)?(?:all\s+)?(?:unique\s+)?(.+?)$",
        r"(?:all|the|show|list|give|get|display)\s+(?:me\s+)?(?:the\s+)?(?:all\s+)?(?:unique\s+)?(.+?)\s+(?:are|in|from|for|of|that|which|please)",
        r"(?:distribution|breakdown|split|values)\s+(?:of|for|in)\s+(.+?)(?:\s|$)",
        r"(?:count|number|total)\s+(?:of|for)\s+(.+?)(?:\s|$)",
        r"(?:top|bottom|max|min|highest|lowest)\s+\d*\s*(.+?)(?:\s|$)",
    ]

    for pattern in patterns:
        match = re.search(pattern, q)
        if match:
            ref = match.group(1).strip().rstrip("s").strip("?.,!")
            if len(ref) > 1:
                col = _fuzzy_match_column(ref, columns)
                if col:
                    return col

    # Fallback: try fuzzy matching content words, preferring longer matches
    words = re.findall(r"[a-z_]+", q)
    stop_words = {"the", "a", "an", "is", "are", "in", "of", "for", "all", "me",
                  "give", "show", "list", "get", "what", "how", "many", "please",
                  "can", "you", "i", "do", "does", "it", "this", "that"}
    content_words = [w for w in words if w not in stop_words and len(w) > 2]

    # Try pairs first (more specific)
    for i in range(len(content_words) - 1):
        ref = content_words[i] + "_" + content_words[i + 1]
        col = _fuzzy_match_column(ref, columns)
        if col:
            return col

    # Then singles
    for w in content_words:
        col = _fuzzy_match_column(w, columns)
        if col:
            return col

    return None


def _extract_value_ref(question: str, df: pd.DataFrame, col: str) -> Optional[str]:
    """Find a specific value from a column referenced in the question."""
    q = question.lower()
    try:
        uniques = df[col].dropna().unique()
        for val in uniques:
            if str(val).lower() in q:
                return str(val)
    except Exception:
        pass
    return None


# ============================================================
# SHEET-AWARE ROUTING (with original sheet name support)
# ============================================================

SHEET_KEYWORDS = {
    "pivot_solo": ["solo", "individual", "single entity", "solo report", "solo non-cgme", "solo non cgme"],
    "pivot_conso": ["conso", "consolidated", "combined", "merged", "group report"],
    "pivot_cgme": ["cgme", "cgm-e", "cgm e", "solo cgme"],
    "pivot_cgml": ["cgml", "cgm-l", "cgm l"],
    "pivot_cgmfl": ["cgmfl", "cgm-fl"],
}


def _detect_target_sheet(question: str, available_sheets: Dict[str, Any],
                         sheet_meta: Dict[str, Any] = None) -> Optional[str]:
    """
    Detect which sheet the user is referring to based on question keywords.
    Returns the ORIGINAL sheet name (e.g. 'Consolidated', 'Solo CGME').
    """
    q = question.lower()

    # First try matching by original sheet name from sheet_meta
    if sheet_meta:
        for orig_name, meta in sheet_meta.items():
            if orig_name.lower() in q:
                return orig_name
            # Also try partial matching
            name_words = orig_name.lower().split()
            if len(name_words) >= 2 and all(w in q for w in name_words):
                return orig_name

    # Then try by internal label keywords -> map back to original name
    for label, keywords in SHEET_KEYWORDS.items():
        for kw in keywords:
            if kw in q:
                # Find original name with this label
                if sheet_meta:
                    for orig_name, meta in sheet_meta.items():
                        if meta.get("label") == label:
                            return orig_name
                # Fallback: try direct match on available_sheets
                if label in available_sheets:
                    return label

    return None


def _detect_sheet_comparison(question: str, available_sheets: Dict[str, Any],
                             sheet_meta: Dict[str, Any] = None) -> Optional[Tuple[str, str]]:
    """Detect if user wants to compare two sheets (e.g., 'compare solo vs consolidated')."""
    q = question.lower()
    if not any(w in q for w in ["compare", "vs", "versus", "difference", "differ"]):
        return None

    found = []

    # Try original names first
    if sheet_meta:
        for orig_name, meta in sheet_meta.items():
            if meta.get("is_pivot") and orig_name.lower() in q:
                found.append(orig_name)

    # If found fewer than 2, try keywords
    if len(found) < 2:
        for label, keywords in SHEET_KEYWORDS.items():
            for kw in keywords:
                if kw in q:
                    if sheet_meta:
                        for orig_name, meta in sheet_meta.items():
                            if meta.get("label") == label and orig_name not in found:
                                found.append(orig_name)
                                break
                    elif label in available_sheets and label not in found:
                        found.append(label)
                    break

    if len(found) >= 2:
        return (found[0], found[1])
    return None


# ============================================================
# MONTH-AWARE ROUTING
# ============================================================

MONTH_KEYWORDS = [
    "month on month", "month over month", "mom", "compare months",
    "trend", "what changed", "delta", "previous month", "last month",
    "monthly comparison", "month comparison",
]


def _detect_month_query(question: str) -> bool:
    """Check if question is about month-over-month comparison."""
    q = question.lower()
    return any(kw in q for kw in MONTH_KEYWORDS)


def _handle_month_query(question: str, scorecard: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Handle month-related queries."""
    months = scorecard.get("months", {})
    t0 = time.time()

    if not months or len(months) < 1:
        periods = scorecard.get("periods", {})
        if not periods:
            display = scorecard.get("display_title", scorecard.get("display_name", "this scorecard"))
            return {
                "tier": 1, "tier_label": "DIRECT",
                "reply": f"Only the current month's data is available for {display}. Upload another month's data using the 'MoM Compare' tab to enable month-over-month comparison.",
                "table_data": None, "chart": None, "chart_data": None,
                "confidence": 0.90, "latency_ms": int((time.time() - t0) * 1000),
                "data_source": "pandas", "model_used": "pandas",
            }

    if len(months) == 1:
        month_label = list(months.keys())[0]
        return {
            "tier": 1, "tier_label": "DIRECT",
            "reply": f"Only data for **{month_label}** is available. Upload another month's data to enable comparison.",
            "table_data": None, "chart": None, "chart_data": None,
            "confidence": 0.85, "latency_ms": int((time.time() - t0) * 1000),
            "data_source": "pandas", "model_used": "pandas",
        }

    # Multiple months available -- provide summary
    month_labels = sorted(months.keys())
    parts = [f"**{len(month_labels)} months** of data available: {', '.join(month_labels)}\n"]

    from backend.services.data_service import calculate_kri

    schema = scorecard.get("schema", {})
    for ml in month_labels:
        md = months[ml]
        mdf = md.get("df")
        if mdf is not None:
            kri = calculate_kri(mdf, schema)
            total = kri.get("total", len(mdf))
            failed = kri.get("failed", 0)
            rate = ((total - failed) / total * 100) if total > 0 else 0
            parts.append(f"- **{ml}**: {len(mdf)} rows, {failed} failures, {rate:.1f}% pass rate")

    reply = "\n".join(parts)
    reply += "\n\nUse the **MoM Compare** tab to see detailed comparison charts and status flips."

    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": None, "chart": None, "chart_data": None,
        "confidence": 0.90, "latency_ms": int((time.time() - t0) * 1000),
        "data_source": "pandas", "model_used": "pandas",
    }


# ============================================================
# PIVOT QUERY KEYWORDS
# ============================================================

PIVOT_KEYWORDS = [
    "solo", "consolidated", "cgme", "cgml", "pivot", "pass rate",
    "fail rate", "amber count", "red count", "dark green", "rag",
    "how many rules", "cde rules", "measurement point", "cde pass",
    "cde fail",
]

def _is_pivot_query(question: str) -> bool:
    """Check if question involves pivot sheet data."""
    q = question.lower()
    return any(kw in q for kw in PIVOT_KEYWORDS)


# ============================================================
# FIX 1: MULTI-PIVOT SUMMARY HELPERS
# ============================================================

def _get_all_pivot_summaries(scorecard: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Loop ALL pivot sheets and extract metrics from grand_total directly.
    grand_total in sheet_meta is the authoritative source — no row re-computation.
    Returns list of summary dicts, one per pivot sheet.
    """
    sheet_meta = scorecard.get("sheet_meta", {})
    summaries = []

    for name, meta in sheet_meta.items():
        if not meta.get("is_pivot"):
            continue
        gt = meta.get("grand_total", {})
        if not gt:
            continue

        rag_cols = meta.get("rag_columns", [])
        total_col = meta.get("total_column", "")
        business_date = meta.get("business_date", "")

        # Total rules — from total_col first, sum of rag_cols as fallback
        total_rules = 0
        if total_col:
            try:
                total_rules = int(float(gt.get(total_col, 0) or 0))
            except (TypeError, ValueError):
                total_rules = 0
        if total_rules == 0:
            for c in rag_cols:
                try:
                    total_rules += int(float(gt.get(c, 0) or 0))
                except (TypeError, ValueError):
                    pass

        # Red count — case-insensitive key lookup
        red_count = 0
        for k, v in gt.items():
            if k.lower() == "red":
                try:
                    red_count = int(float(v or 0))
                except (TypeError, ValueError):
                    red_count = 0
                break

        # Amber count
        amber_count = 0
        for k, v in gt.items():
            if k.lower() == "amber":
                try:
                    amber_count = int(float(v or 0))
                except (TypeError, ValueError):
                    amber_count = 0
                break

        # Pass count = Green + Dark Green
        pass_count = 0
        for k, v in gt.items():
            if k.lower() in ("green", "dark green", "dark_green"):
                try:
                    pass_count += int(float(v or 0))
                except (TypeError, ValueError):
                    pass

        pass_rate = (pass_count / total_rules * 100) if total_rules > 0 else 0.0

        summaries.append({
            "sheet_name": name,
            "total_rules": total_rules,
            "red": red_count,
            "amber": amber_count,
            "pass": pass_count,
            "fail_total": red_count + amber_count,
            "pass_rate": pass_rate,
            "business_date": business_date,
            "rag_cols": rag_cols,
            "grand_total": gt,
        })

    return summaries


def _get_failing_cdes_per_sheet(scorecard: Dict[str, Any],
                                 status_filter: str = "all") -> List[Dict[str, Any]]:
    """
    Return list of CDEs that are failing across ALL pivot sheets.
    status_filter: "red" | "amber" | "all" (red + amber combined)
    Each item: {sheet_name, cde_name, red, amber, total}
    """
    sheets = scorecard.get("sheets", {})
    sheet_meta = scorecard.get("sheet_meta", {})
    results = []

    for name, meta in sheet_meta.items():
        if not meta.get("is_pivot"):
            continue
        if name not in sheets:
            continue
        df = sheets[name]
        if not isinstance(df, pd.DataFrame) or df.empty:
            continue

        rag_cols = meta.get("rag_columns", [])
        dim_col = meta.get("dim_column", df.columns[0] if len(df.columns) > 0 else "")
        total_col = meta.get("total_column", "")
        red_col = next((c for c in rag_cols if c.lower() == "red"), None)
        amber_col = next((c for c in rag_cols if c.lower() == "amber"), None)

        for _, row in df.iterrows():
            cde_name = str(row.get(dim_col, "")).strip()
            if not cde_name:
                continue

            red_val = 0
            if red_col:
                try:
                    red_val = int(float(pd.to_numeric(row.get(red_col, 0), errors="coerce") or 0))
                except (TypeError, ValueError):
                    red_val = 0

            amber_val = 0
            if amber_col:
                try:
                    amber_val = int(float(pd.to_numeric(row.get(amber_col, 0), errors="coerce") or 0))
                except (TypeError, ValueError):
                    amber_val = 0

            total_val = 0
            if total_col:
                try:
                    total_val = int(float(pd.to_numeric(row.get(total_col, 0), errors="coerce") or 0))
                except (TypeError, ValueError):
                    total_val = 0

            is_failing = (
                (status_filter == "red" and red_val > 0) or
                (status_filter == "amber" and amber_val > 0) or
                (status_filter == "all" and (red_val > 0 or amber_val > 0))
            )

            if is_failing:
                results.append({
                    "sheet_name": name,
                    "cde_name": cde_name,
                    "red": red_val,
                    "amber": amber_val,
                    "total": total_val,
                })

    return results


# ============================================================
# FIX 2: DEDICATED FAILING CDEs HANDLER
# ============================================================

FAILING_CDE_KEYWORDS = [
    "which cde", "which cdes", "failing cde", "failing cdes",
    "cde failing", "cdes failing", "cde fail", "what cde",
    "list cde", "show cde", "red cde", "amber cde",
    "cde with red", "cde with amber", "cde breach",
    "which rules", "failing rules", "failed rules",
    "which are failing", "what is failing", "what is red",
    "show me red", "show me amber", "show failing",
    "breached cde", "non compliant",
]


def _is_failing_cde_query(question: str) -> bool:
    """Return True if the question is asking about which CDEs are failing."""
    q = question.lower()
    return any(kw in q for kw in FAILING_CDE_KEYWORDS)


def _handle_failing_cdes(question: str, scorecard: Dict[str, Any],
                          t0: float) -> Dict[str, Any]:
    """
    Dedicated handler for 'which CDEs are failing?' questions.
    Loops all pivot sheets, returns per-sheet breakdown with named CDEs
    and a table_data list for frontend rendering.
    """
    q = question.lower()

    # Determine which status to filter
    if any(w in q for w in ["red", "fail", "breach", "non compliant"]) and "amber" not in q:
        status_filter = "red"
        status_label = "Red (Failed)"
    elif "amber" in q and "red" not in q:
        status_filter = "amber"
        status_label = "Amber (At Risk)"
    else:
        status_filter = "all"
        status_label = "Red + Amber"

    sheets = scorecard.get("sheets", {})
    sheet_meta = scorecard.get("sheet_meta", {})
    target_sheet = _detect_target_sheet(question, sheets, sheet_meta)

    failing = _get_failing_cdes_per_sheet(scorecard, status_filter)
    if target_sheet:
        failing = [f for f in failing if f["sheet_name"] == target_sheet]

    if not failing:
        summaries = _get_all_pivot_summaries(scorecard)
        sheets_checked = [s["sheet_name"] for s in summaries]
        suffix = (
            f" across {len(sheets_checked)} pivot sheet(s): {', '.join(sheets_checked)}."
            if sheets_checked else "."
        )
        return {
            "tier": 1, "tier_label": "DIRECT",
            "reply": f"No {status_label} failures found{suffix}",
            "table_data": None, "chart": None, "chart_data": None,
            "confidence": 0.95,
            "latency_ms": int((time.time() - t0) * 1000),
            "data_source": "pandas (pivot)", "model_used": "pandas",
        }

    # Group by sheet for readable output
    by_sheet: Dict[str, List[Dict]] = {}
    for item in failing:
        by_sheet.setdefault(item["sheet_name"], []).append(item)

    reply_parts = [f"**{status_label} failures:**\n"]
    for sheet_name, cdes in by_sheet.items():
        reply_parts.append(f"\n**{sheet_name}** ({len(cdes)} CDE(s) failing):")
        for c in cdes:
            detail = []
            if c["red"] > 0:
                detail.append(f"Red: {c['red']}")
            if c["amber"] > 0:
                detail.append(f"Amber: {c['amber']}")
            suffix2 = f" ({', '.join(detail)})" if detail else ""
            reply_parts.append(f"- {c['cde_name']}{suffix2}")

    reply = "\n".join(reply_parts)

    table_data = [
        {
            "Sheet": item["sheet_name"],
            "CDE": item["cde_name"],
            "Red": item["red"],
            "Amber": item["amber"],
            "Total Rules": item["total"],
        }
        for item in failing
    ]

    ms = int((time.time() - t0) * 1000)
    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": table_data,
        "chart": None, "chart_data": None,
        "confidence": 0.97,
        "latency_ms": ms,
        "data_source": f"pandas (pivot) — {len(by_sheet)} sheet(s)",
        "model_used": "pandas",
    }


def _handle_pivot_query(question: str, scorecard: Dict[str, Any], t0: float) -> Optional[Dict[str, Any]]:
    """
    Handle pivot-specific queries with full multi-pivot awareness.
    FIX 1: Uses grand_total from sheet_meta directly. Loops all pivot sheets.
    """
    sheets = scorecard.get("sheets", {})
    sheet_meta = scorecard.get("sheet_meta", {})
    if not sheet_meta:
        return None

    q = question.lower()
    target_name = _detect_target_sheet(question, sheets, sheet_meta)
    all_summaries = _get_all_pivot_summaries(scorecard)
    if not all_summaries:
        return None

    target_summaries = (
        [s for s in all_summaries if s["sheet_name"] == target_name]
        if target_name else all_summaries
    )

    reply = ""
    chart_data = None

    if any(kw in q for kw in ["pass rate", "cde pass", "fail rate", "cde fail",
                                "how many rules", "cde rules", "how many fail",
                                "total rules", "rule count"]):
        if len(target_summaries) == 1:
            s = target_summaries[0]
            bd_line = f" (Business Date: {s['business_date']})" if s["business_date"] else ""
            reply = (
                f"**{s['sheet_name']}**{bd_line}\n\n"
                f"| Metric | Value |\n|---|---|\n"
                f"| Total Rules | {s['total_rules']} |\n"
                f"| Red (Failed) | {s['red']} |\n"
                f"| Amber (At Risk) | {s['amber']} |\n"
                f"| Pass (Green + Dk Green) | {s['pass']} |\n"
                f"| Pass Rate | **{s['pass_rate']:.1f}%** |\n"
            )
        else:
            rows_md = ""
            for s in target_summaries:
                status = "PASS" if s["red"] == 0 and s["amber"] == 0 else (
                    "FAIL" if s["red"] > 0 else "AT RISK"
                )
                rows_md += (
                    f"| {s['sheet_name']} | {s['total_rules']} | {s['red']} | "
                    f"{s['amber']} | {s['pass_rate']:.1f}% | {status} |\n"
                )
            reply = (
                "**Pass Rate across all pivot sheets:**\n\n"
                "| Sheet | Rules | Red | Amber | Pass Rate | Status |\n"
                "|---|---|---|---|---|---|\n"
                + rows_md
            )
        s0 = target_summaries[0]
        chart_data = {
            "chart_type": "bar",
            "title": f"RAG Distribution \u2014 {s0['sheet_name']}",
            "labels": s0["rag_cols"],
            "datasets": [{
                "label": s0["sheet_name"],
                "data": [int(s0["grand_total"].get(c, 0) or 0) for c in s0["rag_cols"]],
                "color": "#1565C0",
            }],
        }

    elif any(kw in q for kw in ["most failure", "most fail", "worst", "highest red", "most red", "top fail"]):
        all_failing = _get_failing_cdes_per_sheet(scorecard, "all")
        if target_name:
            all_failing = [f for f in all_failing if f["sheet_name"] == target_name]
        all_failing.sort(key=lambda x: x["red"] * 2 + x["amber"], reverse=True)
        top5 = all_failing[:5]
        if not top5:
            return None
        rows_md = ""
        for item in top5:
            rows_md += f"| {item['sheet_name']} | {item['cde_name']} | {item['red']} | {item['amber']} |\n"
        reply = (
            "**Top failing CDEs:**\n\n"
            "| Sheet | CDE | Red | Amber |\n|---|---|---|---|\n"
            + rows_md
        )
        chart_data = {
            "chart_type": "bar",
            "title": "Top Failing CDEs",
            "labels": [f"{f['cde_name'][:20]} ({f['sheet_name']})" for f in top5],
            "datasets": [
                {"label": "Red", "data": [f["red"] for f in top5], "color": "#C62828"},
                {"label": "Amber", "data": [f["amber"] for f in top5], "color": "#FF9800"},
            ],
        }

    elif any(kw in q for kw in ["show", "table", "results", "data", "display", "list", "all cde"]):
        if not target_name and target_summaries:
            target_name = target_summaries[0]["sheet_name"]
        if not target_name or target_name not in sheets:
            return None
        df = sheets[target_name]
        meta = sheet_meta.get(target_name, {})
        dim_col = meta.get("dim_column", df.columns[0] if len(df.columns) > 0 else "")
        rag_cols = meta.get("rag_columns", [])
        total_col = meta.get("total_column", "")
        grand_total = meta.get("grand_total", {})
        all_cols = [dim_col] + rag_cols + ([total_col] if total_col else [])
        header = "| " + " | ".join(all_cols) + " |"
        separator = "|" + "|".join(["---"] * len(all_cols)) + "|"
        rows = []
        for _, row in df.iterrows():
            vals = []
            for c in all_cols:
                v = row.get(c, "")
                vals.append(str(int(v)) if isinstance(v, (int, float)) and pd.notna(v) else str(v))
            rows.append("| " + " | ".join(vals) + " |")
        if grand_total:
            gt_vals = ["**Grand Total**"]
            for c in all_cols[1:]:
                gt_vals.append(f"**{grand_total.get(c, 0)}**")
            rows.append("| " + " | ".join(gt_vals) + " |")
        reply = (
            f"**{target_name}** ({len(df)} CDEs):\n\n"
            + header + "\n" + separator + "\n"
            + "\n".join(rows)
        )
        chart_data = {
            "chart_type": "bar",
            "title": f"RAG Distribution \u2014 {target_name}",
            "labels": rag_cols,
            "datasets": [{
                "label": target_name,
                "data": [int(grand_total.get(c, 0) or 0) for c in rag_cols],
                "color": "#1565C0",
            }],
        }

    else:
        parts = ["**Pivot Sheet Summary:**\n"]
        for s in target_summaries:
            status = "PASS" if s["red"] == 0 and s["amber"] == 0 else "FAIL"
            parts.append(
                f"- **{s['sheet_name']}**: {s['total_rules']} rules, "
                f"Red: {s['red']}, Amber: {s['amber']}, "
                f"Pass Rate: {s['pass_rate']:.1f}% [{status}]"
            )
        reply = "\n".join(parts)

    if not reply:
        return None

    ms = int((time.time() - t0) * 1000)
    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": None,
        "chart": None,
        "chart_data": chart_data,
        "confidence": 0.93,
        "latency_ms": ms,
        "data_source": f"Pivot: {len(target_summaries)} sheet(s)",
        "model_used": "pandas",
    }


def _rag_chart_colors(rag_cols: List[str]) -> List[str]:
    """Map RAG column names to their colors."""
    color_map = {
        "amber": "#D97706", "dark green": "#1D4E2B", "green": "#047857", "red": "#C8102E",
        "dark_green": "#1D4E2B", "row_total": "#003B6F",
    }
    return [color_map.get(c.lower(), "#6B7280") for c in rag_cols]


def _handle_proactive_summary(scorecard: Dict[str, Any], t0: float) -> Dict[str, Any]:
    """
    Generate a proactive summary looping ALL pivot sheets (FIX 1b).
    Uses grand_total from sheet_meta directly.
    """
    display_title = scorecard.get("display_title", scorecard.get("display_name", "Scorecard"))
    months = scorecard.get("months", {})
    all_summaries = _get_all_pivot_summaries(scorecard)
    parts = []

    if all_summaries:
        primary = next(
            (s for s in all_summaries if "consol" in s["sheet_name"].lower()),
            all_summaries[0]
        )
        bd = primary["business_date"]
        red_all = sum(s["red"] for s in all_summaries)
        amber_all = sum(s["amber"] for s in all_summaries)

        parts.append(
            f"{display_title}: {primary['total_rules']} total CDE rules as of {bd}."
        )
        if red_all == 0 and amber_all == 0:
            parts.append(f"All rules passing across {len(all_summaries)} pivot sheet(s).")
        else:
            parts.append(
                f"{red_all + amber_all} rules have issues "
                f"({red_all} Red, {amber_all} Amber) "
                f"across {len(all_summaries)} pivot sheet(s)."
            )
        for s in all_summaries:
            fail_total = s["red"] + s["amber"]
            if fail_total > 0:
                parts.append(
                    f"{s['sheet_name']}: {fail_total} failing "
                    f"({s['red']} Red, {s['amber']} Amber), "
                    f"{s['pass_rate']:.1f}% pass rate."
                )
            else:
                parts.append(
                    f"{s['sheet_name']}: All {s['total_rules']} rules "
                    f"passing ({s['pass_rate']:.1f}%)."
                )
        failing_red = _get_failing_cdes_per_sheet(scorecard, "red")
        if failing_red:
            top3 = failing_red[:3]
            cde_names = ", ".join(
                f"{f['cde_name']} ({f['sheet_name']})" for f in top3
            )
            parts.append(f"Top Red failures: {cde_names}.")
    else:
        df = scorecard.get("df")
        if df is not None:
            parts.append(f"{display_title}: {len(df):,} records across {len(df.columns)} columns.")

    if len(months) > 1:
        month_keys = sorted(months.keys())
        parts.append(
            f"{len(months)} months of data available "
            f"({month_keys[0]} to {month_keys[-1]}). "
            "Use the MoM Compare tab for trends."
        )

    reply = " ".join(parts)
    ms = int((time.time() - t0) * 1000)
    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": None, "chart": None, "chart_data": None,
        "confidence": 0.95, "latency_ms": ms,
        "data_source": "pandas (proactive)", "model_used": "pandas",
    }


# ============================================================
# TIER 1: PANDAS DIRECT
# ============================================================

T1_KEYWORDS = {
    "list": ["give me", "list", "show me", "show all", "display", "what are", "get all", "get me"],
    "count": ["how many", "count", "total", "number of"],
    "filter": ["filter", "where", "which"],
    "rank": ["top", "bottom", "highest", "lowest", "max", "min", "best", "worst"],
    "aggregate": ["sum", "average", "mean", "avg", "group by", "group", "aggregate"],
    "distribution": ["distribution", "breakdown", "split", "rag status", "pass rate", "status breakdown"],
}


def _detect_t1_intent(question: str) -> Optional[str]:
    """Detect if the question can be answered by pandas. Returns intent or None."""
    q = question.lower().strip()
    for intent, keywords in T1_KEYWORDS.items():
        for kw in keywords:
            if kw in q:
                return intent
    return None


def try_pandas_query(question: str, df: pd.DataFrame, schema: Dict, sheets: Dict = None,
                     sheet_meta: Dict = None) -> Optional[Dict[str, Any]]:
    """
    Attempt to answer the question using pandas operations.
    Returns result dict with reply, data, confidence -- or None if cannot answer.
    """
    if df is None or df.empty:
        return None

    t0 = time.time()
    q = question.lower().strip()

    # Check for proactive summary
    if "proactive summary" in q or "proactive insight" in q:
        scorecard_stub = {"df": df, "sheets": sheets or {}, "sheet_meta": sheet_meta or {},
                          "display_title": "", "months": {}}
        return _handle_proactive_summary(scorecard_stub, t0)

    # FIX 2: Failing CDEs handler before generic pivot
    if sheet_meta and _is_failing_cde_query(q):
        scorecard_stub = {"sheets": sheets or {}, "sheet_meta": sheet_meta}
        result = _handle_failing_cdes(question, scorecard_stub, t0)
        if result:
            return result

    # FIX 1: Pivot-specific with multi-pivot awareness
    if sheet_meta and _is_pivot_query(q):
        scorecard_stub = {"sheets": sheets or {}, "sheet_meta": sheet_meta}
        result = _handle_pivot_query(question, scorecard_stub, t0)
        if result:
            return result

    # Check for sheet-specific queries
    if sheets and sheet_meta:
        target_sheet = _detect_target_sheet(question, sheets, sheet_meta)
        if target_sheet and target_sheet in sheets:
            target_df = sheets[target_sheet]
            target_meta = sheet_meta.get(target_sheet, {})
            if isinstance(target_df, pd.DataFrame) and not target_df.empty:
                if target_meta.get("is_pivot"):
                    scorecard_stub = {"sheets": sheets, "sheet_meta": sheet_meta}
                    result = _handle_pivot_query(question, scorecard_stub, t0)
                    if result:
                        return result
                return _query_pivot_sheet(question, target_df, target_sheet, t0)

        # Check for sheet comparison
        pair = _detect_sheet_comparison(question, sheets, sheet_meta)
        if pair:
            return _compare_sheets(question, sheets, pair, t0)
    elif sheets:
        target_sheet = _detect_target_sheet(question, sheets)
        if target_sheet and target_sheet in sheets:
            target_df = sheets[target_sheet]
            if isinstance(target_df, pd.DataFrame) and not target_df.empty:
                return _query_pivot_sheet(question, target_df, target_sheet, t0)

    intent = _detect_t1_intent(question)
    if intent is None:
        return None

    columns = list(df.columns)
    rag_cols = schema.get("rag_status", [])
    id_cols = schema.get("identifier", [])
    dim_cols = schema.get("dimension", [])
    measure_cols = schema.get("measure", [])

    reply = ""
    table_data = None
    chart = None
    chart_data = None
    confidence = 0.85

    try:
        # -- LIST / SHOW ALL queries --
        if intent == "list":
            col_ref = _extract_column_ref(question, columns)
            if col_ref:
                unique_vals = df[col_ref].dropna().unique().tolist()
                unique_vals = [str(v) for v in unique_vals if str(v).strip()]
                count = len(unique_vals)

                if count <= 20:
                    items = "\n".join(f"{i+1}. {v}" for i, v in enumerate(unique_vals))
                    reply = f"**{count} unique values in '{col_ref}':**\n\n{items}"
                else:
                    shown = "\n".join(f"{i+1}. {v}" for i, v in enumerate(unique_vals[:20]))
                    reply = f"**{count} unique values in '{col_ref}'** (showing first 20):\n\n{shown}\n\n...and {count - 20} more."

                confidence = 0.95
            elif any(w in q for w in ["fail", "red", "breach"]) and rag_cols:
                rag_col = rag_cols[0]
                fails = df[df[rag_col].str.lower() == "red"]
                reply = f"Found **{len(fails)}** failing (Red) records."
                table_data = fails.head(20).fillna("").to_dict(orient="records")
                confidence = 0.92
            elif any(w in q for w in ["column", "columns", "fields", "field"]):
                items = "\n".join(f"{i+1}. {c}" for i, c in enumerate(columns))
                reply = f"**{len(columns)} columns:**\n\n{items}"
                confidence = 0.95
            else:
                return None

        # -- COUNT queries --
        elif intent == "count":
            if any(w in q for w in ["fail", "red", "breach"]):
                if rag_cols:
                    rag_col = rag_cols[0]
                    fail_count = len(df[df[rag_col].str.lower().isin(["red"])])
                    total = len(df)
                    reply = f"There are **{fail_count:,}** failed (Red) records out of **{total:,}** total records."
                    confidence = 0.95
                else:
                    return None
            elif any(w in q for w in ["pass", "green", "dark green"]):
                if rag_cols:
                    rag_col = rag_cols[0]
                    pass_count = len(df[df[rag_col].str.lower().isin(["green", "dark green"])])
                    total = len(df)
                    reply = f"There are **{pass_count:,}** passing (Green/Dark Green) records out of **{total:,}** total."
                    confidence = 0.95
                else:
                    return None
            else:
                col_ref = _extract_column_ref(question, columns)
                if col_ref:
                    unique_count = df[col_ref].nunique()
                    reply = f"There are **{unique_count:,}** unique values in '{col_ref}'."
                    confidence = 0.90
                else:
                    reply = f"The dataset contains **{len(df):,}** total records across **{len(columns)}** columns."
                    confidence = 0.80

        # -- FILTER queries --
        elif intent == "filter":
            col_ref = _extract_column_ref(question, columns)
            if col_ref:
                val_ref = _extract_value_ref(question, df, col_ref)
                if val_ref:
                    filtered = df[df[col_ref].astype(str).str.lower() == val_ref.lower()]
                    reply = f"Found **{len(filtered):,}** records where '{col_ref}' = '{val_ref}'."
                    table_data = filtered.head(20).fillna("").to_dict(orient="records")
                    confidence = 0.92
                else:
                    vals = df[col_ref].value_counts().head(10).to_dict()
                    reply = f"Top values in '{col_ref}':\n" + "\n".join(f"- **{k}**: {v:,}" for k, v in vals.items())
                    confidence = 0.85
            elif any(w in q for w in ["fail", "red"]) and rag_cols:
                rag_col = rag_cols[0]
                fails = df[df[rag_col].str.lower() == "red"]
                reply = f"Found **{len(fails):,}** failing (Red) records."
                table_data = fails.head(20).fillna("").to_dict(orient="records")
                confidence = 0.90
            else:
                return None

        # -- RANK queries --
        elif intent == "rank":
            col_ref = _extract_column_ref(question, measure_cols + columns)
            if col_ref and pd.api.types.is_numeric_dtype(df[col_ref]):
                is_top = any(w in q for w in ["top", "highest", "max", "best"])
                n = 5
                nums = re.findall(r"\d+", question)
                if nums:
                    n = min(int(nums[0]), 20)
                sorted_df = df.sort_values(col_ref, ascending=not is_top).head(n)
                direction = "highest" if is_top else "lowest"
                reply = f"**{direction.capitalize()} {n}** records by '{col_ref}':"
                table_data = sorted_df.fillna("").to_dict(orient="records")
                confidence = 0.90
            else:
                return None

        # -- AGGREGATE queries --
        elif intent == "aggregate":
            col_ref = _extract_column_ref(question, measure_cols)
            group_col = _extract_column_ref(question, dim_cols)
            if col_ref and group_col:
                if "sum" in q:
                    agg = df.groupby(group_col)[col_ref].sum().reset_index()
                elif any(w in q for w in ["average", "mean", "avg"]):
                    agg = df.groupby(group_col)[col_ref].mean().reset_index()
                else:
                    agg = df.groupby(group_col)[col_ref].sum().reset_index()
                reply = f"Aggregation of '{col_ref}' grouped by '{group_col}':"
                table_data = agg.head(20).to_dict(orient="records")

                # Build chart only if we have data
                if len(agg) > 0:
                    labels = agg[group_col].astype(str).tolist()[:15]
                    values = [round(float(v), 2) for v in agg[col_ref].head(15)]
                    chart = _build_chart("bar", f"{'Sum' if 'sum' in q else 'Average'} of {col_ref} by {group_col}", labels, values)

                confidence = 0.88
            elif col_ref:
                total = df[col_ref].sum()
                avg = df[col_ref].mean()
                reply = f"'{col_ref}': Sum = **{total:,.2f}**, Average = **{avg:,.2f}**, Count = **{df[col_ref].count():,}**"
                confidence = 0.85
            else:
                return None

        # -- DISTRIBUTION queries --
        elif intent == "distribution":
            if rag_cols and any(w in q for w in ["rag", "status", "pass", "fail", "distribution", "breakdown"]):
                rag_col = rag_cols[0]
                dist = df[rag_col].value_counts().to_dict()
                total = sum(dist.values())
                reply = "**RAG Status Distribution:**\n" + "\n".join(
                    f"- {k}: **{v:,}** ({v/total*100:.1f}%)" for k, v in dist.items()
                )
                # Build chart
                labels = list(dist.keys())
                values = list(dist.values())
                if labels:
                    chart = _build_rag_chart(labels, values)
                confidence = 0.95
            else:
                col_ref = _extract_column_ref(question, dim_cols + columns)
                if col_ref:
                    dist = df[col_ref].value_counts().head(15).to_dict()
                    reply = f"**Distribution of '{col_ref}':**\n" + "\n".join(
                        f"- {k}: **{v:,}**" for k, v in dist.items()
                    )
                    labels = list(dist.keys())
                    values = list(dist.values())
                    if labels:
                        chart = _build_chart("bar", f"Distribution of {col_ref}", [str(l) for l in labels], values)
                    confidence = 0.85
                else:
                    return None

        # Auto-enrich with chart from list/filter results that have no chart yet
        if intent in ("list", "filter") and table_data and chart is None and chart_data is None:
            cols = list(table_data[0].keys()) if table_data else []
            # Find a numeric column to chart against the first text column
            label_key = cols[0] if cols else None
            value_key = next((c for c in cols[1:] if all(
                isinstance(table_data[i].get(c, ""), (int, float)) or
                str(table_data[i].get(c, "")).replace(".", "").lstrip("-").isdigit()
                for i in range(min(3, len(table_data)))
            )), None)
            if label_key and value_key:
                chart = _auto_chart_from_table(table_data, label_key, value_key,
                                               f"{value_key} by {label_key}")

        else:
            return None

        ms = int((time.time() - t0) * 1000)
        log.info(f"T1 PANDAS: intent={intent}, conf={confidence:.2f}, {ms}ms")

        return {
            "tier": 1,
            "tier_label": "DIRECT",
            "reply": reply,
            "table_data": table_data,
            "chart": chart,
            "chart_data": chart_data,
            "confidence": confidence,
            "latency_ms": ms,
            "data_source": f"pandas ({len(df):,} rows)",
            "model_used": "pandas",
        }

    except Exception as e:
        log.warning(f"T1 pandas query failed: {e}")
        return None


def _query_pivot_sheet(question: str, df: pd.DataFrame, sheet_name: str, t0: float) -> Dict[str, Any]:
    """Query a specific pivot sheet and format nicely."""
    label = sheet_name

    # Build a clean summary table
    table_data = df.head(30).fillna("").to_dict(orient="records")

    # Try to build a chart from the pivot
    chart = None
    chart_data = None
    if len(df.columns) >= 2:
        first_col = df.columns[0]
        numeric_cols = [c for c in df.columns[1:] if pd.api.types.is_numeric_dtype(df[c])]
        if numeric_cols and len(df) > 0:
            labels = df[first_col].astype(str).tolist()[:15]
            datasets = []
            COLORS = ["#003B6F", "#C8102E", "#047857", "#D97706", "#6D28D9", "#0891B2"]
            for i, nc in enumerate(numeric_cols[:6]):
                datasets.append({
                    "label": str(nc),
                    "data": [round(float(v), 2) if pd.notna(v) else 0 for v in df[nc].head(15)],
                    "color": COLORS[i % len(COLORS)],
                })
            chart = {
                "chart_type": "bar",
                "title": f"{label} Pivot Data",
                "labels": labels,
                "datasets": datasets,
            }

    reply = f"**{label}** ({len(df)} rows, {len(df.columns)} columns):"
    ms = int((time.time() - t0) * 1000)

    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": table_data,
        "chart": chart,
        "chart_data": chart_data,
        "confidence": 0.92,
        "latency_ms": ms,
        "data_source": f"Sheet: {sheet_name} ({len(df)} rows)",
        "model_used": "pandas",
    }


def _compare_sheets(question: str, sheets: Dict, pair: Tuple[str, str], t0: float) -> Dict[str, Any]:
    """Compare two pivot sheets side by side."""
    name_a, name_b = pair
    df_a = sheets[name_a]
    df_b = sheets[name_b]

    reply = f"**Comparison: {name_a} vs {name_b}**\n\n"
    reply += f"- {name_a}: {len(df_a)} rows, {len(df_a.columns)} columns\n"
    reply += f"- {name_b}: {len(df_b)} rows, {len(df_b.columns)} columns\n"

    # Compare common numeric columns
    common_cols = [c for c in df_a.columns if c in df_b.columns and pd.api.types.is_numeric_dtype(df_a[c])]
    if common_cols:
        reply += "\n**Numeric column comparison:**\n"
        for col in common_cols[:5]:
            sum_a = df_a[col].sum()
            sum_b = df_b[col].sum()
            delta = sum_b - sum_a
            reply += f"- {col}: {name_a}={sum_a:,.0f}, {name_b}={sum_b:,.0f} (delta: {delta:+,.0f})\n"

    ms = int((time.time() - t0) * 1000)
    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": None, "chart": None, "chart_data": None,
        "confidence": 0.88,
        "latency_ms": ms,
        "data_source": f"Sheets: {name_a} vs {name_b}",
        "model_used": "pandas",
    }


# ============================================================
# CHART BUILDERS (with empty guard)
# ============================================================

CITI_COLORS = ["#003B6F", "#0057A8", "#C8102E", "#047857", "#D97706", "#6D28D9", "#0891B2", "#BE185D"]
RAG_COLORS = {
    "red": "#C8102E", "amber": "#D97706", "green": "#047857",
    "dark green": "#065F46", "dark_green": "#065F46",
}


def _build_chart(chart_type: str, title: str, labels: List, values: List, color: str = None) -> Optional[Dict]:
    """Build a chart dict, returning None if data is empty."""
    if not labels or not values or all(v == 0 for v in values):
        return None
    return {
        "chart_type": chart_type,
        "title": title,
        "labels": [str(l) for l in labels],
        "datasets": [{
            "label": title,
            "data": [round(float(v), 2) if v is not None else 0 for v in values],
            "color": color or CITI_COLORS[0],
        }],
    }


def _build_rag_chart(labels: List[str], values: List[int]) -> Optional[Dict]:
    """Build a RAG distribution chart with proper colors."""
    if not labels or not values:
        return None

    colors = []
    for label in labels:
        lbl = str(label).lower().strip()
        colors.append(RAG_COLORS.get(lbl, "#6B7280"))

    return {
        "chart_type": "doughnut",
        "title": "RAG Status Distribution",
        "labels": [str(l) for l in labels],
        "data": values,
        "colors": colors,
    }


# ============================================================
# TIER 2: SEMANTIC SEARCH
# ============================================================

T2_KEYWORDS = [
    "what is", "how does", "explain", "process", "architecture",
    "steps", "logic", "formula", "calculation", "workflow",
    "module", "define", "definition", "document", "policy",
    "procedure", "guideline", "standard", "requirement",
    "describe", "overview", "methodology", "approach",
]


def _detect_t2_intent(question: str) -> bool:
    """Check if question looks like a documentation/semantic query."""
    q = question.lower()
    return any(kw in q for kw in T2_KEYWORDS)


def _search_scorecard_metadata(question: str, scorecard: Dict[str, Any]) -> Optional[List[Dict]]:
    """
    FIX 3: Search scorecard questions, narrative, and anomalies when no docs uploaded.
    Returns list of {content, score, source, section} sorted by score.
    """
    q = question.lower()
    stop = {"the", "a", "an", "is", "are", "in", "of", "for", "what", "how",
            "show", "list", "me", "i", "do", "does", "it", "this"}
    q_words = set(re.findall(r"[a-z]+", q)) - stop
    results = []

    for sq in scorecard.get("questions", []):
        sq_words = set(re.findall(r"[a-z]+", sq.lower())) - stop
        overlap = len(q_words & sq_words)
        if overlap >= 2:
            results.append({
                "content": sq, "score": overlap / max(len(q_words), 1),
                "source": "Scorecard Questions", "section": "Suggested Questions",
            })

    narrative = scorecard.get("narrative", "")
    if narrative and len(narrative) > 10:
        n_words = set(re.findall(r"[a-z]+", narrative.lower())) - stop
        overlap = len(q_words & n_words)
        if overlap >= 2:
            results.append({
                "content": narrative, "score": overlap / max(len(q_words), 1),
                "source": "Scorecard Narrative", "section": "Summary",
            })

    for a in scorecard.get("anomalies", []):
        text = f"{a.get('description', '')} {a.get('context', '')}".strip()
        if not text:
            continue
        text_words = set(re.findall(r"[a-z]+", text.lower())) - stop
        overlap = len(q_words & text_words)
        if overlap >= 2:
            results.append({
                "content": f"{a.get('severity', '').upper()}: {text}",
                "score": overlap / max(len(q_words), 1),
                "source": "Anomaly Signals",
                "section": f"Severity: {a.get('severity', 'unknown')}",
            })

    if not results:
        return None
    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:5]


def try_semantic_search(question: str, scorecard: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Attempt to answer using TF-IDF indexed documents.
    FIX 3: Falls back to scorecard metadata when no docs or score too low.
    FIX 3: TF-IDF threshold raised from 0.08 to 0.20.
    """
    from backend.services.document_service import search_documents

    vectorizer = scorecard.get("doc_index")
    chunks = scorecard.get("doc_chunks", [])
    t0 = time.time()

    if vectorizer and chunks:
        results = search_documents(question, vectorizer, chunks)
        if results and results[0].get("score", 0) >= 0.20:
            ms = int((time.time() - t0) * 1000)
            top_score = results[0]["score"]
            confidence = min(top_score + 0.3, 0.95)
            log.info(f"T2 TF-IDF: score={top_score:.3f}, conf={confidence:.2f}, {ms}ms")
            return {
                "tier": 2, "tier_label": "SEMANTIC",
                "raw_chunks": results[:5],
                "confidence": confidence,
                "latency_ms": ms,
                "data_source": f"TF-IDF ({len(chunks)} chunks)",
                "model_used": "scikit-learn TfidfVectorizer",
                "is_metadata_fallback": False,
            }

    meta_results = _search_scorecard_metadata(question, scorecard)
    if meta_results:
        ms = int((time.time() - t0) * 1000)
        top_score = meta_results[0].get("score", 0)
        confidence = min(0.55 + top_score * 0.1, 0.80)
        log.info(f"T2 METADATA: score={top_score:.3f}, conf={confidence:.2f}, {ms}ms")
        return {
            "tier": 2, "tier_label": "SEMANTIC",
            "raw_chunks": meta_results,
            "confidence": confidence,
            "latency_ms": ms,
            "data_source": "Scorecard Metadata (questions/narrative/anomalies)",
            "model_used": "keyword-overlap",
            "is_metadata_fallback": True,
        }

    return None


def _format_t2_through_t3(question: str, t2_result: Dict, scorecard: Dict) -> Dict[str, Any]:
    """
    Pass T2 semantic results through T3 (Gemini) for clean formatting.
    Falls back to local formatting if Gemini is unavailable.
    """
    chunks = t2_result.get("raw_chunks", [])
    t0 = time.time()

    # Build context from chunks
    chunk_texts = []
    sources = []
    is_metadata = t2_result.get("is_metadata_fallback", False)
    for c in chunks:
        chunk_texts.append(c.get("content", ""))
        src_label = c.get("doc_name", c.get("source", "Scorecard Metadata"))
        src = f"{src_label} (Section: {c.get('section', 'N/A')})"
        if src not in sources:
            sources.append(src)

    context = "\n\n---\n\n".join(chunk_texts)
    ctx_label = "scorecard metadata" if is_metadata else "document excerpts"

    # Try T3 formatting
    try:
        from backend.services.vertex_service import chat as vertex_chat

        system_prompt = f"""You are a professional data analyst for an enterprise intelligence platform.
Based on the following {ctx_label}, provide a clear, structured answer to the user's question.

FORMAT RULES:
- No raw markdown artifacts, no table separators like | --- |, no section headers from the source
- Use clean HTML formatting: <strong>, <br>, <ol>/<li>, <table>
- Numbers with commas (1,000 not 1000), percentages with 2 decimal places
- Go straight to the answer, no preamble
- Keep response concise and professional

User question: {question}

Context:
{context}"""

        reply, chart, in_tok, out_tok, resp_ms = vertex_chat(
            system_prompt,
            messages=[{"role": "user", "content": question}]
        )
        ms = int((time.time() - t0) * 1000)

        # Append source attribution
        source_line = "<br><br><small style='color:#6B7280'>Sources: " + ", ".join(sources) + "</small>"
        reply = reply + source_line

        log.info(f"T2+T3: formatted semantic results via Gemini, {ms}ms")

        return {
            "tier": 2,
            "tier_label": "SEMANTIC+LLM",
            "reply": reply,
            "table_data": None,
            "chart": chart if _validate_chart(chart) else None,
            "chart_data": None,
            "confidence": t2_result["confidence"],
            "latency_ms": ms,
            "data_source": t2_result["data_source"],
            "model_used": "TF-IDF + Gemini",
        }

    except Exception as e:
        log.info(f"T2+T3 fallback: Gemini unavailable ({e}), using local formatting")
        return _format_t2_locally(question, chunks, sources, t2_result, t0)


def _format_t2_locally(question: str, chunks: List, sources: List, t2_result: Dict, t0: float) -> Dict[str, Any]:
    """Format T2 results locally when Gemini is unavailable. Clean up raw text."""
    reply_parts = []
    for i, chunk in enumerate(chunks[:3], 1):
        content = chunk.get("content", "")
        # Clean up raw markdown/table artifacts
        content = re.sub(r'\|\s*---\s*\|', '', content)
        content = re.sub(r'\|', ' ', content)
        content = re.sub(r'#{1,3}\s+', '', content)
        content = re.sub(r'\*\*', '', content)
        content = re.sub(r'\n{3,}', '\n\n', content)
        content = content.strip()

        if content:
            # Truncate long chunks
            if len(content) > 400:
                content = content[:400] + "..."
            reply_parts.append(content)

    reply = "\n\n".join(reply_parts)

    # Append sources
    reply += "\n\n---\nSources: " + ", ".join(sources)

    ms = int((time.time() - t0) * 1000)

    return {
        "tier": 2,
        "tier_label": "SEMANTIC",
        "reply": reply,
        "table_data": None,
        "chart": None,
        "chart_data": None,
        "confidence": t2_result["confidence"],
        "latency_ms": ms,
        "data_source": t2_result["data_source"],
        "model_used": "scikit-learn TfidfVectorizer",
    }


def _validate_chart(chart: Optional[Dict]) -> bool:
    """Validate that a chart has actual data. Returns False for empty charts."""
    if not chart:
        return False
    if chart.get("datasets"):
        for ds in chart["datasets"]:
            data = ds.get("data", [])
            if data and any(v != 0 and v is not None for v in data):
                return True
    if chart.get("data"):
        return any(v != 0 and v is not None for v in chart["data"])
    if chart.get("labels") and not chart.get("datasets") and not chart.get("data"):
        return False
    return False


# ============================================================
# TIER 3: LLM (GEMINI)
# ============================================================

def try_llm_query(question: str, scorecard: Dict[str, Any],
                  t1_context: Optional[str] = None, t2_context: Optional[str] = None,
                  chat_context: Optional[str] = None) -> Dict[str, Any]:
    """
    Call Vertex AI Gemini with context from T1, T2, and chat history.
    Always returns a result (this is the fallback tier).
    """
    from backend.services.vertex_service import chat as vertex_chat

    df = scorecard.get("df")
    schema = scorecard.get("schema", {})
    sheet_meta = scorecard.get("sheet_meta", {})

    t0 = time.time()

    # Build context
    preview = ""
    if df is not None:
        preview = df.head(5).to_csv(index=False)

    context_parts = [f"Data Schema: {json.dumps(schema)}"]
    context_parts.append(f"Data Preview (first 5 rows):\n{preview}")

    # Include pivot context
    if sheet_meta:
        pivot_info = []
        for sname, smeta in sheet_meta.items():
            if smeta.get("is_pivot"):
                gt = smeta.get("grand_total", {})
                pivot_info.append(
                    f"Pivot sheet '{sname}': business_date={smeta.get('business_date', 'N/A')}, "
                    f"grand_total={json.dumps(gt)}, rag_columns={smeta.get('rag_columns', [])}"
                )
        if pivot_info:
            context_parts.append("Pivot Sheets:\n" + "\n".join(pivot_info))

    display_title = scorecard.get("display_title", scorecard.get("display_name", ""))
    reporting_month = scorecard.get("reporting_month", "")
    legal_entity = scorecard.get("legal_entity", "")
    if display_title:
        context_parts.append(f"Scorecard: {display_title}, Reporting Month: {reporting_month}, Entity: {legal_entity}")

    if t1_context:
        context_parts.append(f"Pandas Analysis Result:\n{t1_context}")
    if t2_context:
        context_parts.append(f"Relevant Documentation:\n{t2_context}")
    if chat_context:
        context_parts.append(f"Previous Conversations:\n{chat_context}")

    system_prompt = f"""You are an AI assistant for the B&I CDE Intelligence Platform at Citi.
You answer questions about data quality scorecards, KRIs, and CDE exception reports.

FORMAT RULES:
- Use clean HTML: <strong>, <br>, <table>, <ol>/<li>. No raw markdown.
- Numbers with commas (1,000). Percentages with % and 2 decimal places.
- Go straight to the answer, no preamble.
- If generating a chart, ensure it has actual data labels and values.
- Keep responses concise and professional.
- When answering, be specific. Cite exact numbers.
- Format tables using markdown pipe syntax.
- Never say I don't know if data is available.

{chr(10).join(context_parts)}

User Question: {question}"""

    try:
        reply, chart, in_tok, out_tok, resp_ms = vertex_chat(
            system_prompt,
            messages=[{"role": "user", "content": question}]
        )
        ms = int((time.time() - t0) * 1000)

        # Validate chart -- never return empty
        if not _validate_chart(chart):
            chart = None

        log.info(f"T3 GEMINI: in={in_tok} out={out_tok}, {ms}ms")

        return {
            "tier": 3,
            "tier_label": "LLM",
            "reply": reply,
            "table_data": None,
            "chart": chart,
            "chart_data": None,
            "confidence": 0.75,
            "latency_ms": ms,
            "data_source": f"Vertex AI Gemini (in={in_tok}, out={out_tok})",
            "model_used": "gemini-1.5-pro",
        }

    except Exception as e:
        ms = int((time.time() - t0) * 1000)
        log.error(f"T3 Gemini failed: {e}")
        return {
            "tier": 3,
            "tier_label": "LLM",
            "reply": f"Gemini AI is not available: {str(e)}. Please ensure vertex_util.py is configured with COIN auth.",
            "table_data": None,
            "chart": None,
            "chart_data": None,
            "confidence": 0.0,
            "latency_ms": ms,
            "data_source": "Vertex AI (unavailable)",
            "model_used": "gemini-1.5-pro (offline)",
        }




# ============================================================
# T1 IMPROVEMENT 1: MONTH-OVER-MONTH CDE COMPARISON
# ============================================================

MOM_CDE_KEYWORDS = [
    "better than last month", "worse than last month", "deteriorate",
    "improved", "improvement", "worsened", "changed since", "delta since",
    "compare this month", "compare last month", "vs last month",
    "vs previous month", "month on month cde", "mom cde",
    "which cde changed", "cde trend", "cde movement",
    "getting worse", "getting better",
]


def _is_mom_cde_query(question: str) -> bool:
    q = question.lower()
    return any(kw in q for kw in MOM_CDE_KEYWORDS)


def _handle_mom_cde_comparison(question: str, scorecard: Dict[str, Any],
                                 t0: float) -> Optional[Dict[str, Any]]:
    """
    Compare CDE pass rates between the two most recent months.
    Identifies which CDEs improved, worsened, or are new/removed.
    Works entirely from scorecard.months using pivot grand_total and per-row data.
    """
    months = scorecard.get("months", {})
    sheet_meta = scorecard.get("sheet_meta", {})

    if len(months) < 2:
        ms = int((time.time() - t0) * 1000)
        return {
            "tier": 1, "tier_label": "DIRECT",
            "reply": "Only one month of data available. Upload a second month to enable month-over-month CDE comparison.",
            "table_data": None, "chart": None, "chart_data": None,
            "confidence": 0.90, "latency_ms": ms,
            "data_source": "pandas", "model_used": "pandas",
        }

    sorted_months = sorted(months.keys())
    label_a = sorted_months[-2]
    label_b = sorted_months[-1]
    month_a = months[label_a]
    month_b = months[label_b]

    # Find first pivot sheet present in both months
    sheets = scorecard.get("sheets", {})
    pivot_sheet = None
    for name, meta in sheet_meta.items():
        if meta.get("is_pivot"):
            sheets_a = month_a.get("sheets", {})
            sheets_b = month_b.get("sheets", {})
            if name in sheets_a and name in sheets_b:
                pivot_sheet = name
                break

    if not pivot_sheet:
        return None

    meta = sheet_meta.get(pivot_sheet, {})
    dim_col = meta.get("dim_column", "")
    rag_cols = meta.get("rag_columns", [])
    total_col = meta.get("total_column", "")

    if not dim_col or not rag_cols:
        return None

    df_a = month_a["sheets"][pivot_sheet]
    df_b = month_b["sheets"][pivot_sheet]

    def get_pass_rate(df: pd.DataFrame, cde: str) -> Optional[float]:
        row = df[df[dim_col].astype(str).str.strip() == cde]
        if row.empty:
            return None
        r = row.iloc[0]
        total = int(pd.to_numeric(r.get(total_col, 0), errors="coerce") or 0) if total_col else             sum(int(pd.to_numeric(r.get(c, 0), errors="coerce") or 0) for c in rag_cols)
        pass_v = sum(
            int(pd.to_numeric(r.get(c, 0), errors="coerce") or 0)
            for c in rag_cols
            if c.lower() in ("green", "dark green", "dark_green")
        )
        return (pass_v / total * 100) if total > 0 else 0.0

    cdes_a = set(df_a[dim_col].astype(str).str.strip().tolist())
    cdes_b = set(df_b[dim_col].astype(str).str.strip().tolist())
    common = sorted(cdes_a & cdes_b)
    new_cdes = sorted(cdes_b - cdes_a)
    removed_cdes = sorted(cdes_a - cdes_b)

    improved, worsened, unchanged = [], [], []
    for cde in common:
        pr_a = get_pass_rate(df_a, cde)
        pr_b = get_pass_rate(df_b, cde)
        if pr_a is None or pr_b is None:
            continue
        delta = pr_b - pr_a
        entry = {"cde": cde, "pr_a": round(pr_a, 1), "pr_b": round(pr_b, 1), "delta": round(delta, 1)}
        if delta > 0.5:
            improved.append(entry)
        elif delta < -0.5:
            worsened.append(entry)
        else:
            unchanged.append(entry)

    improved.sort(key=lambda x: -x["delta"])
    worsened.sort(key=lambda x: x["delta"])

    # Build reply
    parts = [f"**CDE Month-over-Month: {label_a} vs {label_b}** ({pivot_sheet})\n"]

    if worsened:
        parts.append(f"\n**Deteriorated ({len(worsened)} CDEs):**")
        for e in worsened:
            parts.append(f"- {e['cde']}: {e['pr_a']}% → {e['pr_b']}% ({e['delta']:+.1f}pp)")

    if improved:
        parts.append(f"\n**Improved ({len(improved)} CDEs):**")
        for e in improved:
            parts.append(f"- {e['cde']}: {e['pr_a']}% → {e['pr_b']}% (+{e['delta']:.1f}pp)")

    if unchanged:
        parts.append(f"\n**Unchanged: {len(unchanged)} CDEs** (delta < 0.5pp)")

    if new_cdes:
        parts.append(f"\n**New CDEs in {label_b}:** {', '.join(new_cdes)}")
    if removed_cdes:
        parts.append(f"\n**Removed from {label_b}:** {', '.join(removed_cdes)}")

    reply = "\n".join(parts)

    # Table data
    table_data = [
        {"CDE": e["cde"], f"Pass Rate {label_a}": f"{e['pr_a']}%",
         f"Pass Rate {label_b}": f"{e['pr_b']}%", "Delta (pp)": f"{e['delta']:+.1f}"}
        for e in (worsened + improved + unchanged)
    ]

    # Chart: delta bar
    all_changed = worsened + improved
    chart = None
    if all_changed:
        labels = [e["cde"][:20] for e in all_changed]
        values = [e["delta"] for e in all_changed]
        colors_list = ["#C62828" if v < 0 else "#2E7D32" for v in values]
        chart = {
            "chart_type": "bar",
            "title": f"Pass Rate Delta: {label_a} vs {label_b}",
            "labels": labels,
            "datasets": [{
                "label": "Delta (pp)",
                "data": values,
                "color": "#1565C0",
            }],
        }

    ms = int((time.time() - t0) * 1000)
    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": table_data,
        "chart": chart,
        "chart_data": None,
        "confidence": 0.95,
        "latency_ms": ms,
        "data_source": f"pandas (MoM: {label_a} vs {label_b})",
        "model_used": "pandas",
    }


# ============================================================
# T1 IMPROVEMENT 2: "WHY IS X FAILING?" HANDLER
# ============================================================

WHY_FAILING_KEYWORDS = [
    "why is", "why are", "why does", "reason for", "cause of",
    "what causes", "explain why", "what makes", "why failing",
    "why red", "why amber", "failure reason", "root cause",
]


def _is_why_failing_query(question: str) -> bool:
    q = question.lower()
    return any(kw in q for kw in WHY_FAILING_KEYWORDS)


def _handle_why_failing(question: str, scorecard: Dict[str, Any],
                         t0: float) -> Optional[Dict[str, Any]]:
    """
    Answer 'why is CDE X failing?' by pulling raw data rows for that CDE
    and surfacing the top patterns: which systems, which values, which entities.
    """
    df = scorecard.get("df")
    schema = scorecard.get("schema", {})
    sheet_meta = scorecard.get("sheet_meta", {})

    if df is None or df.empty:
        return None

    # Try to identify a CDE name in the question
    sheets = scorecard.get("sheets", {})
    cde_name = None
    dim_col = None

    # First try pivot sheet CDEs
    for name, meta in sheet_meta.items():
        if not meta.get("is_pivot") or name not in sheets:
            continue
        sdf = sheets[name]
        dc = meta.get("dim_column", "")
        if not dc:
            continue
        cdes = sdf[dc].astype(str).str.strip().tolist()
        q = question.lower()
        for cde in cdes:
            if cde.lower() in q or any(w in q for w in cde.lower().split()[:2] if len(w) > 3):
                cde_name = cde
                dim_col = dc
                break
        if cde_name:
            break

    # Fall back to raw data column detection
    rag_col = schema.get("rag_status", [None])[0]
    id_col = None
    for candidate in ["immutable_cde", "cde_name", "rule_name", "source_system_rule_name"]:
        for col in df.columns:
            if candidate in col.lower():
                id_col = col
                break
        if id_col:
            break

    if not id_col:
        id_col = schema.get("identifier", [None])[0]

    # Extract CDE from raw data if not found via pivot
    if not cde_name and id_col and rag_col:
        q = question.lower()
        uniques = df[id_col].astype(str).str.strip().unique()
        for u in uniques:
            if u.lower() in q or any(w in q for w in u.lower().split()[:2] if len(w) > 3):
                cde_name = u
                dim_col = id_col
                break

    if not cde_name:
        return None

    # Pull failing rows for this CDE from raw data
    reply_parts = [f"**Why is '{cde_name}' failing?**\n"]

    if rag_col and id_col:
        cde_rows = df[df[id_col].astype(str).str.strip().str.lower() == cde_name.lower()]
        fail_rows = cde_rows[cde_rows[rag_col].astype(str).str.lower().isin(["red", "amber"])]

        if fail_rows.empty:
            reply_parts.append(f"No failing records found for '{cde_name}' in the raw data.")
        else:
            reply_parts.append(f"Found **{len(fail_rows):,}** failing records out of **{len(cde_rows):,}** total.\n")

            # Surface patterns: top 3 dimension columns with high failure concentration
            dim_cols = schema.get("dimension", [])
            for dim in dim_cols[:4]:
                if dim not in fail_rows.columns:
                    continue
                breakdown = fail_rows[dim].value_counts().head(5)
                if breakdown.empty:
                    continue
                top_vals = ", ".join(f"{v} ({c})" for v, c in breakdown.items())
                reply_parts.append(f"- **{dim}**: {top_vals}")

            # Surface the RAG status breakdown
            rag_dist = fail_rows[rag_col].value_counts().to_dict()
            rag_line = ", ".join(f"{k}: {v}" for k, v in rag_dist.items())
            reply_parts.append(f"- **Status breakdown**: {rag_line}")

        table_data = fail_rows.head(20).fillna("").to_dict(orient="records")
    else:
        reply_parts.append("Raw data not available for detailed failure analysis.")
        table_data = None

    reply = "\n".join(reply_parts)
    ms = int((time.time() - t0) * 1000)
    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": table_data,
        "chart": None, "chart_data": None,
        "confidence": 0.88,
        "latency_ms": ms,
        "data_source": f"pandas (raw data: {cde_name})",
        "model_used": "pandas",
    }


# ============================================================
# T1 IMPROVEMENT 3: AUTO-CHART for count/filter/rank results
# ============================================================

def _auto_chart_from_table(table_data: List[Dict], label_key: str,
                            value_key: str, title: str) -> Optional[Dict]:
    """
    Build a bar chart from a list of dicts when a clear label+value pair exists.
    Used to enrich count/filter/rank T1 results automatically.
    """
    if not table_data or len(table_data) < 2:
        return None
    labels = [str(row.get(label_key, ""))[:24] for row in table_data[:15]]
    values = []
    for row in table_data[:15]:
        v = row.get(value_key, 0)
        try:
            values.append(float(v))
        except (TypeError, ValueError):
            return None
    if not labels or not values or all(v == 0 for v in values):
        return None
    return {
        "chart_type": "bar",
        "title": title,
        "labels": labels,
        "datasets": [{
            "label": value_key,
            "data": [round(v, 2) for v in values],
            "color": "#1565C0",
        }],
    }


# ============================================================
# T2 IMPROVEMENT 4: DIRECT ANSWER SYNTHESIS (no LLM needed)
# ============================================================

NARRATIVE_KEYWORDS = [
    "narrative", "summary", "overview", "what does this scorecard",
    "describe this", "tell me about", "what is this report",
    "about this scorecard",
]

ANOMALY_KEYWORDS = [
    "anomal", "signal", "warning", "alert", "issue detected",
    "concern", "flag", "flagged", "unusual", "spike",
]

QUESTIONS_KEYWORDS = [
    "what questions", "what can i ask", "what can you tell",
    "what do you know", "example questions", "suggested question",
    "help me start", "ideas to ask",
]


def _handle_t2_direct_synthesis(question: str, scorecard: Dict[str, Any],
                                  t0: float) -> Optional[Dict[str, Any]]:
    """
    Answer T2 questions about scorecard metadata directly without Gemini.
    Covers: narrative, anomalies, suggested questions.
    Confidence is high because the data is directly from the scorecard object.
    """
    q = question.lower()

    # Narrative / scorecard overview
    if any(kw in q for kw in NARRATIVE_KEYWORDS):
        narrative = scorecard.get("narrative", "")
        display = scorecard.get("display_title", scorecard.get("display_name", "this scorecard"))
        if not narrative:
            return None
        reply = f"**{display} — Summary**\n\n{narrative}"
        questions = scorecard.get("questions", [])
        if questions:
            reply += "\n\n**Suggested questions you can ask:**\n"
            reply += "\n".join(f"- {q_}" for q_ in questions[:5])
        ms = int((time.time() - t0) * 1000)
        return {
            "tier": 2, "tier_label": "SEMANTIC",
            "reply": reply,
            "table_data": None, "chart": None, "chart_data": None,
            "confidence": 0.92,
            "latency_ms": ms,
            "data_source": "Scorecard Metadata (narrative)",
            "model_used": "direct-synthesis",
        }

    # Anomalies / signals
    if any(kw in q for kw in ANOMALY_KEYWORDS):
        anomalies = scorecard.get("anomalies", [])
        if not anomalies:
            ms = int((time.time() - t0) * 1000)
            return {
                "tier": 2, "tier_label": "SEMANTIC",
                "reply": "No anomalies or signals detected for this scorecard.",
                "table_data": None, "chart": None, "chart_data": None,
                "confidence": 0.88,
                "latency_ms": ms,
                "data_source": "Scorecard Metadata (anomalies)",
                "model_used": "direct-synthesis",
            }
        SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        sorted_anomalies = sorted(anomalies, key=lambda a: SEV_ORDER.get(a.get("severity", "low"), 3))
        parts = [f"**{len(anomalies)} signal(s) detected:**\n"]
        for a in sorted_anomalies:
            sev = a.get("severity", "").upper()
            desc = a.get("description", "")
            ctx = a.get("context", "")
            parts.append(f"- **[{sev}]** {desc}" + (f" — {ctx}" if ctx else ""))
        table_data = [
            {"Severity": a.get("severity", ""), "Description": a.get("description", ""),
             "Context": a.get("context", "")}
            for a in sorted_anomalies
        ]
        ms = int((time.time() - t0) * 1000)
        return {
            "tier": 2, "tier_label": "SEMANTIC",
            "reply": "\n".join(parts),
            "table_data": table_data,
            "chart": None, "chart_data": None,
            "confidence": 0.95,
            "latency_ms": ms,
            "data_source": f"Scorecard Metadata ({len(anomalies)} anomalies)",
            "model_used": "direct-synthesis",
        }

    # Suggested questions
    if any(kw in q for kw in QUESTIONS_KEYWORDS):
        questions = scorecard.get("questions", [])
        if not questions:
            return None
        reply = "**Here are questions you can ask about this scorecard:**\n\n"
        reply += "\n".join(f"{i+1}. {q_}" for i, q_ in enumerate(questions[:10]))
        ms = int((time.time() - t0) * 1000)
        return {
            "tier": 2, "tier_label": "SEMANTIC",
            "reply": reply,
            "table_data": None, "chart": None, "chart_data": None,
            "confidence": 0.90,
            "latency_ms": ms,
            "data_source": "Scorecard Metadata (questions)",
            "model_used": "direct-synthesis",
        }

    return None

# ============================================================
# MAIN ROUTER
# ============================================================

def query_scorecard(scorecard: Dict[str, Any], question: str, mode: str = "auto",
                    chat_context: Optional[str] = None) -> Dict[str, Any]:
    """
    Route a question through the 3-tier engine.

    mode: 'auto' | 't1' | 't2' | 't3'
    - auto: tries T1 -> T2 -> T3
    - t1/t2/t3: forces that specific tier
    """
    df = scorecard.get("df")
    schema = scorecard.get("schema", {})
    sheets = scorecard.get("sheets", {})
    sheet_meta = scorecard.get("sheet_meta", {})

    # Proactive summary (any mode)
    q = question.lower().strip()
    if "proactive summary" in q or "proactive insight" in q:
        t0 = time.time()
        return _handle_proactive_summary(scorecard, t0)

    # T2 direct synthesis — narrative/anomalies/questions (no LLM needed)
    t0 = time.time()
    t2_direct = _handle_t2_direct_synthesis(question, scorecard, t0)
    if t2_direct:
        return t2_direct

    # Month queries (fast path, any mode)
    if _detect_month_query(question):
        month_result = _handle_month_query(question, scorecard)
        if month_result:
            return month_result

    # T1: Month-over-month CDE comparison
    if _is_mom_cde_query(q):
        t0 = time.time()
        mom_result = _handle_mom_cde_comparison(question, scorecard, t0)
        if mom_result:
            return mom_result

    # T1: Why is X failing? — root cause handler
    if _is_why_failing_query(q):
        t0 = time.time()
        why_result = _handle_why_failing(question, scorecard, t0)
        if why_result:
            return why_result

    # FIX 2: Failing CDEs — most common question, runs before generic pivot
    if sheet_meta and _is_failing_cde_query(q):
        t0 = time.time()
        result = _handle_failing_cdes(question, scorecard, t0)
        if result:
            return result

    # FIX 1: Multi-pivot queries (any mode)
    if sheet_meta and _is_pivot_query(q):
        t0 = time.time()
        pivot_result = _handle_pivot_query(question, scorecard, t0)
        if pivot_result:
            return pivot_result

    # -- Forced mode --
    if mode == "t1":
        result = try_pandas_query(question, df, schema, sheets, sheet_meta)
        if result:
            return result
        return {
            "tier": 1, "tier_label": "DIRECT",
            "reply": "Could not answer this question using pandas. Try AUTO mode for better results.",
            "table_data": None, "chart": None, "chart_data": None,
            "confidence": 0.0, "latency_ms": 0,
            "data_source": "pandas", "model_used": "pandas",
        }

    if mode == "t2":
        result = try_semantic_search(question, scorecard)
        if result:
            return _format_t2_through_t3(question, result, scorecard)
        return {
            "tier": 2, "tier_label": "SEMANTIC",
            "reply": "No relevant documents found. Upload documentation files when onboarding for semantic search.",
            "table_data": None, "chart": None, "chart_data": None,
            "confidence": 0.0, "latency_ms": 0,
            "data_source": "TF-IDF", "model_used": "scikit-learn",
        }

    if mode == "t3":
        return try_llm_query(question, scorecard, chat_context=chat_context)

    # -- AUTO mode: T1 -> T2 -> T3 --
    # Try Tier 1 first
    t1_result = try_pandas_query(question, df, schema, sheets, sheet_meta)
    if t1_result and t1_result["confidence"] > 0.7:
        log.info("AUTO: routed to T1 (pandas)")
        return t1_result

    # Try Tier 2
    if _detect_t2_intent(question):
        t2_result = try_semantic_search(question, scorecard)
        if t2_result and t2_result["confidence"] > 0.3:
            log.info("AUTO: routed to T2+T3 (semantic + LLM formatting)")
            return _format_t2_through_t3(question, t2_result, scorecard)

    # Fall back to Tier 3 with all available context
    t1_context = t1_result["reply"] if t1_result else None
    t2_result = try_semantic_search(question, scorecard)
    t2_context = None
    if t2_result:
        raw = t2_result.get("raw_chunks", [])
        t2_context = "\n".join(c.get("content", "")[:300] for c in raw[:3])

    log.info("AUTO: routed to T3 (Gemini)")
    return try_llm_query(question, scorecard, t1_context, t2_context, chat_context=chat_context)
