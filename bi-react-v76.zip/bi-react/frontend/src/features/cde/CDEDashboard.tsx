import { useState, useMemo, useCallback } from 'react'
import { useQuery } from '@tanstack/react-query'
import { ResponsiveLine } from '@nivo/line'
import { ResponsiveHeatMap } from '@nivo/heatmap'
import { getPivotData, getPivotTrend } from '@/api'
import {
  ragColor, normaliseRag, computePassRate,
  computeNarrativeFromPivot, RAG_CHART_COLORS,
} from '@/utils/rag'
import { PanelBox, Skeleton, EmptyState, ErrorState } from '@/components/ui/index'
import { useAppStore } from '@/store/appStore'
import type { PivotRow, TrendResponse, DataTableFilter } from '@/types'

interface CDEDashboardProps {
  scorecardId: string
  sheetName: string
  activeMonth: string
}

export function CDEDashboard({ scorecardId, sheetName, activeMonth }: CDEDashboardProps) {
  const setActiveTab = useAppStore((s) => s.setActiveTab)
  const setDrillFilters = useAppStore((s) => s.setDrillFilters)
  const [selectedCde, setSelectedCde] = useState<string>('__ALL__')

  const { data, isLoading, error } = useQuery({
    queryKey: ['pivotData', scorecardId, sheetName, activeMonth],
    queryFn: () => getPivotData(scorecardId, sheetName, activeMonth || undefined),
    enabled: Boolean(scorecardId && sheetName),
    staleTime: 60_000,
  })

  // For trend queries: when exactly 1 CDE selected use it, else use all (no cde param)
  const selectedSet = selectedCde === '__ALL__' || !selectedCde
    ? null
    : new Set(selectedCde.split('|||').filter(Boolean))
  const cdeParam = selectedSet?.size === 1 ? [...selectedSet][0] : undefined

  const { data: trendRed } = useQuery({
    queryKey: ['pivotTrend', scorecardId, sheetName, 'Red', cdeParam ?? '__ALL__'],
    queryFn: () => getPivotTrend(scorecardId, sheetName, 'Red', cdeParam),
    enabled: Boolean(scorecardId && sheetName),
    staleTime: 60_000,
  })

  const { data: trendAmber } = useQuery({
    queryKey: ['pivotTrend', scorecardId, sheetName, 'Amber', cdeParam ?? '__ALL__'],
    queryFn: () => getPivotTrend(scorecardId, sheetName, 'Amber', cdeParam),
    enabled: Boolean(scorecardId && sheetName),
    staleTime: 60_000,
  })

  const { data: trendGreen } = useQuery({
    queryKey: ['pivotTrend', scorecardId, sheetName, 'Green', cdeParam ?? '__ALL__'],
    queryFn: () => getPivotTrend(scorecardId, sheetName, 'Green', cdeParam),
    enabled: Boolean(scorecardId && sheetName),
    staleTime: 60_000,
  })

  const { data: trendTotal } = useQuery({
    queryKey: ['pivotTrend', scorecardId, sheetName, 'Row_Total', cdeParam ?? '__ALL__'],
    queryFn: () => getPivotTrend(scorecardId, sheetName, 'Row_Total', cdeParam),
    enabled: Boolean(scorecardId && sheetName),
    staleTime: 60_000,
  })

  const handleHeatmapClick = useCallback(
    (cde: string, ragStatus: string) => {
      if (!cde || !ragStatus) return
      const filters: DataTableFilter[] = [
        { column: 'immutable_cde', operator: 'equals', value: cde },
        { column: 'rag_status', operator: 'equals', value: ragStatus },
      ]
      setDrillFilters(filters)
      setActiveTab('data-table')
    },
    [setDrillFilters, setActiveTab],
  )

  if (!sheetName) {
    return <EmptyState message="No pivot sheets available. Upload an Excel file with Consolidated or Solo pivot tabs." />
  }
  if (isLoading) return <CDESkeleton />
  if (error) return <ErrorState message="Failed to load pivot data." />
  if (!data) return null

  const { meta, data: rows, columns } = data
  const ragCols = meta.rag_columns ?? []
  const dimCol = meta.dim_column ?? columns[0] ?? ''
  const totalCol = meta.total_column ?? ''
  const gt = meta.grand_total ?? {}

  // Heatmap shows all selected CDEs
  const activeSelectedSet = selectedCde === '__ALL__' || !selectedCde
    ? null
    : new Set(selectedCde.split('|||').filter(Boolean))
  const visibleRows = activeSelectedSet === null
    ? (rows as PivotRow[])
    : (rows as PivotRow[]).filter((r) => activeSelectedSet.has(String(r[dimCol] ?? '')))

  const narrative = computeNarrativeFromPivot(
    rows as Record<string, number | string>[],
    ragCols, dimCol, totalCol, gt as Record<string, number>,
  )

  const cdeOptions = (rows as PivotRow[]).map((r) => String(r[dimCol] ?? '')).filter(Boolean)

  return (
    <div className="space-y-4">
      <CDEHeaderRow
        sheetName={sheetName}
        businessDate={meta.business_date}
        gt={gt as Record<string, number>}
        ragCols={ragCols}
        totalCol={totalCol}
        narrative={narrative}
      />

      <PanelBox>
        <PassRateByCde
          rows={rows as PivotRow[]}
          ragCols={ragCols}
          dimCol={dimCol}
          totalCol={totalCol}
          gt={gt as Record<string, number>}
          cdeOptions={cdeOptions}
          selectedCde={selectedCde}
          onSelectCde={setSelectedCde}
        />
      </PanelBox>

      {/* Heatmap LEFT + Trend charts RIGHT stacked */}
      <div className="grid grid-cols-[1fr_380px] gap-4 items-start">
        <PanelBox title="Status Heatmap" icon={<ListIcon />}>
          <p className="text-2xs text-ink-dim mb-2 mt-0.5">Click any cell to drill into the filtered data table.</p>
          <CDEHeatmap
            rows={visibleRows}
            ragCols={ragCols}
            dimCol={dimCol}
            onCellClick={handleHeatmapClick}
          />
        </PanelBox>

        <div className="flex flex-col gap-4">
          <PanelBox title="Monthly Fail Trend (Red + Amber)" icon={<WaveIcon />}>
            <FailTrendChart trendRed={trendRed} trendAmber={trendAmber} />
          </PanelBox>
          <PanelBox title="Monthly RAG Breakdown" icon={<WaveIcon />}>
            <RagBreakdownTrend trendRed={trendRed} trendAmber={trendAmber} trendGreen={trendGreen} />
          </PanelBox>
        </div>
      </div>

      {trendTotal && (trendTotal.labels?.length ?? 0) > 1 && (
        <PanelBox title="Month-over-Month Trend — Total Rules" icon={<WaveIcon />}>
          <MoMTotalTrend trendTotal={trendTotal} />
        </PanelBox>
      )}

      <CDEDetailTable
        rows={visibleRows}
        columns={columns}
        ragCols={ragCols}
        dimCol={dimCol}
        gt={selectedCde === '__ALL__' ? (gt as Record<string, number>) : undefined}
      />
    </div>
  )
}

function CDEHeaderRow({
  sheetName, businessDate, gt, ragCols, totalCol, narrative,
}: {
  sheetName: string
  businessDate: string
  gt: Record<string, number>
  ragCols: string[]
  totalCol: string
  narrative: string
}) {
  const total = totalCol
    ? Number(gt[totalCol]) || 0
    : ragCols.reduce((s, c) => s + (Number(gt[c]) || 0), 0)

  const ragPills = ragCols.filter((c) => Number(gt[c]) > 0).map((c) => ({ key: c, val: Number(gt[c]) }))

  return (
    <div className="bg-surface-card border border-border rounded shadow-sm p-4">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-bold text-navy truncate">{sheetName}</h3>
          {businessDate && <p className="text-xs text-ink-dim mt-0.5">Business Date: {businessDate}</p>}
          {narrative && <p className="text-sm text-ink-sec mt-2 leading-relaxed max-w-2xl">{narrative}</p>}
        </div>
        <div className="flex gap-2.5 flex-shrink-0 flex-wrap justify-end">
          {ragPills.map(({ key, val }) => {
            const cls = normaliseRag(key)
            const bgMap: Record<string, string> = {
              red: 'bg-rag-red/[0.09] text-rag-red',
              amber: 'bg-rag-amber/[0.09] text-rag-amber',
              green: 'bg-rag-green/[0.09] text-rag-green',
              'dark green': 'bg-rag-dkgreen/[0.09] text-rag-dkgreen',
            }
            const style = bgMap[cls] ?? 'bg-surface text-ink-sec'
            return (
              <div key={key} className={`px-3.5 py-1.5 rounded-lg text-center min-w-[66px] ${style}`}>
                <div className="text-xl font-bold font-mono leading-none">{val}</div>
                <div className="text-2xs font-semibold uppercase tracking-widest mt-1">{key}</div>
              </div>
            )
          })}
          {total > 0 && (
            <div className="px-3.5 py-1.5 rounded-lg text-center min-w-[66px] bg-navy/[0.07] text-navy">
              <div className="text-xl font-bold font-mono leading-none">{total}</div>
              <div className="text-2xs font-semibold uppercase tracking-widest mt-1">Total</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function PassRateByCde({
  rows, ragCols, dimCol, totalCol, gt,
  cdeOptions, selectedCde, onSelectCde,
}: {
  rows: PivotRow[]
  ragCols: string[]
  dimCol: string
  totalCol: string
  gt: Record<string, number>
  cdeOptions: string[]
  selectedCde: string
  onSelectCde: (cde: string) => void
}) {
  // Multi-select: comma-separated cde names, or '__ALL__'
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [barHovered, setBarHovered] = useState(false)
  const [tooltipX, setTooltipX] = useState(0)

  const selectedSet: Set<string> = selectedCde === '__ALL__'
    ? new Set(cdeOptions)
    : new Set(selectedCde.split('|||').filter(Boolean))

  function toggleCde(cde: string) {
    const next = new Set(selectedSet)
    if (next.has(cde)) {
      next.delete(cde)
    } else {
      next.add(cde)
    }
    if (next.size === 0 || next.size === cdeOptions.length) {
      onSelectCde('__ALL__')
    } else {
      onSelectCde([...next].join('|||'))
    }
  }

  function selectAll() { onSelectCde('__ALL__') }
  function clearAll() { onSelectCde('') }

  // Aggregate RAG counts across all selected CDEs
  const activeRows = rows.filter((r) => selectedSet.has(String(r[dimCol] ?? '')))

  const aggregated: Record<string, number> = {}
  ragCols.forEach((c) => {
    aggregated[c] = activeRows.reduce((s, r) => s + (Number(r[c]) || 0), 0)
  })
  const aggTotal = totalCol
    ? activeRows.reduce((s, r) => s + (Number(r[totalCol]) || 0), 0)
    : ragCols.reduce((s, c) => s + aggregated[c], 0)

  const passCount = ragCols.filter((c) => ['green', 'dark green', 'dark_green'].includes(normaliseRag(c)))
    .reduce((s, c) => s + aggregated[c], 0)
  const passRate = aggTotal > 0 ? (passCount / aggTotal) * 100 : 0

  const dropdownLabel = selectedCde === '__ALL__'
    ? 'All CDEs'
    : selectedSet.size === 0
      ? 'None selected'
      : selectedSet.size === 1
        ? [...selectedSet][0]
        : `${selectedSet.size} CDEs selected`

  // Per-CDE breakdown for tooltip
  const perCde = activeRows.map((r) => {
    const cde = String(r[dimCol] ?? '')
    const tot = totalCol ? Number(r[totalCol]) || 0 : ragCols.reduce((s, c) => s + (Number(r[c]) || 0), 0)
    const pass = ragCols.filter((c) => ['green', 'dark green', 'dark_green'].includes(normaliseRag(c)))
      .reduce((s, c) => s + (Number(r[c]) || 0), 0)
    const pr = tot > 0 ? (pass / tot * 100).toFixed(1) : '0.0'
    const ragDetail = ragCols
      .filter((c) => Number(r[c]) > 0)
      .map((c) => `${c}: ${Number(r[c])}`)
    return { cde, pr, ragDetail, tot }
  })

  return (
    <div>
      {/* Header row */}
      <div className="flex items-center gap-3 mb-4">
        <div className="flex items-center gap-1.5">
          <WaveIcon />
          <span className="text-2xs font-bold uppercase tracking-wide text-ink-dim">Pass Rate by CDE</span>
        </div>

        {/* Multi-select dropdown */}
        <div className="relative">
          <button
            onClick={() => setDropdownOpen((v) => !v)}
            className="flex items-center gap-2 text-xs border border-border rounded px-2.5 py-1.5 bg-white text-ink outline-none focus:border-blue-brand cursor-pointer font-medium min-w-[180px] justify-between"
          >
            <span className="truncate">{dropdownLabel}</span>
            <svg className="w-3 h-3 text-ink-dim flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </button>

          {dropdownOpen && (
            <>
              {/* backdrop */}
              <div className="fixed inset-0 z-30" onClick={() => setDropdownOpen(false)} />
              <div className="absolute left-0 top-full mt-1 z-40 bg-white border border-border rounded shadow-lg min-w-[220px] max-h-72 overflow-y-auto">
                {/* All / Clear controls */}
                <div className="flex items-center gap-2 px-3 py-2 border-b border-border sticky top-0 bg-white z-10">
                  <button
                    onClick={selectAll}
                    className="text-2xs font-bold text-blue-brand hover:underline"
                  >
                    All
                  </button>
                  <span className="text-border-strong">|</span>
                  <button
                    onClick={clearAll}
                    className="text-2xs font-bold text-ink-dim hover:text-navy hover:underline"
                  >
                    Clear
                  </button>
                  <span className="ml-auto text-2xs text-ink-dim">
                    {selectedSet.size}/{cdeOptions.length}
                  </span>
                </div>
                {/* CDE options */}
                {cdeOptions.map((cde) => {
                  const checked = selectedSet.has(cde)
                  // Find RAG status for this CDE to show a colour dot
                  const row = rows.find((r) => String(r[dimCol] ?? '') === cde)
                  const ragStatus = row
                    ? ragCols.find((c) => Number(row[c]) > 0 && !['', 'green', 'dark green', 'dark_green'].includes(normaliseRag(c)))
                    : undefined
                  return (
                    <label
                      key={cde}
                      className="flex items-center gap-2.5 px-3 py-1.5 hover:bg-surface cursor-pointer select-none"
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleCde(cde)}
                        className="w-3.5 h-3.5 accent-blue-brand flex-shrink-0"
                      />
                      {ragStatus && (
                        <span
                          className="w-2 h-2 rounded-full flex-shrink-0"
                          style={{ background: ragColor(ragStatus) }}
                        />
                      )}
                      <span className="text-xs text-ink truncate">{cde}</span>
                    </label>
                  )
                })}
              </div>
            </>
          )}
        </div>

        {/* Pass rate badge */}
        {aggTotal > 0 && (
          <span className="ml-auto text-xs font-bold font-mono text-navy">
            {passRate.toFixed(1)}% pass &nbsp;·&nbsp; {aggTotal} rules
          </span>
        )}
      </div>

      {/* Single stacked bar */}
      {aggTotal > 0 ? (
        <div className="relative">
          <div
            className="h-8 rounded overflow-hidden flex cursor-default"
            onMouseEnter={() => setBarHovered(true)}
            onMouseLeave={() => setBarHovered(false)}
            onMouseMove={(e) => {
              const rect = e.currentTarget.getBoundingClientRect()
              setTooltipX(e.clientX - rect.left)
            }}
          >
            {ragCols.map((c) => {
              const v = aggregated[c] || 0
              if (v === 0) return null
              return (
                <div
                  key={c}
                  style={{ width: `${(v / aggTotal * 100).toFixed(3)}%`, background: ragColor(c) }}
                />
              )
            })}
          </div>

          {/* Hover tooltip */}
          {barHovered && (
            <div
              className="absolute bottom-full mb-2 z-50 pointer-events-none"
              style={{ left: Math.min(tooltipX, 999), transform: 'translateX(-50%)' }}
            >
              <div className="bg-navy text-white text-xs rounded shadow-lg px-3 py-2.5 min-w-[200px] max-w-[320px]">
                {/* Aggregate summary */}
                <div className="font-bold text-white mb-1.5 border-b border-white/20 pb-1.5">
                  {dropdownLabel}
                </div>
                <div className="flex justify-between mb-1">
                  <span className="text-white/70">Pass rate</span>
                  <span className="font-bold font-mono">{passRate.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/70">Total rules</span>
                  <span className="font-mono">{aggTotal}</span>
                </div>
                {/* RAG breakdown */}
                <div className="space-y-0.5 mb-2">
                  {ragCols.filter((c) => aggregated[c] > 0).map((c) => (
                    <div key={c} className="flex items-center gap-1.5 justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: ragColor(c) }} />
                        <span className="text-white/70">{c}</span>
                      </div>
                      <span className="font-mono">{aggregated[c]}</span>
                    </div>
                  ))}
                </div>
                {/* Per-CDE breakdown when multiple selected */}
                {perCde.length > 1 && perCde.length <= 8 && (
                  <div className="border-t border-white/20 pt-1.5 space-y-0.5">
                    <div className="text-2xs text-white/50 uppercase tracking-wide mb-1">Per CDE</div>
                    {perCde.map(({ cde, pr, tot }) => (
                      <div key={cde} className="flex justify-between gap-2">
                        <span className="text-white/70 truncate max-w-[140px]" title={cde}>{cde}</span>
                        <span className="font-mono flex-shrink-0">{pr}% ({tot})</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Legend row under bar */}
          <div className="flex gap-3 mt-2 flex-wrap">
            {ragCols.filter((c) => aggregated[c] > 0).map((c) => (
              <div key={c} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: ragColor(c) }} />
                <span className="text-2xs text-ink-sec">
                  {c}: <span className="font-mono font-bold">{aggregated[c]}</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="text-xs text-ink-dim py-3">No CDEs selected.</div>
      )}
    </div>
  )
}

function CDEHeatmap({ rows, ragCols, dimCol, onCellClick }: {
  rows: PivotRow[]
  ragCols: string[]
  dimCol: string
  onCellClick: (cde: string, ragStatus: string) => void
}) {
  const visCols = ragCols.slice(0, 6)
  const displayRows = rows.slice(0, 20)

  const nivoData = useMemo(() =>
    visCols.map((col) => ({
      id: col,
      data: displayRows.map((row) => ({
        x: String(row[dimCol] ?? '').slice(0, 28),
        y: Number(row[col]) || 0,
      })),
    })),
    [visCols, displayRows, dimCol],
  )

  if (!nivoData.length || !displayRows.length) return <EmptyState message="No data" />

  return (
    <div style={{ height: Math.max(200, displayRows.length * 28 + 60) }}>
      <ResponsiveHeatMap
        data={nivoData}
        margin={{ top: 40, right: 10, bottom: 10, left: 210 }}
        axisTop={{ tickSize: 0, tickPadding: 6, legendOffset: -36, tickRotation: -20 }}
        axisLeft={{ tickSize: 0, tickPadding: 10 }}
        colors={(cell) => {
          const col = String(cell.serieId)
          const base = RAG_CHART_COLORS[normaliseRag(col)] ?? '#8898AA'
          const serieData = nivoData.find((d) => d.id === col)
          const maxVal = serieData ? Math.max(...serieData.data.map((d) => d.y), 1) : 1
          const opacity = Math.max(0.15, (Number(cell.value) || 0) / maxVal)
          return base + Math.round(opacity * 255).toString(16).padStart(2, '0')
        }}
        emptyColor="#F5F7FA"
        borderRadius={4}
        borderWidth={2}
        borderColor="#FFFFFF"
        labelTextColor="rgba(255,255,255,0.92)"
        theme={{ text: { fontSize: 10 }, axis: { ticks: { text: { fontSize: 10, fill: '#4A5568' } } } }}
        onClick={(cell) => {
          if (Number(cell.value) > 0) onCellClick(String(cell.data.x), String(cell.serieId))
        }}
        tooltip={({ cell }) => (
          <div className="bg-navy text-white text-xs px-3 py-1.5 rounded shadow-lg">
            <strong>{String(cell.data.x)}</strong> / {String(cell.serieId)}: <strong>{cell.value}</strong>
            {Number(cell.value) > 0 && <div className="text-white/60 mt-0.5 text-[10px]">Click to open filtered data table</div>}
          </div>
        )}
      />
    </div>
  )
}

function FailTrendChart({ trendRed, trendAmber }: { trendRed?: TrendResponse; trendAmber?: TrendResponse }) {
  const nivoData = useMemo(() => {
    const labels = trendRed?.labels ?? trendAmber?.labels ?? []
    if (labels.length < 2) return []
    const redData = trendRed?.datasets?.[0]?.data ?? []
    const amberData = trendAmber?.datasets?.[0]?.data ?? []
    return [{
      id: 'Total Failures (Red + Amber)',
      color: '#5C35CC',
      data: labels.map((label, i) => ({ x: label, y: (redData[i] ?? 0) + (amberData[i] ?? 0) })),
    }]
  }, [trendRed, trendAmber])

  if (!nivoData.length || nivoData[0].data.length < 2) {
    return <EmptyState message="Not enough months for trend. Upload data for 2+ months." />
  }

  return (
    <div style={{ height: 172 }}>
      <ResponsiveLine
        data={nivoData}
        margin={{ top: 16, right: 16, bottom: 40, left: 40 }}
        xScale={{ type: 'point' }}
        yScale={{ type: 'linear', min: 0, max: 'auto', stacked: false }}
        curve="monotoneX"
        colors={['#5C35CC']}
        lineWidth={2.5}
        pointSize={7}
        pointColor="#5C35CC"
        pointBorderWidth={2}
        pointBorderColor="#FFFFFF"
        enableArea
        areaOpacity={0.08}
        axisBottom={{ tickSize: 0, tickPadding: 8, tickRotation: -20 }}
        axisLeft={{ tickSize: 0, tickPadding: 6, tickValues: 4 }}
        gridYValues={4}
        theme={{ text: { fontSize: 10 }, axis: { ticks: { text: { fontSize: 10, fill: '#8898AA' } } }, grid: { line: { stroke: 'rgba(0,0,0,.05)' } } }}
        tooltip={({ point }) => (
          <div className="bg-navy text-white text-xs px-3 py-1.5 rounded shadow-lg">
            {String(point.data.x)}: <strong>{String(point.data.y)} failures</strong>
          </div>
        )}
        useMesh
      />
    </div>
  )
}

function RagBreakdownTrend({ trendRed, trendAmber, trendGreen }: { trendRed?: TrendResponse; trendAmber?: TrendResponse; trendGreen?: TrendResponse }) {
  const nivoData = useMemo(() => {
    const labels = trendRed?.labels ?? trendAmber?.labels ?? trendGreen?.labels ?? []
    if (labels.length < 2) return []
    const redData = trendRed?.datasets?.[0]?.data ?? []
    const amberData = trendAmber?.datasets?.[0]?.data ?? []
    const greenData = trendGreen?.datasets?.[0]?.data ?? []
    return [
      { id: 'Red', color: '#C62828', data: labels.map((label, i) => ({ x: label, y: redData[i] ?? 0 })) },
      { id: 'Amber', color: '#FF9800', data: labels.map((label, i) => ({ x: label, y: amberData[i] ?? 0 })) },
      { id: 'Green', color: '#2E7D32', data: labels.map((label, i) => ({ x: label, y: greenData[i] ?? 0 })) },
    ]
  }, [trendRed, trendAmber, trendGreen])

  if (!nivoData.length || nivoData[0].data.length < 2) {
    return <EmptyState message="Not enough months for trend. Upload data for 2+ months." />
  }

  return (
    <div style={{ height: 172 }}>
      <ResponsiveLine
        data={nivoData}
        margin={{ top: 16, right: 62, bottom: 40, left: 40 }}
        xScale={{ type: 'point' }}
        yScale={{ type: 'linear', min: 0, max: 'auto', stacked: false }}
        curve="monotoneX"
        colors={nivoData.map((d) => d.color)}
        lineWidth={2.5}
        pointSize={6}
        pointColor={{ from: 'color' }}
        pointBorderWidth={2}
        pointBorderColor="#FFFFFF"
        axisBottom={{ tickSize: 0, tickPadding: 8, tickRotation: -20 }}
        axisLeft={{ tickSize: 0, tickPadding: 6, tickValues: 4 }}
        gridYValues={4}
        theme={{ text: { fontSize: 10 }, axis: { ticks: { text: { fontSize: 10, fill: '#8898AA' } } }, grid: { line: { stroke: 'rgba(0,0,0,.05)' } } }}
        legends={[{
          anchor: 'right',
          direction: 'column',
          translateX: 60,
          itemWidth: 54,
          itemHeight: 16,
          symbolSize: 9,
          symbolShape: 'circle',
          itemTextColor: '#8898AA',
          effects: [{ on: 'hover', style: { itemTextColor: '#0A1628' } }],
        }]}
        tooltip={({ point }) => (
          <div className="bg-navy text-white text-xs px-3 py-1.5 rounded shadow-lg">
            {String(point.serieId)} — {String(point.data.x)}: <strong>{String(point.data.y)}</strong>
          </div>
        )}
        enableSlices="x"
      />
    </div>
  )
}

function MoMTotalTrend({ trendTotal }: { trendTotal: TrendResponse }) {
  const nivoData = useMemo(() =>
    (trendTotal.datasets ?? []).map((ds) => ({
      id: ds.label || trendTotal.sheet_name || 'Total',
      data: trendTotal.labels.map((label, i) => ({ x: label, y: ds.data[i] ?? 0 })),
    })),
    [trendTotal],
  )

  if (!nivoData.length || nivoData[0].data.length < 2) return <EmptyState message="Not enough month data for trend." />

  return (
    <div style={{ height: 200 }}>
      <ResponsiveLine
        data={nivoData}
        margin={{ top: 16, right: 20, bottom: 44, left: 52 }}
        xScale={{ type: 'point' }}
        yScale={{ type: 'linear', min: 'auto', max: 'auto', stacked: false }}
        curve="monotoneX"
        colors={['#1565C0']}
        lineWidth={2.5}
        pointSize={7}
        pointColor="#1565C0"
        pointBorderWidth={2}
        pointBorderColor="#FFFFFF"
        enableArea
        areaOpacity={0.06}
        axisBottom={{ tickSize: 0, tickPadding: 8, tickRotation: -20 }}
        axisLeft={{ tickSize: 0, tickPadding: 8, tickValues: 5 }}
        gridYValues={5}
        theme={{ text: { fontSize: 10 }, axis: { ticks: { text: { fontSize: 10, fill: '#8898AA' } } }, grid: { line: { stroke: 'rgba(0,0,0,.05)' } } }}
        tooltip={({ point }) => (
          <div className="bg-navy text-white text-xs px-3 py-1.5 rounded shadow-lg">
            {String(point.data.x)}: <strong>{String(point.data.y)} rules</strong>
          </div>
        )}
        useMesh
      />
    </div>
  )
}

function CDEDetailTable({ rows, columns, ragCols, dimCol, gt }: {
  rows: PivotRow[]
  columns: string[]
  ragCols: string[]
  dimCol: string
  gt?: Record<string, number>
}) {
  if (!rows.length) return null
  return (
    <div className="bg-surface-card border border-border rounded shadow-sm overflow-auto">
      <table className="w-full">
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c} className="sticky top-0 bg-navy-mid text-white/85 px-3.5 py-2.5 text-2xs font-bold uppercase tracking-wide text-left whitespace-nowrap border-b border-white/10">
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} className="hover:bg-blue-brand/[0.025] transition-colors">
              {columns.map((c) => {
                const v = row[c] ?? ''
                const isRag = ragCols.includes(c) && Number(v) > 0
                return (
                  <td key={c} className="px-3.5 py-2 text-xs border-b border-black/[0.04] whitespace-nowrap font-mono">
                    {isRag ? (
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full inline-block flex-shrink-0" style={{ background: ragColor(c) }} />
                        {String(v)}
                      </span>
                    ) : String(v)}
                  </td>
                )
              })}
            </tr>
          ))}
          {gt && Object.keys(gt).length > 0 && (
            <tr className="bg-surface-raised">
              {columns.map((c, i) => {
                const v = gt[c] !== undefined ? gt[c] : ''
                return (
                  <td key={c} className="px-3.5 py-2 text-xs border-t-2 border-border whitespace-nowrap font-sans font-bold">
                    {i === 0 ? <strong>Grand Total</strong> : String(v)}
                  </td>
                )
              })}
            </tr>
          )}
        </tbody>
      </table>
    </div>
  )
}

function CDESkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-24" />
      <Skeleton className="h-48" />
      <Skeleton className="h-56" />
      <div className="grid grid-cols-2 gap-4">
        <Skeleton className="h-48" />
        <Skeleton className="h-48" />
      </div>
      <Skeleton className="h-48" />
    </div>
  )
}

function WaveIcon() {
  return (
    <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
    </svg>
  )
}
function ListIcon() {
  return (
    <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>
    </svg>
  )
}
