import { useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getPivotData } from '@/api'
import { isFail, normaliseRag, isPass, passRateColor } from '@/utils/rag'
import { Skeleton } from '@/components/ui/index'
import { useAppStore } from '@/store/appStore'
import type { ScorecardSummary, PivotRow, PivotDataResponse } from '@/types'

interface OverviewProps {
  scorecard: ScorecardSummary
  activeMonth: string
}

// ─── Generate crisp dynamic theory from live pivot data ──────────
function buildTheory(pivot: PivotDataResponse): string {
  const ragCols = pivot.meta.rag_columns ?? []
  const dimCol = pivot.meta.dim_column ?? ''
  const totalCol = pivot.meta.total_column ?? ''
  const gt = pivot.meta.grand_total ?? {}
  const rows = pivot.data as PivotRow[]
  const businessDate = pivot.meta.business_date ?? ''

  const totalRules = totalCol
    ? Number(gt[totalCol]) || 0
    : ragCols.reduce((s, c) => s + (Number(gt[c]) || 0), 0)

  const totalCdes = rows.length

  const failRules = ragCols
    .filter(isFail)
    .reduce((s, c) => s + (Number(gt[c]) || 0), 0)

  const amberRules = ragCols
    .filter((c) => normaliseRag(c) === 'amber')
    .reduce((s, c) => s + (Number(gt[c]) || 0), 0)

  const passRules = ragCols
    .filter(isPass)
    .reduce((s, c) => s + (Number(gt[c]) || 0), 0)

  const passRate = totalRules > 0 ? ((passRules / totalRules) * 100).toFixed(1) : '0.0'

  // Find which CDEs are Red
  const redCdes = rows
    .filter((r) => ragCols.filter(isFail).reduce((s, c) => s + (Number(r[c]) || 0), 0) > 0)
    .map((r) => String(r[dimCol] ?? ''))
    .filter(Boolean)
    .slice(0, 2)

  // Find which CDEs are Amber
  const amberCdes = rows
    .filter((r) =>
      ragCols.filter((c) => normaliseRag(c) === 'amber').reduce((s, c) => s + (Number(r[c]) || 0), 0) > 0 &&
      ragCols.filter(isFail).reduce((s, c) => s + (Number(r[c]) || 0), 0) === 0
    )
    .map((r) => String(r[dimCol] ?? ''))
    .filter(Boolean)
    .slice(0, 2)

  // Build the sentence
  const datePart = businessDate ? ` as of ${businessDate}` : ''
  let text = `${totalRules} rules assessed across ${totalCdes} CDEs${datePart}.`

  if (failRules === 0 && amberRules === 0) {
    text += ` Pass rate ${passRate}% — all CDEs passing.`
  } else {
    if (failRules > 0) {
      const cdeNames = redCdes.length > 0 ? ` (${redCdes.join(', ')}${redCdes.length < failRules ? ' and others' : ''})` : ''
      text += ` ${failRules} Red failure${failRules !== 1 ? 's' : ''}${cdeNames}`
    }
    if (failRules > 0 && amberRules > 0) text += ' and'
    if (amberRules > 0) {
      const cdeNames = amberCdes.length > 0 ? ` (${amberCdes.join(', ')}${amberCdes.length < amberRules ? ' and others' : ''})` : ''
      text += ` ${amberRules} Amber rule${amberRules !== 1 ? 's' : ''} at risk${cdeNames}`
    }
    text += `. Pass rate stands at ${passRate}%.`
  }

  return text
}

// ─── Extract metrics from pivot data ─────────────────────────────
function extractMetrics(pivot: PivotDataResponse) {
  const ragCols = pivot.meta.rag_columns ?? []
  const totalCol = pivot.meta.total_column ?? ''
  const gt = pivot.meta.grand_total ?? {}
  const rows = pivot.data as PivotRow[]

  const totalRules = totalCol
    ? Number(gt[totalCol]) || 0
    : ragCols.reduce((s, c) => s + (Number(gt[c]) || 0), 0)

  const failRules = ragCols.filter(isFail).reduce((s, c) => s + (Number(gt[c]) || 0), 0)
  const amberRules = ragCols.filter((c) => normaliseRag(c) === 'amber').reduce((s, c) => s + (Number(gt[c]) || 0), 0)
  const passRules = ragCols.filter(isPass).reduce((s, c) => s + (Number(gt[c]) || 0), 0)
  const passRate = totalRules > 0 ? (passRules / totalRules) * 100 : 0

  // Failing CDE pills — Red first then Amber
  const redCdes = rows
    .filter((r) => ragCols.filter(isFail).reduce((s, c) => s + (Number(r[c]) || 0), 0) > 0)
    .map((r) => ({ name: String(r[pivot.meta.dim_column ?? ''] ?? ''), type: 'red' as const }))
    .slice(0, 3)

  const amberCdes = rows
    .filter((r) =>
      ragCols.filter((c) => normaliseRag(c) === 'amber').reduce((s, c) => s + (Number(r[c]) || 0), 0) > 0 &&
      ragCols.filter(isFail).reduce((s, c) => s + (Number(r[c]) || 0), 0) === 0
    )
    .map((r) => ({ name: String(r[pivot.meta.dim_column ?? ''] ?? ''), type: 'amber' as const }))
    .slice(0, 2)

  const failingCdes = [...redCdes, ...amberCdes]

  return { totalRules, failRules, amberRules, passRate, failingCdes }
}

// ─── ACCENT COLOUR PER SHEET NAME ────────────────────────────────
function sheetAccentClass(name: string): string {
  const n = name.toLowerCase()
  if (n.includes('consolidated')) return 'before:bg-blue-brand'
  if (n.includes('non')) return 'before:bg-rag-amber-soft'
  if (n.includes('solo')) return 'before:bg-rag-green-soft'
  return 'before:bg-ink-dim'
}

// ─── MAIN OVERVIEW ───────────────────────────────────────────────
export function OverviewFeature({ scorecard, activeMonth }: OverviewProps) {
  const setActiveTab = useAppStore((s) => s.setActiveTab)
  const setActivePivotSheet = useAppStore((s) => s.setActivePivotSheet)

  const pivotSheets = scorecard.pivot_sheet_names ?? []
  const months = scorecard.months_available ?? []

  if (!pivotSheets.length) {
    return (
      <div className="text-sm text-ink-sec py-8 text-center">
        No pivot sheets available. Upload an Excel file with pivot tabs.
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {/* Reporting context */}
      <div className="flex items-center gap-2 text-xs text-ink-dim mb-4">
        <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>
        </svg>
        <span>
          Reporting: <strong className="text-ink">{activeMonth || months[months.length - 1] || '—'}</strong>
        </span>
        <span className="text-border-s">·</span>
        <span>{pivotSheets.length} pivot sheet{pivotSheets.length !== 1 ? 's' : ''}</span>
        {scorecard.onboarded_at && (
          <>
            <span className="text-border-s">·</span>
            <span>
              Updated{' '}
              {new Date(scorecard.onboarded_at).toLocaleDateString('en-GB', {
                day: 'numeric', month: 'short', year: 'numeric',
              })}
            </span>
          </>
        )}
      </div>

      {/* One row per pivot sheet */}
      {pivotSheets.map((sheet) => (
        <PivotSheetRow
          key={sheet}
          scorecardId={scorecard.scorecard_id}
          sheetName={sheet}
          activeMonth={activeMonth || months[months.length - 1] || ''}
          accentClass={sheetAccentClass(sheet)}
          onDrillClick={() => {
            setActivePivotSheet(sheet)
            setActiveTab('cde-dashboard')
          }}
        />
      ))}
    </div>
  )
}

// ─── SINGLE PIVOT SHEET ROW ───────────────────────────────────────
function PivotSheetRow({
  scorecardId,
  sheetName,
  activeMonth,
  accentClass,
  onDrillClick,
}: {
  scorecardId: string
  sheetName: string
  activeMonth: string
  accentClass: string
  onDrillClick: () => void
}) {
  const { data, isLoading } = useQuery({
    queryKey: ['pivotData', scorecardId, sheetName, activeMonth],
    queryFn: () => getPivotData(scorecardId, sheetName, activeMonth || undefined),
    enabled: Boolean(scorecardId && sheetName),
    staleTime: 60_000,
  })

  const metrics = useMemo(() => data ? extractMetrics(data) : null, [data])
  const theory = useMemo(() => data ? buildTheory(data) : '', [data])

  if (isLoading) {
    return <Skeleton className="h-[88px] rounded-lg" />
  }

  if (!data || !metrics) {
    return (
      <div className="bg-surface-card border border-border rounded-lg px-5 py-4 text-xs text-ink-dim">
        No data available for {sheetName} in this period.
      </div>
    )
  }

  const failTotal = metrics.failRules + metrics.amberRules
  const failColor = metrics.failRules > 0 ? '#C62828' : metrics.amberRules > 0 ? '#E65100' : '#2E7D32'
  const prColor = passRateColor(metrics.passRate)

  return (
    <div
      onClick={onDrillClick}
      className={`
        bg-surface-card border border-border rounded-lg px-5 py-4
        cursor-pointer transition-all duration-150 group
        hover:border-blue-brand/30 hover:shadow-md
        relative overflow-hidden
        before:absolute before:left-0 before:top-0 before:bottom-0 before:w-[3px] before:rounded-l-lg
        ${accentClass}
      `}
    >
      <div className="flex items-center gap-5">

        {/* Sheet name + theory */}
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="text-sm font-bold text-navy">{sheetName}</h3>
            {data.meta.business_date && (
              <span className="text-2xs text-ink-dim">
                {data.meta.business_date}
              </span>
            )}
          </div>
          <p className="text-xs text-ink-sec leading-relaxed">{theory}</p>
        </div>

        {/* Vertical divider */}
        <div className="w-px h-10 bg-border flex-shrink-0" />

        {/* Fail count / total */}
        <div className="flex-shrink-0 text-center min-w-[72px]">
          <div className="flex items-baseline gap-1 justify-center">
            <span
              className="text-2xl font-bold font-mono leading-none"
              style={{ color: failColor }}
            >
              {failTotal}
            </span>
            <span className="text-xs text-ink-dim font-mono">
              / {metrics.totalRules}
            </span>
          </div>
          <div className="text-2xs font-bold uppercase tracking-wide text-ink-dim mt-1">
            Failing rules
          </div>
        </div>

        {/* Vertical divider */}
        <div className="w-px h-10 bg-border flex-shrink-0" />

        {/* Pass rate */}
        <div className="flex-shrink-0 text-center min-w-[64px]">
          <div
            className="text-xl font-bold font-mono leading-none"
            style={{ color: prColor }}
          >
            {metrics.passRate.toFixed(1)}%
          </div>
          <div className="text-2xs font-bold uppercase tracking-wide text-ink-dim mt-1">
            Pass Rate
          </div>
        </div>

        {/* Vertical divider */}
        <div className="w-px h-10 bg-border flex-shrink-0" />

        {/* Failing CDE pills */}
        <div className="flex flex-wrap gap-1.5 flex-shrink-0 max-w-[220px]">
          {metrics.failingCdes.length === 0 ? (
            <span className="text-xs px-2.5 py-1 rounded-md font-medium bg-rag-green/[0.08] text-rag-green">
              All passing
            </span>
          ) : (
            metrics.failingCdes.map((c) => (
              <span
                key={c.name}
                className={`text-xs px-2 py-0.5 rounded-md font-medium whitespace-nowrap ${
                  c.type === 'red'
                    ? 'bg-rag-red/[0.09] text-rag-red'
                    : 'bg-rag-amber/[0.09] text-rag-amber'
                }`}
              >
                {c.name.length > 18 ? c.name.slice(0, 17) + '…' : c.name}
              </span>
            ))
          )}
        </div>

        {/* Arrow */}
        <svg
          className="w-4 h-4 text-ink-dim flex-shrink-0 transition-all duration-150 group-hover:translate-x-1 group-hover:text-navy"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
        >
          <path d="M5 12h14M12 5l7 7-7 7"/>
        </svg>
      </div>
    </div>
  )
}
