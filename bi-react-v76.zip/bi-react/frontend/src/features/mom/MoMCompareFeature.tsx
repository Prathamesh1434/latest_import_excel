import { useState, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { ResponsiveBar } from '@nivo/bar'
import { ResponsiveLine } from '@nivo/line'
import { listMonths, addMonth, getPivotData } from '@/api'
import { formatMonth, isPass, isFail, normaliseRag, RAG_CHART_COLORS } from '@/utils/rag'
import { Button, KpiCard, Skeleton, EmptyState } from '@/components/ui/index'
import type { ScorecardSummary, PivotRow, PivotMoMResult } from '@/types'

interface MoMProps {
  scorecardId: string
  activePivotSheet: string
  scorecard: ScorecardSummary
}

export function MoMCompareFeature({ scorecardId, activePivotSheet, scorecard }: MoMProps) {
  const [periodA, setPeriodA] = useState('')
  const [periodB, setPeriodB] = useState('')
  const [uploadMonth, setUploadMonth] = useState('')
  const [uploadFile, setUploadFile] = useState<File | null>(null)
  const [uploadStatus, setUploadStatus] = useState('')
  const [comparing, setComparing] = useState(false)
  const [compareResult, setCompareResult] = useState<PivotMoMResult | null>(null)
  const [compareError, setCompareError] = useState('')

  const { data: months = [], refetch: refetchMonths } = useQuery({
    queryKey: ['months', scorecardId],
    queryFn: () => listMonths(scorecardId),
    enabled: Boolean(scorecardId),
  })

  // Determine active sheet: use prop or first pivot sheet
  const sheetName = activePivotSheet || scorecard.pivot_sheet_names?.[0] || ''

  async function handleUpload() {
    if (!uploadMonth || !uploadFile) { setUploadStatus('Select month and file.'); return }
    setUploadStatus('Uploading...')
    try {
      const d = await addMonth(scorecardId, uploadMonth, uploadFile)
      setUploadStatus(`Uploaded: ${d.row_count} rows, ${d.sheet_count} sheets`)
      refetchMonths()
    } catch (e: unknown) {
      setUploadStatus(e instanceof Error ? e.message : 'Upload failed.')
    }
  }

  async function handleCompare() {
    if (!periodA || !periodB || !sheetName) return
    setComparing(true)
    setCompareError('')
    setCompareResult(null)
    try {
      const [pivA, pivB] = await Promise.all([
        getPivotData(scorecardId, sheetName, periodA),
        getPivotData(scorecardId, sheetName, periodB),
      ])
      const result = computePivotMoM(pivA, pivB, periodA, periodB)
      setCompareResult(result)
    } catch (e: unknown) {
      setCompareError(e instanceof Error ? e.message : 'Comparison failed.')
    } finally {
      setComparing(false)
    }
  }

  // All available period labels (from months list + scorecard months_available)
  const allPeriods = useMemo(() => {
    const fromMonths = months.map((m) => m.month_label)
    const fromScorecard = scorecard.months_available ?? []
    return [...new Set([...fromMonths, ...fromScorecard])].sort()
  }, [months, scorecard.months_available])

  const periodOpts = allPeriods.map((m) => (
    <option key={m} value={m}>
      {formatMonth(m)}
    </option>
  ))

  if (!sheetName) {
    return <EmptyState message="No pivot sheets available for comparison. Upload an Excel file with pivot tabs." />
  }

  return (
    <div className="space-y-5">
      <div className="bg-surface-card border border-border rounded shadow-sm p-5">
        <h4 className="text-sm font-bold text-navy mb-4">Upload New Period</h4>
        <div className="flex items-end gap-3 flex-wrap mb-5">
          <CtrlGroup label="Month">
            <input
              type="month"
              value={uploadMonth}
              onChange={(e) => setUploadMonth(e.target.value)}
              className="ctrl-input"
            />
          </CtrlGroup>
          <CtrlGroup label="File">
            <input
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={(e) => setUploadFile(e.target.files?.[0] ?? null)}
              className="ctrl-input text-xs py-1.5"
            />
          </CtrlGroup>
          <Button variant="primary" size="sm" onClick={handleUpload}>Upload</Button>
          {uploadStatus && (
            <span className="text-xs text-ink-sec self-end pb-1">{uploadStatus}</span>
          )}
        </div>

        <div className="border-t border-border pt-4">
          <h4 className="text-sm font-bold text-navy mb-3">
            Compare Periods — <span className="font-normal text-ink-sec">{sheetName}</span>
          </h4>
          <div className="flex items-end gap-3 flex-wrap">
            <CtrlGroup label="Period A">
              <select
                value={periodA}
                onChange={(e) => setPeriodA(e.target.value)}
                className="ctrl-input min-w-[160px]"
              >
                <option value="">Select...</option>
                {periodOpts}
              </select>
            </CtrlGroup>
            <CtrlGroup label="Period B">
              <select
                value={periodB}
                onChange={(e) => setPeriodB(e.target.value)}
                className="ctrl-input min-w-[160px]"
              >
                <option value="">Select...</option>
                {periodOpts}
              </select>
            </CtrlGroup>
            <Button
              variant="primary"
              size="sm"
              disabled={!periodA || !periodB || comparing}
              onClick={handleCompare}
            >
              {comparing ? 'Comparing...' : 'Compare'}
            </Button>
          </div>
          {allPeriods.length === 0 && (
            <p className="text-xs text-ink-dim mt-3">
              No periods available. Upload data for at least 2 months to compare.
            </p>
          )}
        </div>
      </div>

      {comparing && <Skeleton className="h-48" />}
      {compareError && <p className="text-rag-red text-sm">{compareError}</p>}
      {compareResult && (
        <PivotMoMResults result={compareResult} />
      )}
    </div>
  )
}

// ─── PIVOT MOM COMPUTATION (client-side) ─────────────────────────
function computePivotMoM(pivA: import('@/types').PivotDataResponse, pivB: import('@/types').PivotDataResponse, labelA: string, labelB: string): PivotMoMResult {
  const ragCols = pivA.meta.rag_columns ?? pivB.meta.rag_columns ?? []
  const dimCol = pivA.meta.dim_column ?? pivB.meta.dim_column ?? ''
  const totalCol = pivA.meta.total_column ?? pivB.meta.total_column ?? ''
  const gtA = pivA.meta.grand_total ?? {}
  const gtB = pivB.meta.grand_total ?? {}

  const rowsA = pivA.data as PivotRow[]
  const rowsB = pivB.data as PivotRow[]

  const mapA = new Map(rowsA.map((r) => [String(r[dimCol] ?? ''), r]))
  const mapB = new Map(rowsB.map((r) => [String(r[dimCol] ?? ''), r]))

  const allCdes = [...new Set([...mapA.keys(), ...mapB.keys()])].filter(Boolean)
  const newCdes = allCdes.filter((c) => !mapA.has(c))
  const removedCdes = allCdes.filter((c) => !mapB.has(c))

  function getTotals(row: PivotRow, cols: string[], tc: string) {
    const total = tc ? Number(row[tc]) || 0 : cols.reduce((s, c) => s + (Number(row[c]) || 0), 0)
    const pass = cols.filter(isPass).reduce((s, c) => s + (Number(row[c]) || 0), 0)
    const fail = cols.filter(isFail).reduce((s, c) => s + (Number(row[c]) || 0), 0)
    const passRate = total > 0 ? (pass / total) * 100 : 0
    return { total, pass, fail, passRate }
  }

  const cdeRows = allCdes.map((cde) => {
    const rowA = mapA.get(cde) ?? {}
    const rowB = mapB.get(cde) ?? {}
    const a: Record<string, number> = {}
    const b: Record<string, number> = {}
    ragCols.forEach((c) => {
      a[c] = Number(rowA[c]) || 0
      b[c] = Number(rowB[c]) || 0
    })
    const tA = getTotals(rowA as PivotRow, ragCols, totalCol)
    const tB = getTotals(rowB as PivotRow, ragCols, totalCol)
    const flips = ragCols
      .filter((c) => a[c] !== b[c])
      .map((c) => ({ status: c, deltaA: a[c], deltaB: b[c] }))
    return {
      cde,
      a, b,
      totalA: tA.total, totalB: tB.total,
      passRateA: tA.passRate, passRateB: tB.passRate,
      passRateDelta: tB.passRate - tA.passRate,
      flips,
    }
  })

  // Grand totals from meta (most reliable)
  const totalRulesA = totalCol ? (Number(gtA[totalCol]) || 0) : ragCols.reduce((s, c) => s + (Number(gtA[c]) || 0), 0)
  const totalRulesB = totalCol ? (Number(gtB[totalCol]) || 0) : ragCols.reduce((s, c) => s + (Number(gtB[c]) || 0), 0)
  const passA = ragCols.filter(isPass).reduce((s, c) => s + (Number(gtA[c]) || 0), 0)
  const passB = ragCols.filter(isPass).reduce((s, c) => s + (Number(gtB[c]) || 0), 0)
  const overallPassRateA = totalRulesA > 0 ? (passA / totalRulesA) * 100 : 0
  const overallPassRateB = totalRulesB > 0 ? (passB / totalRulesB) * 100 : 0

  const ragMovement: Record<string, { a: number; b: number; delta: number }> = {}
  ragCols.forEach((c) => {
    const vA = Number(gtA[c]) || 0
    const vB = Number(gtB[c]) || 0
    ragMovement[c] = { a: vA, b: vB, delta: vB - vA }
  })

  const grandA: Record<string, number> = {}
  const grandB: Record<string, number> = {}
  ragCols.forEach((c) => { grandA[c] = Number(gtA[c]) || 0; grandB[c] = Number(gtB[c]) || 0 })

  return {
    labelA, labelB, ragCols, dimCol, totalCol,
    cdeRows, grandA, grandB,
    totalRulesA, totalRulesB,
    overallPassRateA, overallPassRateB,
    ragMovement,
    newCdes, removedCdes,
  }
}

// ─── RESULTS UI ───────────────────────────────────────────────────
function PivotMoMResults({ result }: { result: PivotMoMResult }) {
  const {
    labelA, labelB, ragCols, cdeRows,
    totalRulesA, totalRulesB,
    overallPassRateA, overallPassRateB,
    ragMovement, newCdes, removedCdes,
  } = result

  const passRateDelta = overallPassRateB - overallPassRateA
  const rulesDelta = totalRulesB - totalRulesA
  const totalFlips = cdeRows.filter((r) => r.flips.length > 0).length

  // RAG bar chart data
  const ragBarData = ragCols.map((c) => ({
    status: c,
    [formatMonth(labelA)]: ragMovement[c]?.a ?? 0,
    [formatMonth(labelB)]: ragMovement[c]?.b ?? 0,
  }))

  // Pass rate trend line
  const passRateLine = [
    {
      id: 'Pass Rate %',
      color: '#1565C0',
      data: [
        { x: formatMonth(labelA), y: parseFloat(overallPassRateA.toFixed(1)) },
        { x: formatMonth(labelB), y: parseFloat(overallPassRateB.toFixed(1)) },
      ],
    },
  ]

  return (
    <div className="space-y-5">
      {/* KPI summary */}
      <div className="grid grid-cols-4 gap-4">
        <KpiCard
          label="Total Rules"
          value={`${totalRulesA.toLocaleString()} → ${totalRulesB.toLocaleString()}`}
          sub={rulesDelta === 0 ? 'No change' : rulesDelta > 0 ? `+${rulesDelta} rules added` : `${rulesDelta} rules removed`}
          variant="blue"
        />
        <KpiCard
          label="Pass Rate"
          value={`${overallPassRateB.toFixed(1)}%`}
          sub={`${passRateDelta >= 0 ? '+' : ''}${passRateDelta.toFixed(1)}% vs ${formatMonth(labelA)}`}
          variant={passRateDelta >= 0 ? 'green' : 'red'}
        />
        <KpiCard
          label="New CDEs"
          value={newCdes.length}
          sub={newCdes.length > 0 ? newCdes.slice(0, 2).join(', ') : 'None added'}
          variant="blue"
        />
        <KpiCard
          label="CDEs with Changes"
          value={totalFlips}
          sub="RAG status moved"
          variant={totalFlips > 0 ? 'amber' : 'green'}
        />
      </div>

      {/* RAG movement table */}
      <div className="bg-surface-card border border-border rounded shadow-sm overflow-auto">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <h4 className="text-sm font-bold text-navy">RAG Status Movement</h4>
          <span className="text-xs text-ink-dim">{formatMonth(labelA)} vs {formatMonth(labelB)}</span>
        </div>
        <table className="w-full">
          <thead>
            <tr>
              <th className="sticky top-0 bg-navy-mid text-white/85 px-4 py-2.5 text-2xs font-bold uppercase tracking-wide text-left border-b border-white/10">Status</th>
              <th className="sticky top-0 bg-navy-mid text-white/85 px-4 py-2.5 text-2xs font-bold uppercase tracking-wide text-right border-b border-white/10">{formatMonth(labelA)}</th>
              <th className="sticky top-0 bg-navy-mid text-white/85 px-4 py-2.5 text-2xs font-bold uppercase tracking-wide text-right border-b border-white/10">{formatMonth(labelB)}</th>
              <th className="sticky top-0 bg-navy-mid text-white/85 px-4 py-2.5 text-2xs font-bold uppercase tracking-wide text-right border-b border-white/10">Delta</th>
            </tr>
          </thead>
          <tbody>
            {ragCols.map((c) => {
              const mv = ragMovement[c]
              if (!mv) return null
              const delta = mv.delta
              const isBad = isFail(c) ? delta > 0 : normaliseRag(c) === 'amber' ? delta > 0 : delta < 0
              const isGood = isFail(c) ? delta < 0 : delta > 0
              return (
                <tr key={c} className="hover:bg-blue-brand/[0.025] transition-colors">
                  <td className="px-4 py-2.5 text-xs border-b border-black/[0.04]">
                    <span className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ background: RAG_CHART_COLORS[normaliseRag(c)] ?? '#8898AA' }} />
                      {c}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-xs border-b border-black/[0.04] font-mono text-right">{mv.a}</td>
                  <td className="px-4 py-2.5 text-xs border-b border-black/[0.04] font-mono text-right">{mv.b}</td>
                  <td className={`px-4 py-2.5 text-xs border-b border-black/[0.04] font-mono font-bold text-right ${isBad ? 'text-rag-red' : isGood ? 'text-rag-green' : 'text-ink-sec'}`}>
                    {delta > 0 ? `+${delta}` : delta}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* Charts: RAG bar + Pass rate trend */}
      <div className="grid grid-cols-2 gap-5">
        <div className="bg-surface-card border border-border rounded shadow-sm p-4">
          <div className="text-2xs font-bold uppercase tracking-wide text-ink-dim mb-3">RAG Distribution Comparison</div>
          <div style={{ height: 220 }}>
            <ResponsiveBar
              data={ragBarData}
              keys={[formatMonth(labelA), formatMonth(labelB)]}
              indexBy="status"
              margin={{ top: 10, right: 10, bottom: 50, left: 36 }}
              padding={0.3}
              groupMode="grouped"
              colors={['#1565C0', '#C62828']}
              borderRadius={3}
              enableLabel={false}
              axisBottom={{ tickSize: 0, tickPadding: 8 }}
              axisLeft={{ tickSize: 0, tickPadding: 8, tickValues: 4 }}
              gridYValues={4}
              theme={{ text: { fontSize: 10 }, axis: { ticks: { text: { fontSize: 10, fill: '#8898AA' } } }, grid: { line: { stroke: 'rgba(0,0,0,.05)' } } }}
              legends={[{
                dataFrom: 'keys', anchor: 'bottom', direction: 'row',
                translateY: 44, itemWidth: 110, itemHeight: 14,
                symbolSize: 8, symbolShape: 'square', itemTextColor: '#8898AA',
              }]}
              tooltip={({ id, value, indexValue }) => (
                <div className="bg-navy text-white text-xs px-3 py-1.5 rounded shadow-lg">
                  {String(id)} — {String(indexValue)}: <strong>{value}</strong>
                </div>
              )}
            />
          </div>
        </div>

        <div className="bg-surface-card border border-border rounded shadow-sm p-4">
          <div className="text-2xs font-bold uppercase tracking-wide text-ink-dim mb-3">Pass Rate Trend</div>
          <div style={{ height: 220 }}>
            <ResponsiveLine
              data={passRateLine}
              margin={{ top: 16, right: 20, bottom: 44, left: 48 }}
              xScale={{ type: 'point' }}
              yScale={{ type: 'linear', min: 0, max: 100, stacked: false }}
              curve="monotoneX"
              colors={[passRateDelta >= 0 ? '#1B5E20' : '#C62828']}
              lineWidth={3}
              pointSize={10}
              pointColor={passRateDelta >= 0 ? '#1B5E20' : '#C62828'}
              pointBorderWidth={2}
              pointBorderColor="#FFFFFF"
              enableArea
              areaOpacity={0.07}
              axisBottom={{ tickSize: 0, tickPadding: 8 }}
              axisLeft={{ tickSize: 0, tickPadding: 8, tickValues: 5, format: (v) => `${v}%` }}
              gridYValues={5}
              theme={{ text: { fontSize: 10 }, axis: { ticks: { text: { fontSize: 10, fill: '#8898AA' } } }, grid: { line: { stroke: 'rgba(0,0,0,.05)' } } }}
              tooltip={({ point }) => (
                <div className="bg-navy text-white text-xs px-3 py-1.5 rounded shadow-lg">
                  {String(point.data.x)}: <strong>{String(point.data.y)}%</strong>
                </div>
              )}
              useMesh
            />
          </div>
        </div>
      </div>

      {/* CDE-level changes */}
      {cdeRows.filter((r) => r.flips.length > 0).length > 0 && (
        <div className="bg-surface-card border border-border rounded shadow-sm overflow-auto">
          <div className="px-4 py-3 border-b border-border">
            <h4 className="text-sm font-bold text-navy">CDE-Level Changes</h4>
          </div>
          <table className="w-full">
            <thead>
              <tr>
                <th className="sticky top-0 bg-navy-mid text-white/85 px-4 py-2.5 text-2xs font-bold uppercase tracking-wide text-left border-b border-white/10">CDE</th>
                <th className="sticky top-0 bg-navy-mid text-white/85 px-4 py-2.5 text-2xs font-bold uppercase tracking-wide text-right border-b border-white/10">Pass Rate A</th>
                <th className="sticky top-0 bg-navy-mid text-white/85 px-4 py-2.5 text-2xs font-bold uppercase tracking-wide text-right border-b border-white/10">Pass Rate B</th>
                <th className="sticky top-0 bg-navy-mid text-white/85 px-4 py-2.5 text-2xs font-bold uppercase tracking-wide text-right border-b border-white/10">Delta</th>
                <th className="sticky top-0 bg-navy-mid text-white/85 px-4 py-2.5 text-2xs font-bold uppercase tracking-wide text-left border-b border-white/10">Changed Statuses</th>
              </tr>
            </thead>
            <tbody>
              {cdeRows
                .filter((r) => r.flips.length > 0)
                .sort((a, b) => Math.abs(b.passRateDelta) - Math.abs(a.passRateDelta))
                .map((r) => (
                  <tr key={r.cde} className="hover:bg-blue-brand/[0.025] transition-colors">
                    <td className="px-4 py-2.5 text-xs border-b border-black/[0.04] font-medium">{r.cde}</td>
                    <td className="px-4 py-2.5 text-xs border-b border-black/[0.04] font-mono text-right">{r.passRateA.toFixed(1)}%</td>
                    <td className="px-4 py-2.5 text-xs border-b border-black/[0.04] font-mono text-right">{r.passRateB.toFixed(1)}%</td>
                    <td className={`px-4 py-2.5 text-xs border-b border-black/[0.04] font-mono font-bold text-right ${r.passRateDelta < 0 ? 'text-rag-red' : 'text-rag-green'}`}>
                      {r.passRateDelta >= 0 ? '+' : ''}{r.passRateDelta.toFixed(1)}%
                    </td>
                    <td className="px-4 py-2.5 text-xs border-b border-black/[0.04]">
                      <div className="flex gap-2 flex-wrap">
                        {r.flips.map((f) => (
                          <span key={f.status} className="text-2xs px-1.5 py-0.5 rounded" style={{ background: (RAG_CHART_COLORS[normaliseRag(f.status)] ?? '#8898AA') + '22', color: RAG_CHART_COLORS[normaliseRag(f.status)] ?? '#8898AA' }}>
                            {f.status}: {f.deltaA} → {f.deltaB}
                          </span>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}

      {/* New/removed CDEs */}
      {(newCdes.length > 0 || removedCdes.length > 0) && (
        <div className="grid grid-cols-2 gap-4">
          {newCdes.length > 0 && (
            <div className="bg-surface-card border border-border rounded shadow-sm p-4">
              <div className="text-2xs font-bold uppercase tracking-wide text-rag-green mb-3">New CDEs in {formatMonth(labelB)}</div>
              <div className="space-y-1">
                {newCdes.map((c) => (
                  <div key={c} className="text-xs text-ink py-1 border-b border-border/50">{c}</div>
                ))}
              </div>
            </div>
          )}
          {removedCdes.length > 0 && (
            <div className="bg-surface-card border border-border rounded shadow-sm p-4">
              <div className="text-2xs font-bold uppercase tracking-wide text-rag-red mb-3">Removed CDEs from {formatMonth(labelA)}</div>
              <div className="space-y-1">
                {removedCdes.map((c) => (
                  <div key={c} className="text-xs text-ink py-1 border-b border-border/50">{c}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function CtrlGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-2xs font-bold uppercase tracking-widest text-ink-dim">{label}</label>
      {children}
    </div>
  )
}
