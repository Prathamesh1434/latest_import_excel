// ─────────────────────────────────────────────
// AUTH
// ─────────────────────────────────────────────
export interface User {
  user_id: string
  name: string
  role: 'admin' | 'analyst' | 'viewer'
  entity: string
}

// ─────────────────────────────────────────────
// SCORECARD
// ─────────────────────────────────────────────
export interface RagSummary {
  Red?: number
  red?: number
  Amber?: number
  amber?: number
  Green?: number
  green?: number
  'Dark Green'?: number
  'dark green'?: number
  dark_green?: number
}

export interface SheetMeta {
  is_pivot: boolean
  dim_column: string
  rag_columns: string[]
  total_column: string
  business_date: string
  grand_total: Record<string, number>
}

export interface Anomaly {
  signal_type: string
  severity: 'critical' | 'high' | 'medium' | 'low'
  description: string
  col: string
  context: string
}

export interface ScorecardSummary {
  scorecard_id: string
  display_title: string
  display_name: string
  legal_entity: string
  reporting_month: string
  row_count: number
  col_count: number
  month_count: number
  months_available: string[]
  pivot_sheet_names: string[]
  raw_sheet_names: string[]
  sheet_names: string[]
  sheet_meta: Record<string, SheetMeta>
  rag_summary: RagSummary
  narrative: string
  questions: string[]
  anomalies: Anomaly[]
  anomaly_count: number
  onboarded_at: string
  is_stale: boolean
}

// ─────────────────────────────────────────────
// PIVOT / CDE DATA
// ─────────────────────────────────────────────
export type PivotRow = Record<string, string | number>

export interface PivotMeta {
  is_pivot: boolean
  dim_column: string
  rag_columns: string[]
  total_column: string
  business_date: string
  grand_total: Record<string, number>
}

export interface PivotDataResponse {
  sheet_name: string
  data: PivotRow[]
  columns: string[]
  row_count: number
  meta: PivotMeta
}

export interface TrendDataset {
  label: string
  data: number[]
  borderColor: string
  backgroundColor: string
  fill: boolean
  tension: number
}

export interface TrendResponse {
  labels: string[]
  datasets: TrendDataset[]
  metric: string
  cde: string
  sheet_name: string
  message?: string
}

// ─────────────────────────────────────────────
// DATA TABLE
// ─────────────────────────────────────────────
export interface ColumnMeta {
  raw: string
  clean: string
  dtype: 'text' | 'numeric' | 'date'
}

export interface DataTableFilter {
  column: string
  operator: 'equals' | 'not_equals' | 'contains' | 'greater_than' | 'less_than'
  value: string
}

export interface DataTableRequest {
  page: number
  per_page: number
  sort_col: string
  sort_dir: 'asc' | 'desc'
  filters: DataTableFilter[]
}

export interface DataTableResponse {
  rows: Record<string, unknown>[]
  total_rows: number
  page: number
  total_pages: number
  per_page: number
  columns: ColumnMeta[]
  column_map: Record<string, string>
}

// ─────────────────────────────────────────────
// CHAT
// ─────────────────────────────────────────────
export type ChatTier = 'auto' | 't1' | 't2' | 't3'
export type ChatTierLabel = 'DIRECT' | 'SEMANTIC' | 'GEMINI' | 'ERROR' | 'BLOCKED'

export interface ChatChartDataset {
  label?: string
  data: number[]
  color?: string
  backgroundColor?: string[] | string
  borderRadius?: number
}

export interface ChatChart {
  chart_type?: string
  type?: string
  title?: string
  labels: string[]
  datasets?: ChatChartDataset[]
  data?: number[]
  colors?: string[]
  indexAxis?: string
}

export interface ChatResponse {
  reply: string
  tier: number
  tier_label: ChatTierLabel
  confidence: number
  latency_ms: number
  data_source: string
  model_used: string
  table_data?: Record<string, unknown>[]
  chart?: ChatChart
  chart_data?: ChatChart
  data_freshness?: string
}

export interface ChatMessage {
  id: string
  role: 'user' | 'bot'
  content: string
  meta?: Omit<ChatResponse, 'reply' | 'table_data' | 'chart' | 'chart_data'>
  tableData?: Record<string, unknown>[]
  chart?: ChatChart
  timestamp: Date
}

// ─────────────────────────────────────────────
// MOM COMPARE
// ─────────────────────────────────────────────
export interface MonthEntry {
  month_label: string
  filename: string
  uploaded_at: string
  row_count: number
  col_count: number
  sheet_names: string[]
}

export interface RagComparison {
  statuses: string[]
  period_a: Record<string, number>
  period_b: Record<string, number>
}

export interface StatusFlip {
  key: string
  from: string
  to: string
}

export interface MoMSummary {
  new_rows: number
  removed_rows: number
  changed_rows: number
  total_status_flips: number
  status_flips_detail: StatusFlip[]
}

export interface MoMChartDataset {
  label: string
  data: number[]
  color: string
}

export interface MoMChart {
  chart_type: string
  title: string
  subtitle: string
  labels: string[]
  datasets: MoMChartDataset[]
}

export interface MoMResponse {
  period_a: { label: string; rows: number; kri: Record<string, number> }
  period_b: { label: string; rows: number; kri: Record<string, number> }
  rag_comparison: RagComparison
  summary: MoMSummary
  changes: unknown[]
  charts: MoMChart[]
}

// Pivot-based MoM: computed client-side from two PivotDataResponse objects
export interface PivotMoMResult {
  labelA: string
  labelB: string
  ragCols: string[]
  dimCol: string
  totalCol: string
  // Per-CDE comparison
  cdeRows: Array<{
    cde: string
    a: Record<string, number>
    b: Record<string, number>
    totalA: number
    totalB: number
    passRateA: number
    passRateB: number
    passRateDelta: number
    flips: Array<{ status: string; deltaA: number; deltaB: number }>
  }>
  // Grand total comparison
  grandA: Record<string, number>
  grandB: Record<string, number>
  totalRulesA: number
  totalRulesB: number
  overallPassRateA: number
  overallPassRateB: number
  // RAG movement summary
  ragMovement: Record<string, { a: number; b: number; delta: number }>
  // New/removed CDEs
  newCdes: string[]
  removedCdes: string[]
}

// ─────────────────────────────────────────────
// LANDING KPI
// ─────────────────────────────────────────────
export interface LandingKPIs {
  total_rules: number
  failed_rules: number
  pass_rate: number
}

export interface LandingResponse {
  kpis: LandingKPIs
  trends: unknown[]
  rag_distribution: Record<string, number>
}

// ─────────────────────────────────────────────
// RAG HELPERS (shared type)
// ─────────────────────────────────────────────
export type RagStatus = 'red' | 'amber' | 'green' | 'dkgreen' | 'unknown'
