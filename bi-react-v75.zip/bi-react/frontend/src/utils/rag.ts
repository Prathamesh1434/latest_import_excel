import type { RagStatus, RagSummary } from '@/types'

export const RAG_CHART_COLORS: Record<string, string> = {
  red: '#C62828',
  amber: '#FF9800',
  green: '#4CAF50',
  'dark green': '#2E7D32',
  dark_green: '#2E7D32',
}

export const RAG_SOFT_COLORS: Record<string, string> = {
  red: 'rgba(198,40,40,.09)',
  amber: 'rgba(230,81,0,.09)',
  green: 'rgba(27,94,32,.09)',
  dkgreen: 'rgba(13,59,31,.09)',
}

export const RAG_TEXT_COLORS: Record<string, string> = {
  red: '#C62828',
  amber: '#E65100',
  green: '#1B5E20',
  dkgreen: '#0D3B1F',
}

export const NIVO_RAG_COLORS = [
  '#C62828',
  '#FF9800',
  '#4CAF50',
  '#2E7D32',
  '#1565C0',
  '#00BCD4',
]

export function normaliseRag(v: string): string {
  return (v || '').toLowerCase().replace('_', ' ').trim()
}

export function ragStatus(v: string): RagStatus {
  const k = normaliseRag(v)
  if (k === 'red') return 'red'
  if (k === 'amber') return 'amber'
  if (k === 'dark green') return 'dkgreen'
  if (k === 'green') return 'green'
  return 'unknown'
}

export function isPass(v: string): boolean {
  return ['green', 'dark green', 'dark_green'].includes(normaliseRag(v))
}

export function isFail(v: string): boolean {
  return normaliseRag(v) === 'red'
}

export function ragColor(v: string): string {
  return RAG_CHART_COLORS[normaliseRag(v)] ?? '#8898AA'
}

export function ragTailwind(v: string): string {
  const s = ragStatus(v)
  if (s === 'red') return 'rag-red'
  if (s === 'amber') return 'rag-amber'
  if (s === 'green') return 'rag-green'
  if (s === 'dkgreen') return 'rag-dkgreen'
  return ''
}

export function computePassRate(
  row: Record<string, number | string>,
  ragCols: string[],
  totalCol: string,
): { pass: number; fail: number; amber: number; total: number; pct: number } {
  const total = totalCol
    ? Number(row[totalCol]) || 0
    : ragCols.reduce((s, c) => s + (Number(row[c]) || 0), 0)

  const pass = ragCols
    .filter(isPass)
    .reduce((s, c) => s + (Number(row[c]) || 0), 0)

  const fail = ragCols
    .filter(isFail)
    .reduce((s, c) => s + (Number(row[c]) || 0), 0)

  const amb = ragCols
    .filter((c) => normaliseRag(c) === 'amber')
    .reduce((s, c) => s + (Number(row[c]) || 0), 0)

  const pct = total > 0 ? (pass / total) * 100 : 0

  return { pass, fail, amber: amb, total, pct }
}

export function summariseRag(rag: RagSummary): {
  red: number
  amber: number
  green: number
  dkgreen: number
  total: number
  passRate: number
} {
  const red = rag.Red ?? rag.red ?? 0
  const amber = rag.Amber ?? rag.amber ?? 0
  const green = rag.Green ?? rag.green ?? 0
  const dkgreen =
    rag['Dark Green'] ?? rag['dark green'] ?? rag.dark_green ?? 0
  const total = (red + amber + green + dkgreen) || 1
  const passRate = ((green + dkgreen) / total) * 100
  return { red, amber, green, dkgreen, total, passRate }
}

export function formatMonth(m: string): string {
  if (!m || m.length < 7) return m
  const NAMES: Record<string, string> = {
    '01': 'Jan', '02': 'Feb', '03': 'Mar', '04': 'Apr',
    '05': 'May', '06': 'Jun', '07': 'Jul', '08': 'Aug',
    '09': 'Sep', '10': 'Oct', '11': 'Nov', '12': 'Dec',
  }
  const [year, mon] = m.split('-')
  return `${NAMES[mon] ?? mon} ${year}`
}

export function fmtNum(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M'
  if (n >= 1_000) return (n / 1_000).toFixed(1) + 'k'
  return String(n)
}

export function passRateColor(pct: number): string {
  if (pct >= 95) return '#1B5E20'
  if (pct >= 80) return '#E65100'
  return '#C62828'
}

export function passRateVariant(pct: number): 'green' | 'amber' | 'red' {
  if (pct >= 95) return 'green'
  if (pct >= 80) return 'amber'
  return 'red'
}

export function computeNarrativeFromPivot(
  data: Record<string, number | string>[],
  ragCols: string[],
  dimCol: string,
  totalCol: string,
  gt: Record<string, number>,
): string {
  if (!data.length || !ragCols.length) return ''

  const totalRules = totalCol
    ? (gt[totalCol] ?? ragCols.reduce((s, c) => s + (gt[c] ?? 0), 0))
    : ragCols.reduce((s, c) => s + (gt[c] ?? 0), 0)

  const totalPass = ragCols
    .filter(isPass)
    .reduce((s, c) => s + (gt[c] ?? 0), 0)

  const totalFail = ragCols
    .filter(isFail)
    .reduce((s, c) => s + (gt[c] ?? 0), 0)

  const totalAmber = ragCols
    .filter((c) => normaliseRag(c) === 'amber')
    .reduce((s, c) => s + (gt[c] ?? 0), 0)

  const passRate = totalRules > 0 ? ((totalPass / totalRules) * 100).toFixed(1) : '0.0'

  const failingCDEs = data
    .filter((row) => {
      const fail = ragCols.filter(isFail).reduce((s, c) => s + (Number(row[c]) || 0), 0)
      return fail > 0
    })
    .map((row) => String(row[dimCol] ?? ''))
    .filter(Boolean)
    .slice(0, 3)

  let narrative = `This scorecard covers ${totalRules.toLocaleString()} rules with an overall pass rate of ${passRate}%. `

  if (totalFail > 0) {
    narrative += `${totalFail.toLocaleString()} rule${totalFail !== 1 ? 's' : ''} are in Red (failed) status. `
  }
  if (totalAmber > 0) {
    narrative += `${totalAmber.toLocaleString()} rule${totalAmber !== 1 ? 's' : ''} are Amber (at risk). `
  }
  if (failingCDEs.length > 0) {
    narrative += `CDEs with failures include: ${failingCDEs.join(', ')}${failingCDEs.length === 3 ? ' and others' : ''}.`
  } else if (totalFail === 0) {
    narrative += 'All CDEs are currently passing.'
  }

  return narrative
}
