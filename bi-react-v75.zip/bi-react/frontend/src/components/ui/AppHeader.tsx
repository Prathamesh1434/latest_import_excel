import { useNavigate } from 'react-router-dom'
import { useAppStore } from '@/store/appStore'

interface HeaderProps {
  onSearch?: (q: string) => void
  showSearch?: boolean
}

export function AppHeader({ onSearch, showSearch = false }: HeaderProps) {
  const user = useAppStore((s) => s.user)
  const setUser = useAppStore((s) => s.setUser)
  const navigate = useNavigate()

  function handleLogout() {
    setUser(null)
    navigate('/login')
  }

  const initials = (user?.name ?? user?.user_id ?? '?')
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  return (
    <header className="fixed top-0 left-0 right-0 h-14 z-[1000] bg-navy border-b border-white/[0.06] flex items-center px-6 gap-4 shadow-[0_2px_16px_rgba(0,0,0,.25)]">
      {/* Brand */}
      <div className="flex items-center gap-3 flex-shrink-0">
        <div className="w-[34px] h-[34px] rounded-lg bg-gradient-to-br from-blue-bright to-accent flex items-center justify-center shadow-md shadow-blue-bright/30">
          <svg className="w-[18px] h-[18px] text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <rect x="3" y="3" width="18" height="18" rx="3"/>
            <path d="M3 9h18M9 3v18"/>
          </svg>
        </div>
        <div>
          <h1 className="text-sm font-bold text-white tracking-tight leading-tight">B&amp;I CDE Intelligence</h1>
          <span className="text-2xs text-white/40 uppercase tracking-widest font-normal">v7.5 Enterprise</span>
        </div>
      </div>

      {/* Divider */}
      <div className="w-px h-7 bg-white/10 flex-shrink-0" />

      {/* Search */}
      {showSearch && (
        <div className="flex-1 max-w-96 relative">
          <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 w-[15px] h-[15px] text-white/35 pointer-events-none" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="7"/>
            <path d="M21 21l-4-4"/>
          </svg>
          <input
            type="text"
            placeholder="Search scorecards... (Ctrl+K)"
            onChange={(e) => onSearch?.(e.target.value)}
            className="w-full h-9 rounded-lg bg-white/[0.07] border border-white/[0.12] text-white placeholder:text-white/35 pl-9 pr-3 text-xs outline-none transition-all duration-150 focus:bg-white/[0.11] focus:border-blue-bright/50"
          />
        </div>
      )}

      {/* Right */}
      <div className="ml-auto flex items-center gap-2.5">
        {/* Status indicator */}
        <div className="flex items-center gap-1.5 px-2.5 text-xs text-white/45">
          <span className="w-1.5 h-1.5 rounded-full bg-rag-green-soft animate-pulseDot" />
          All systems operational
        </div>

        <div className="w-px h-7 bg-white/10" />

        {/* Admin link — only for admin role */}
        {user?.role === 'admin' && (
          <a
            href="/dashboard.html"
            className="h-[34px] px-3.5 rounded-lg text-xs font-semibold text-white/70 border border-white/15 flex items-center gap-1.5 hover:bg-white/[0.08] hover:text-white transition-all duration-150"
          >
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 20h9M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
            </svg>
            Admin
          </a>
        )}

        {/* User pill */}
        {user && (
          <div className="flex items-center gap-2 pl-1 pr-3 py-1 bg-white/[0.07] rounded-full border border-white/10">
            <div className="w-6.5 h-6.5 rounded-full bg-gradient-to-br from-blue-bright to-accent flex items-center justify-center text-2xs font-bold text-white">
              {initials}
            </div>
            <div>
              <div className="text-xs font-medium text-white/80 leading-tight">{user.name ?? user.user_id}</div>
              <div className="text-2xs text-white/40 capitalize">{user.role}</div>
            </div>
          </div>
        )}

        {/* Logout */}
        <button
          onClick={handleLogout}
          title="Sign out"
          className="w-8 h-8 rounded-lg flex items-center justify-center text-white/40 hover:bg-white/[0.08] hover:text-white/80 transition-all duration-150"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/>
          </svg>
        </button>
      </div>
    </header>
  )
}
