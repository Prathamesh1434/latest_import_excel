import { clsx } from 'clsx'
import type { ReactNode } from 'react'

// ─── BADGE ───────────────────────────────────────────────────────
interface BadgeProps {
  children: ReactNode
  variant?: 'entity' | 'stale' | 'tier1' | 'tier2' | 'tier3'
  className?: string
}
export function Badge({ children, variant = 'entity', className }: BadgeProps) {
  return (
    <span
      className={clsx(
        'inline-block text-2xs font-bold px-2 py-0.5 rounded-xl uppercase tracking-wide flex-shrink-0',
        variant === 'entity' && 'bg-blue-brand/10 text-blue-brand',
        variant === 'stale' && 'bg-amber-100 text-rag-amber',
        variant === 'tier1' && 'bg-blue-50 text-blue-brand',
        variant === 'tier2' && 'bg-amber-50 text-rag-amber',
        variant === 'tier3' && 'bg-purple-50 text-purple-700',
        className,
      )}
    >
      {children}
    </span>
  )
}

// ─── BUTTON ──────────────────────────────────────────────────────
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'ghost'
  size?: 'sm' | 'md'
  children: ReactNode
}
export function Button({
  variant = 'primary',
  size = 'md',
  children,
  className,
  ...props
}: ButtonProps) {
  return (
    <button
      {...props}
      className={clsx(
        'inline-flex items-center gap-1.5 font-semibold rounded transition-all duration-150 disabled:opacity-40 disabled:cursor-not-allowed',
        size === 'sm' && 'h-8 px-3 text-xs',
        size === 'md' && 'h-9 px-4 text-sm',
        variant === 'primary' && 'bg-navy text-white hover:bg-blue-brand',
        variant === 'outline' &&
          'border border-border bg-white text-ink-sec hover:border-blue-brand hover:text-blue-brand',
        variant === 'ghost' &&
          'text-ink-sec hover:bg-surface hover:text-navy',
        className,
      )}
    >
      {children}
    </button>
  )
}

// ─── KPI CARD ────────────────────────────────────────────────────
interface KpiCardProps {
  label: string
  value: string | number
  sub?: string
  variant?: 'default' | 'red' | 'green' | 'amber' | 'blue'
}
export function KpiCard({ label, value, sub, variant = 'default' }: KpiCardProps) {
  const accent = {
    default: 'after:bg-navy',
    blue: 'after:bg-blue-bright',
    red: 'after:bg-rag-red',
    green: 'after:bg-rag-green-soft',
    amber: 'after:bg-rag-amber-soft',
  }[variant]

  const valueColor = {
    default: 'text-navy',
    blue: 'text-navy',
    red: 'text-rag-red',
    green: 'text-rag-green',
    amber: 'text-rag-amber',
  }[variant]

  return (
    <div
      className={clsx(
        'bg-surface-card border border-border rounded p-4 shadow-sm relative overflow-hidden',
        "after:content-[''] after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[3px] after:rounded-b",
        accent,
      )}
    >
      <div className="text-2xs font-bold uppercase tracking-wider text-ink-dim mb-2">{label}</div>
      <div className={clsx('text-4xl font-bold font-mono leading-none tracking-tight', valueColor)}>
        {value}
      </div>
      {sub && <div className="text-xs text-ink-dim mt-1.5">{sub}</div>}
    </div>
  )
}

// ─── SKELETON ────────────────────────────────────────────────────
export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={clsx(
        'rounded animate-shimmer',
        'bg-gradient-to-r from-slate-100 via-slate-50 to-slate-100 bg-[length:200%_100%]',
        className,
      )}
    />
  )
}

export function SkeletonCard() {
  return <Skeleton className="h-44 rounded-lg" />
}

// ─── RAG CHIP ────────────────────────────────────────────────────
interface RagChipProps {
  value: string | number
  label?: string
}
export function RagChip({ value, label }: RagChipProps) {
  const k = (label ?? String(value)).toLowerCase().replace('_', ' ').trim()
  const styles: Record<string, string> = {
    red: 'bg-rag-red/10 text-rag-red before:bg-rag-red',
    amber: 'bg-rag-amber/10 text-rag-amber before:bg-rag-amber-soft',
    green: 'bg-rag-green/10 text-rag-green before:bg-rag-green-soft',
    'dark green': 'bg-rag-dkgreen/10 text-rag-dkgreen before:bg-rag-dkgreen-soft',
  }
  const style = styles[k] ?? 'bg-border text-ink-sec'
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1 px-2 py-0.5 rounded-xl text-2xs font-bold",
        "before:content-[''] before:w-1.5 before:h-1.5 before:rounded-full",
        style,
      )}
    >
      {value}
    </span>
  )
}

// ─── SPINNER ─────────────────────────────────────────────────────
export function Spinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const sz = { sm: 'w-4 h-4', md: 'w-6 h-6', lg: 'w-8 h-8' }[size]
  return (
    <div
      className={clsx(
        sz,
        'rounded-full border-2 border-border border-t-blue-brand animate-spin',
      )}
    />
  )
}

// ─── SECTION HEADER ──────────────────────────────────────────────
interface SectionHeaderProps {
  title: string
  sub?: string
  icon?: ReactNode
  action?: ReactNode
}
export function SectionHeader({ title, sub, icon, action }: SectionHeaderProps) {
  return (
    <div className="flex items-center justify-between mb-3">
      <div className="flex items-center gap-2">
        {icon && <span className="text-ink-dim">{icon}</span>}
        <span className="text-2xs font-bold uppercase tracking-wide text-ink-dim">
          {title}
        </span>
        {sub && <span className="text-xs text-ink-dim">{sub}</span>}
      </div>
      {action}
    </div>
  )
}

// ─── PANEL BOX ───────────────────────────────────────────────────
interface PanelBoxProps {
  children: ReactNode
  className?: string
  title?: string
  icon?: ReactNode
  action?: ReactNode
}
export function PanelBox({ children, className, title, icon, action }: PanelBoxProps) {
  return (
    <div className={clsx('bg-surface-card border border-border rounded shadow-sm p-4', className)}>
      {title && <SectionHeader title={title} icon={icon} action={action} />}
      {children}
    </div>
  )
}

// ─── EMPTY STATE ─────────────────────────────────────────────────
export function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex items-center justify-center py-12 text-ink-dim text-sm">
      {message}
    </div>
  )
}

// ─── ERROR STATE ─────────────────────────────────────────────────
export function ErrorState({ message }: { message: string }) {
  return (
    <div className="flex items-center justify-center py-8">
      <span className="text-rag-red text-sm">{message}</span>
    </div>
  )
}
