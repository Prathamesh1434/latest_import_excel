import type {
  User,
  ScorecardSummary,
  PivotDataResponse,
  TrendResponse,
  DataTableRequest,
  DataTableResponse,
  LandingResponse,
  MonthEntry,
  MoMResponse,
  ChatResponse,
  ChatTier,
} from '@/types'

const BASE = ''

async function request<T>(
  path: string,
  options?: RequestInit,
  userId?: string,
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options?.headers as Record<string, string>),
  }
  if (userId) headers['x-user-id'] = userId

  const res = await fetch(BASE + path, { ...options, headers })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail ?? `Request failed: ${res.status}`)
  }
  return res.json() as Promise<T>
}

// ─── AUTH ────────────────────────────────────────────────────────
export async function login(wwid: string): Promise<User> {
  return request<User>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ wwid: wwid.toUpperCase() }),
  })
}

// ─── SCORECARDS ──────────────────────────────────────────────────
export async function listScorecards(): Promise<ScorecardSummary[]> {
  return request<ScorecardSummary[]>('/scorecards/list')
}

// ─── LANDING KPI ─────────────────────────────────────────────────
export async function getLanding(scorecardId: string): Promise<LandingResponse> {
  return request<LandingResponse>(`/data/${scorecardId}/landing`)
}

// ─── PIVOT DATA ──────────────────────────────────────────────────
export async function getPivotData(
  scorecardId: string,
  sheetName: string,
  month?: string,
): Promise<PivotDataResponse> {
  const monthParam = month ? `?month=${encodeURIComponent(month)}` : ''
  return request<PivotDataResponse>(
    `/data/${scorecardId}/pivot-data/${encodeURIComponent(sheetName)}${monthParam}`,
  )
}

export async function getPivotTrend(
  scorecardId: string,
  sheetName: string,
  metric = 'Row_Total',
  cde?: string,
): Promise<TrendResponse> {
  const cdeParam = cde ? `&cde=${encodeURIComponent(cde)}` : ''
  return request<TrendResponse>(
    `/data/${scorecardId}/pivot-trend/${encodeURIComponent(sheetName)}?metric=${metric}${cdeParam}`,
  )
}

// ─── DATA TABLE ──────────────────────────────────────────────────
export async function getDataTable(
  scorecardId: string,
  body: DataTableRequest,
): Promise<DataTableResponse> {
  return request<DataTableResponse>(`/data/${scorecardId}/data-table`, {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function getColumnValues(
  scorecardId: string,
  column: string,
): Promise<{ column: string; values: string[]; total: number }> {
  return request(`/data/${scorecardId}/column-values/${encodeURIComponent(column)}`)
}

export async function exportCsv(
  scorecardId: string,
  filters: DataTableRequest['filters'],
): Promise<Blob> {
  const res = await fetch(`${BASE}/data/${scorecardId}/export-csv`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ filters }),
  })
  if (!res.ok) throw new Error('Export failed')
  return res.blob()
}

// ─── SHEETS ──────────────────────────────────────────────────────
export async function getSheetData(
  scorecardId: string,
  sheetName: string,
  limit = 200,
): Promise<Record<string, unknown>[]> {
  return request(`/data/${scorecardId}/sheets/${encodeURIComponent(sheetName)}/data?limit=${limit}`)
}

// ─── MONTHS ──────────────────────────────────────────────────────
export async function listMonths(scorecardId: string): Promise<MonthEntry[]> {
  return request<MonthEntry[]>(`/data/${scorecardId}/months`)
}

export async function addMonth(
  scorecardId: string,
  reportingMonth: string,
  file: File,
): Promise<{ row_count: number; sheet_count: number }> {
  const fd = new FormData()
  fd.append('reporting_month', reportingMonth)
  fd.append('data_file', file)
  const res = await fetch(`${BASE}/data/${scorecardId}/add-month`, {
    method: 'POST',
    body: fd,
  })
  if (!res.ok) throw new Error('Upload failed')
  return res.json()
}

export async function momCompare(
  scorecardId: string,
  periodA: string,
  periodB: string,
): Promise<MoMResponse> {
  return request<MoMResponse>(`/data/${scorecardId}/mom-compare`, {
    method: 'POST',
    body: JSON.stringify({ period_a: periodA, period_b: periodB }),
  })
}

// ─── CHAT ────────────────────────────────────────────────────────
export async function chatQuery(
  scorecardId: string,
  question: string,
  mode: ChatTier,
  userId: string,
): Promise<ChatResponse> {
  return request<ChatResponse>(
    '/chat/query',
    {
      method: 'POST',
      body: JSON.stringify({ scorecard_id: scorecardId, question, mode }),
    },
    userId,
  )
}

export async function getChatHistory(
  scorecardId: string,
  userId: string,
): Promise<{ role: string; content: string; timestamp: string }[]> {
  return request(`/chat/history/${scorecardId}`, {}, userId)
}
