import { useState, useCallback, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getDataTable, exportCsv } from '@/api'
import { Button, Skeleton } from '@/components/ui/index'
import type { DataTableFilter, ColumnMeta } from '@/types'

interface DataTableProps {
  scorecardId: string
  initialFilters?: DataTableFilter[]
  onFiltersCleared?: () => void
}

export function DataTableFeature({ scorecardId, initialFilters = [], onFiltersCleared }: DataTableProps) {
  const [page, setPage] = useState(1)
  const [perPage] = useState(50)
  const [sortCol, setSortCol] = useState('')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc')
  const [appliedFilters, setAppliedFilters] = useState<DataTableFilter[]>(initialFilters)
  const [pendingFilters, setPendingFilters] = useState<DataTableFilter[]>(initialFilters)
  const [exporting, setExporting] = useState(false)

  // When drill filters arrive from heatmap click, apply them immediately
  useEffect(() => {
    if (initialFilters.length > 0) {
      setAppliedFilters(initialFilters)
      setPendingFilters(initialFilters)
      setPage(1)
    }
  }, [JSON.stringify(initialFilters)])

  const { data, isLoading } = useQuery({
    queryKey: ['dataTable', scorecardId, page, perPage, sortCol, sortDir, appliedFilters],
    queryFn: () =>
      getDataTable(scorecardId, {
        page,
        per_page: perPage,
        sort_col: sortCol,
        sort_dir: sortDir,
        filters: appliedFilters,
      }),
    enabled: Boolean(scorecardId),
    staleTime: 60_000,
    placeholderData: (prev) => prev,
  })

  const columns: ColumnMeta[] = data?.columns ?? []

  function handleSort(col: string) {
    if (sortCol === col) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    } else {
      setSortCol(col)
      setSortDir('asc')
    }
    setPage(1)
  }

  function addFilterRow() {
    setPendingFilters((prev) => [...prev, { column: '', operator: 'equals', value: '' }])
  }

  function updateFilter(i: number, key: keyof DataTableFilter, value: string) {
    setPendingFilters((prev) =>
      prev.map((f, idx) => (idx === i ? { ...f, [key]: value } : f)),
    )
  }

  function removeFilter(i: number) {
    setPendingFilters((prev) => prev.filter((_, idx) => idx !== i))
  }

  function applyFilters() {
    const valid = pendingFilters.filter((f) => f.column && f.value)
    setAppliedFilters(valid)
    setPage(1)
    if (valid.length === 0) onFiltersCleared?.()
  }

  function clearAllFilters() {
    setPendingFilters([])
    setAppliedFilters([])
    setPage(1)
    onFiltersCleared?.()
  }

  const handleExport = useCallback(async () => {
    setExporting(true)
    try {
      const blob = await exportCsv(scorecardId, appliedFilters)
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `${scorecardId}_export.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch (e) {
      console.error('Export failed', e)
    } finally {
      setExporting(false)
    }
  }, [scorecardId, appliedFilters])

  const hasActiveDrill = appliedFilters.length > 0 && initialFilters.length > 0 &&
    JSON.stringify(appliedFilters) === JSON.stringify(initialFilters)

  return (
    <div>
      {/* Drill-through banner */}
      {hasActiveDrill && (
        <div className="flex items-center gap-3 mb-3 px-3 py-2 bg-blue-brand/[0.06] border border-blue-brand/20 rounded text-xs text-blue-brand">
          <svg className="w-3.5 h-3.5 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
          </svg>
          <span className="font-medium">Drill-through active:</span>
          <span className="text-ink-sec">
            {appliedFilters.map((f) => `${f.column} = ${f.value}`).join(' AND ')}
          </span>
          <button
            onClick={clearAllFilters}
            className="ml-auto text-rag-red font-semibold hover:underline flex-shrink-0"
          >
            Clear
          </button>
        </div>
      )}

      {/* Filter bar */}
      <div className="bg-surface-card border border-border rounded shadow-sm p-3 mb-4 flex flex-wrap gap-2 items-center">
        {pendingFilters.map((f, i) => (
          <div
            key={i}
            className="flex items-center gap-1.5 bg-surface px-2 py-1 rounded border border-border"
          >
            <select
              value={f.column}
              onChange={(e) => updateFilter(i, 'column', e.target.value)}
              className="h-7 border-none bg-transparent text-xs outline-none text-ink min-w-[110px]"
            >
              <option value="">Column</option>
              {columns.map((c) => (
                <option key={c.raw} value={c.raw}>
                  {c.clean}
                </option>
              ))}
            </select>
            <select
              value={f.operator}
              onChange={(e) =>
                updateFilter(i, 'operator', e.target.value as DataTableFilter['operator'])
              }
              className="h-7 border-none bg-transparent text-xs outline-none text-ink"
            >
              <option value="equals">Equals</option>
              <option value="not_equals">Not Equals</option>
              <option value="contains">Contains</option>
              <option value="greater_than">Greater Than</option>
              <option value="less_than">Less Than</option>
            </select>
            <input
              type="text"
              value={f.value}
              onChange={(e) => updateFilter(i, 'value', e.target.value)}
              placeholder="Value..."
              className="h-7 border-none bg-transparent text-xs outline-none text-ink w-28"
            />
            <button
              onClick={() => removeFilter(i)}
              className="w-5 h-5 rounded-full flex items-center justify-center text-rag-red-soft font-bold text-sm hover:bg-rag-red/10 transition-colors"
            >
              ×
            </button>
          </div>
        ))}
        <button
          onClick={addFilterRow}
          className="text-xs font-semibold text-blue-brand hover:bg-blue-brand/[0.08] px-2.5 py-1.5 rounded transition-colors"
        >
          + Add Filter
        </button>
        {pendingFilters.length > 0 && (
          <Button variant="outline" size="sm" onClick={applyFilters}>
            Apply
          </Button>
        )}
        {appliedFilters.length > 0 && (
          <Button variant="ghost" size="sm" onClick={clearAllFilters}>
            Clear all
          </Button>
        )}
      </div>

      {/* Controls row */}
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs text-ink-sec">
          {data
            ? `Showing ${data.rows.length} of ${data.total_rows.toLocaleString()} rows (page ${data.page} / ${data.total_pages})`
            : 'Loading...'}
        </span>
        <Button variant="primary" size="sm" onClick={handleExport} disabled={exporting}>
          {exporting ? 'Exporting...' : 'Export CSV'}
        </Button>
      </div>

      {/* Table */}
      {isLoading ? (
        <Skeleton className="h-64" />
      ) : (
        <div className="bg-surface-card border border-border rounded shadow-sm overflow-auto max-h-[520px]">
          <table className="w-full">
            <thead>
              <tr>
                {columns.map((c) => (
                  <th
                    key={c.raw}
                    onClick={() => handleSort(c.raw)}
                    className={`sticky top-0 bg-surface-raised px-3 py-2 text-2xs font-semibold uppercase tracking-wide text-left cursor-pointer whitespace-nowrap border-b-2 border-border hover:bg-border transition-colors select-none ${
                      sortCol === c.raw ? 'text-blue-brand' : 'text-ink-sec'
                    }`}
                  >
                    {c.clean}
                    {sortCol === c.raw && (
                      <span className="ml-1 text-2xs">
                        {sortDir === 'asc' ? '▲' : '▼'}
                      </span>
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(data?.rows ?? []).map((row, i) => (
                <tr key={i} className="hover:bg-blue-brand/[0.025] transition-colors">
                  {columns.map((c) => {
                    const v = row[c.raw] ?? ''
                    const vl = String(v).toLowerCase()
                    let cls = ''
                    if (vl === 'red') cls = 'text-rag-red font-bold bg-rag-red/[0.06]'
                    else if (vl === 'amber') cls = 'text-rag-amber font-bold bg-rag-amber/[0.06]'
                    else if (vl === 'dark green') cls = 'text-rag-dkgreen font-bold bg-rag-dkgreen/[0.06]'
                    else if (vl === 'green') cls = 'text-rag-green font-bold bg-rag-green/[0.06]'
                    return (
                      <td
                        key={c.raw}
                        className={`px-3 py-1.5 text-xs border-b border-black/[0.04] whitespace-nowrap ${cls}`}
                      >
                        {String(v)}
                      </td>
                    )
                  })}
                </tr>
              ))}
              {!isLoading && (data?.rows ?? []).length === 0 && (
                <tr>
                  <td
                    colSpan={columns.length || 1}
                    className="px-4 py-8 text-center text-ink-dim text-sm"
                  >
                    No records match the current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {data && data.total_pages > 1 && (
        <div className="flex items-center justify-center gap-1.5 mt-4">
          <PgBtn disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            &lt;
          </PgBtn>
          {Array.from({ length: data.total_pages }, (_, i) => i + 1)
            .filter((p) => Math.abs(p - page) <= 3)
            .map((p) => (
              <PgBtn key={p} active={p === page} onClick={() => setPage(p)}>
                {p}
              </PgBtn>
            ))}
          <span className="text-xs text-ink-sec mx-2">
            {page} / {data.total_pages}
          </span>
          <PgBtn
            disabled={page >= data.total_pages}
            onClick={() => setPage((p) => p + 1)}
          >
            &gt;
          </PgBtn>
        </div>
      )}
    </div>
  )
}

function PgBtn({
  children,
  active,
  disabled,
  onClick,
}: {
  children: React.ReactNode
  active?: boolean
  disabled?: boolean
  onClick?: () => void
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`w-8 h-8 rounded-lg border text-xs font-medium flex items-center justify-center transition-all duration-150 disabled:opacity-30 disabled:cursor-not-allowed ${
        active
          ? 'bg-navy text-white border-navy'
          : 'bg-white border-border text-ink-sec hover:border-blue-brand hover:text-blue-brand'
      }`}
    >
      {children}
    </button>
  )
}
