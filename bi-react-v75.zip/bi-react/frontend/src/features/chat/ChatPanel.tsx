import { useState, useRef, useEffect, useCallback } from 'react'
import { useMutation } from '@tanstack/react-query'
import { ResponsiveBar } from '@nivo/bar'
import { ResponsivePie } from '@nivo/pie'
import { ResponsiveLine } from '@nivo/line'
import { chatQuery } from '@/api'
import { useAppStore } from '@/store/appStore'
import type { ChatMessage, ChatTier, ChatChart, ScorecardSummary } from '@/types'

interface ChatPanelProps {
  scorecard: ScorecardSummary
}

// RBAC: which tiers each role can access
const ROLE_TIERS: Record<string, ChatTier[]> = {
  admin: ['auto', 't1', 't2', 't3'],
  analyst: ['auto', 't1', 't2'],
  viewer: ['auto', 't1', 't2'],
}

const TIER_LABELS: Record<ChatTier, string> = {
  auto: 'AUTO',
  t1: 'T1 — Direct',
  t2: 'T2 — Semantic',
  t3: 'T3 — Gemini',
}

export function ChatPanel({ scorecard }: ChatPanelProps) {
  const user = useAppStore((s) => s.user)
  const chatPanelWidth = useAppStore((s) => s.chatPanelWidth)
  const setChatPanelWidth = useAppStore((s) => s.setChatPanelWidth)

  const userRole = user?.role ?? 'viewer'
  const allowedTiers = ROLE_TIERS[userRole] ?? ROLE_TIERS.viewer

  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [mode, setMode] = useState<ChatTier>('auto')

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const isDragging = useRef(false)
  const startX = useRef(0)
  const startW = useRef(0)

  // Welcome message + proactive summary on scorecard change
  useEffect(() => {
    setMessages([
      {
        id: 'welcome',
        role: 'bot',
        content: `Welcome to <strong>${escHtml(scorecard.display_title || scorecard.display_name)}</strong>. Ask me about CDE rules, pass rates, anomalies, or trends.`,
        timestamp: new Date(),
      },
    ])
    if (scorecard.pivot_sheet_names?.length || scorecard.questions?.length) {
      setTimeout(() => sendMessage('proactive summary'), 900)
    }
  }, [scorecard.scorecard_id])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Reset mode if not allowed for this role
  useEffect(() => {
    if (!allowedTiers.includes(mode)) {
      setMode('auto')
    }
  }, [userRole])

  const mutation = useMutation({
    mutationFn: (q: string) =>
      chatQuery(scorecard.scorecard_id, q, mode, user?.user_id ?? 'PG23137'),
    onSuccess: (data) => {
      setMessages((prev) => {
        const filtered = prev.filter((m) => m.id !== 'typing')
        return [
          ...filtered,
          {
            id: `bot-${Date.now()}`,
            role: 'bot',
            content: data.reply ?? '',
            meta: {
              tier: data.tier,
              tier_label: data.tier_label,
              confidence: data.confidence,
              latency_ms: data.latency_ms,
              data_source: data.data_source,
              model_used: data.model_used,
              data_freshness: data.data_freshness,
            },
            tableData: data.table_data,
            chart: data.chart ?? data.chart_data,
            timestamp: new Date(),
          },
        ]
      })
    },
    onError: (err: unknown) => {
      setMessages((prev) => {
        const filtered = prev.filter((m) => m.id !== 'typing')
        return [
          ...filtered,
          {
            id: `err-${Date.now()}`,
            role: 'bot',
            content: `Error: ${err instanceof Error ? err.message : 'Request failed'}`,
            timestamp: new Date(),
          },
        ]
      })
    },
  })

  const sendMessage = useCallback(
    (q: string) => {
      const question = q.trim()
      if (!question) return

      if (question !== 'proactive summary') {
        setMessages((prev) => [
          ...prev,
          {
            id: `user-${Date.now()}`,
            role: 'user',
            content: question,
            timestamp: new Date(),
          },
        ])
      }

      setMessages((prev) => [
        ...prev,
        { id: 'typing', role: 'bot', content: '', timestamp: new Date() },
      ])

      mutation.mutate(question)
    },
    [mutation],
  )

  function handleSend() {
    if (!input.trim() || mutation.isPending) return
    sendMessage(input)
    setInput('')
  }

  // Chat panel resize
  function onResizeMouseDown(e: React.MouseEvent) {
    isDragging.current = true
    startX.current = e.clientX
    startW.current = panelRef.current?.offsetWidth ?? chatPanelWidth
    document.body.style.cursor = 'col-resize'
    document.body.style.userSelect = 'none'
    e.preventDefault()
  }

  useEffect(() => {
    function onMove(e: MouseEvent) {
      if (!isDragging.current || !panelRef.current) return
      const dx = startX.current - e.clientX
      const nw = Math.min(560, Math.max(280, startW.current + dx))
      panelRef.current.style.width = `${nw}px`
    }
    function onUp() {
      if (!isDragging.current) return
      isDragging.current = false
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
      if (panelRef.current) setChatPanelWidth(panelRef.current.offsetWidth)
    }
    document.addEventListener('mousemove', onMove)
    document.addEventListener('mouseup', onUp)
    return () => {
      document.removeEventListener('mousemove', onMove)
      document.removeEventListener('mouseup', onUp)
    }
  }, [setChatPanelWidth])

  return (
    <div
      ref={panelRef}
      className="flex flex-col bg-white border-l border-border relative flex-shrink-0"
      style={{ width: chatPanelWidth, minWidth: 280, maxWidth: 560 }}
    >
      {/* Resize handle */}
      <div
        onMouseDown={onResizeMouseDown}
        className="absolute left-0 top-0 bottom-0 w-1 cursor-col-resize z-10 hover:bg-blue-brand transition-colors duration-150"
      />

      {/* Header */}
      <div className="flex items-center gap-2.5 px-4 py-3 border-b border-border flex-shrink-0">
        <div className="flex items-center gap-1.5 flex-1 min-w-0">
          <div className="w-2 h-2 rounded-full bg-rag-green-soft animate-pulseDot flex-shrink-0" />
          <h3 className="text-sm font-bold text-navy truncate">Intelligence Chat</h3>
        </div>
        <select
          value={mode}
          onChange={(e) => setMode(e.target.value as ChatTier)}
          className="text-xs px-2 py-1 rounded border border-border bg-surface text-ink-sec cursor-pointer outline-none focus:border-blue-brand"
        >
          {allowedTiers.map((t) => (
            <option key={t} value={t}>
              {TIER_LABELS[t]}
            </option>
          ))}
        </select>
      </div>

      {/* Role badge if not admin */}
      {userRole !== 'admin' && (
        <div className="px-4 py-1.5 bg-surface border-b border-border flex-shrink-0">
          <span className="text-2xs text-ink-dim">
            {userRole === 'analyst' ? 'Analyst: T1 + T2 access' : 'Viewer: T1 + T2 access'}
            {' — '}
            <span className="text-ink-dim">T3 Gemini requires admin</span>
          </span>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-3.5 py-3 flex flex-col gap-2.5 min-h-0">
        {messages.map((msg) => (
          <MessageBubble key={msg.id} msg={msg} />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested questions */}
      {scorecard.questions && scorecard.questions.length > 0 && (
        <div className="flex flex-wrap gap-1.5 px-3.5 py-2 border-t border-border flex-shrink-0">
          {scorecard.questions.slice(0, 5).map((q) => (
            <button
              key={q}
              onClick={() => sendMessage(q)}
              className="text-xs px-2.5 py-1 rounded-xl border border-border text-ink-sec bg-white hover:border-blue-brand hover:text-blue-brand transition-all duration-150 whitespace-nowrap"
            >
              {q}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="px-3.5 pb-4 pt-2.5 border-t border-border flex gap-2 items-end flex-shrink-0">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              handleSend()
            }
          }}
          placeholder="Ask about CDE rules, pass rates, trends..."
          rows={1}
          className="flex-1 border border-border rounded-lg px-3 py-2 text-sm resize-none min-h-[38px] max-h-[120px] outline-none transition-all duration-150 bg-surface-raised focus:border-blue-brand focus:bg-white focus:shadow-[0_0_0_3px_rgba(21,101,192,.08)]"
        />
        <button
          onClick={handleSend}
          disabled={!input.trim() || mutation.isPending}
          className="w-10 h-10 rounded-lg bg-navy text-white flex items-center justify-center flex-shrink-0 hover:bg-blue-brand transition-colors duration-150 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <svg
            className="w-4 h-4"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
          >
            <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/>
          </svg>
        </button>
      </div>
    </div>
  )
}

// ─── MESSAGE BUBBLE ──────────────────────────────────────────────
function MessageBubble({ msg }: { msg: ChatMessage }) {
  if (msg.id === 'typing') {
    return (
      <div className="flex gap-1.5 px-3 py-2.5 bg-surface-raised border border-border rounded-xl rounded-bl-sm self-start">
        {[0, 150, 300].map((delay) => (
          <span
            key={delay}
            className="w-1.5 h-1.5 rounded-full bg-ink-dim animate-bounceUp"
            style={{ animationDelay: `${delay}ms` }}
          />
        ))}
      </div>
    )
  }

  if (msg.role === 'user') {
    return (
      <div className="self-end bg-navy text-white px-3.5 py-2.5 rounded-xl rounded-br-sm max-w-[92%] text-sm leading-relaxed animate-slideIn">
        {msg.content}
      </div>
    )
  }

  const tierCls =
    msg.meta?.tier === 1
      ? 'bg-blue-50 text-blue-brand'
      : msg.meta?.tier === 2
      ? 'bg-amber-50 text-rag-amber'
      : msg.meta?.tier === 3
      ? 'bg-purple-50 text-purple-700'
      : ''
  const tierLabel = msg.meta?.tier_label

  return (
    <div className="self-start bg-surface-raised border border-border rounded-xl rounded-bl-sm max-w-[94%] px-3.5 py-2.5 text-sm leading-relaxed animate-fadeIn">
      {tierLabel && (
        <span
          className={`inline-block text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded mb-2 ${tierCls}`}
        >
          {tierLabel}
        </span>
      )}
      {tierLabel && <br />}
      <div
        className="text-ink"
        dangerouslySetInnerHTML={{ __html: parseMarkdown(msg.content) }}
      />
      {msg.tableData && msg.tableData.length > 0 && (
        <ChatTable data={msg.tableData} />
      )}
      {msg.chart && <ChatChartRenderer chart={msg.chart} />}
      {msg.meta && (
        <div className="text-[10px] text-ink-dim mt-2">
          {msg.meta.latency_ms}ms &middot; {msg.meta.data_source}
        </div>
      )}
    </div>
  )
}

function ChatTable({ data }: { data: Record<string, unknown>[] }) {
  const cols = Object.keys(data[0])
  return (
    <div className="mt-2 overflow-auto rounded border border-border">
      <table className="w-full text-[11px]">
        <thead>
          <tr>
            {cols.map((c) => (
              <th
                key={c}
                className="bg-surface px-2.5 py-1.5 text-left font-semibold text-ink-sec border-b border-border whitespace-nowrap"
              >
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.slice(0, 10).map((row, i) => (
            <tr key={i} className="border-b border-black/[0.04]">
              {cols.map((c) => (
                <td key={c} className="px-2.5 py-1 whitespace-nowrap">
                  {String(row[c] ?? '')}
                </td>
              ))}
            </tr>
          ))}
          {data.length > 10 && (
            <tr>
              <td
                colSpan={cols.length}
                className="px-2.5 py-1 text-center text-ink-dim italic"
              >
                ...and {data.length - 10} more rows
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  )
}

function ChatChartRenderer({ chart }: { chart: ChatChart }) {
  const type = chart.chart_type ?? chart.type ?? 'bar'
  const COLORS = ['#1565C0', '#C62828', '#4CAF50', '#FF9800', '#6B21A8', '#00BCD4']

  if (type === 'pie' || type === 'doughnut') {
    const pieData = (chart.labels ?? []).map((l, i) => ({
      id: l,
      label: l,
      value: chart.data?.[i] ?? chart.datasets?.[0]?.data?.[i] ?? 0,
      color: chart.colors?.[i] ?? COLORS[i % COLORS.length],
    }))
    return (
      <div className="mt-2" style={{ height: 180 }}>
        <ResponsivePie
          data={pieData}
          margin={{ top: 10, right: 80, bottom: 10, left: 80 }}
          innerRadius={type === 'doughnut' ? 0.55 : 0}
          padAngle={2}
          cornerRadius={3}
          colors={{ datum: 'data.color' }}
          borderWidth={2}
          borderColor="#FFFFFF"
          enableArcLabels={false}
          arcLinkLabelsSkipAngle={10}
          arcLinkLabelsTextColor="#8898AA"
          arcLinkLabelsThickness={1}
          arcLinkLabelsColor={{ from: 'color' }}
          theme={{ fontSize: 10 }}
        />
      </div>
    )
  }

  const datasets = chart.datasets ?? []

  if (type === 'line') {
    const nivoData = datasets.map((ds, si) => ({
      id: ds.label ?? `Series ${si + 1}`,
      color: (ds.color as string) ?? COLORS[si % COLORS.length],
      data: (chart.labels ?? []).map((l, i) => ({ x: l, y: ds.data?.[i] ?? 0 })),
    }))
    return (
      <div className="mt-2" style={{ height: 160 }}>
        <ResponsiveLine
          data={nivoData}
          margin={{ top: 10, right: 10, bottom: 32, left: 36 }}
          xScale={{ type: 'point' }}
          yScale={{ type: 'linear', min: 'auto', max: 'auto' }}
          curve="monotoneX"
          colors={nivoData.map((d) => d.color)}
          lineWidth={2}
          pointSize={4}
          enableArea
          areaOpacity={0.06}
          axisBottom={{ tickSize: 0, tickPadding: 6, tickRotation: -20 }}
          axisLeft={{ tickSize: 0, tickPadding: 6, tickValues: 4 }}
          theme={{ fontSize: 10, axis: { ticks: { text: { fontSize: 10, fill: '#8898AA' } } } }}
          useMesh
        />
      </div>
    )
  }

  const barData = (chart.labels ?? []).map((label, li) => {
    const obj: Record<string, string | number> = { label }
    datasets.forEach((ds, si) => {
      obj[ds.label ?? `s${si}`] = ds.data?.[li] ?? 0
    })
    return obj
  })
  const barKeys = datasets.map((ds, si) => ds.label ?? `s${si}`)
  const barColors = datasets.map((ds, si) => (ds.color as string) ?? COLORS[si % COLORS.length])

  return (
    <div className="mt-2" style={{ height: 160 }}>
      <ResponsiveBar
        data={barData}
        keys={barKeys}
        indexBy="label"
        margin={{ top: 10, right: 10, bottom: 36, left: 36 }}
        padding={0.3}
        groupMode={barKeys.length > 1 ? 'grouped' : 'stacked'}
        colors={barColors}
        borderRadius={3}
        enableLabel={false}
        axisBottom={{ tickSize: 0, tickPadding: 6, tickRotation: -20 }}
        axisLeft={{ tickSize: 0, tickPadding: 6, tickValues: 4 }}
        theme={{
          fontSize: 10,
          axis: { ticks: { text: { fontSize: 10, fill: '#8898AA' } } },
          grid: { line: { stroke: 'rgba(0,0,0,.05)' } },
        }}
        legends={
          barKeys.length > 1
            ? [
                {
                  dataFrom: 'keys',
                  anchor: 'bottom',
                  direction: 'row',
                  translateY: 34,
                  itemWidth: 80,
                  itemHeight: 12,
                  symbolSize: 7,
                  symbolShape: 'square',
                  itemTextColor: '#8898AA',
                },
              ]
            : []
        }
        tooltip={({ id, value, indexValue }) => (
          <div className="bg-navy text-white text-xs px-3 py-1.5 rounded shadow-lg">
            {String(indexValue)} / {String(id)}: <strong>{value}</strong>
          </div>
        )}
      />
    </div>
  )
}

// ─── MARKDOWN PARSER ─────────────────────────────────────────────
function parseMarkdown(text: string): string {
  if (!text) return ''
  if (
    text.includes('<table>') ||
    text.includes('<strong>') ||
    text.includes('<br>')
  )
    return text
  let t = text
  t = t.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  t = t.replace(
    /\|(.+)\|\n\|[-| ]+\|\n((?:\|.+\|\n?)+)/g,
    (_m, header: string, body: string) => {
      const ths = header
        .split('|')
        .filter((s) => s.trim())
        .map(
          (s) =>
            `<th class="bg-surface px-2 py-1 text-left font-semibold border-b border-border text-[11px]">${s.trim()}</th>`,
        )
        .join('')
      const rows = body
        .trim()
        .split('\n')
        .map((row) => {
          const tds = row
            .split('|')
            .filter((s) => s.trim())
            .map(
              (s) =>
                `<td class="px-2 py-1 border-b border-black/[0.04] text-[11px]">${s.trim()}</td>`,
            )
            .join('')
          return `<tr>${tds}</tr>`
        })
        .join('')
      return `<table class="w-full border border-border rounded overflow-hidden my-2"><thead><tr>${ths}</tr></thead><tbody>${rows}</tbody></table>`
    },
  )
  t = t.replace(/\n/g, '<br>')
  return t
}

function escHtml(s: string): string {
  const d = document.createElement('div')
  d.textContent = s
  return d.innerHTML
}
