import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { login } from '@/api'
import { useAppStore } from '@/store/appStore'

export function LoginPage() {
  const [wwid, setWwid] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const setUser = useAppStore((s) => s.setUser)
  const navigate = useNavigate()

  async function handleLogin() {
    if (!wwid.trim()) { setError('Please enter your WWID.'); return }
    setLoading(true)
    setError('')
    try {
      const user = await login(wwid.trim())
      setUser(user)
      navigate('/')
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Login failed.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-navy flex items-center justify-center z-50">
      <div className="w-96 p-10 bg-navy-mid rounded-lg border border-white/10 shadow-xl animate-fadeIn">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-11 h-11 rounded-lg bg-gradient-to-br from-blue-bright to-accent flex items-center justify-center shadow-lg shadow-blue-bright/30">
            <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <rect x="3" y="3" width="18" height="18" rx="3"/>
              <path d="M3 9h18M9 3v18"/>
            </svg>
          </div>
          <div>
            <h2 className="text-lg font-bold text-white leading-tight">B&amp;I CDE Intelligence</h2>
            <span className="text-xs text-white/40">Enterprise Data Quality Platform</span>
          </div>
        </div>

        {/* Form */}
        <div className="mb-4">
          <label className="block text-2xs font-bold uppercase tracking-widest text-white/50 mb-1.5">
            WWID
          </label>
          <input
            type="text"
            value={wwid}
            autoFocus
            autoComplete="off"
            placeholder="Enter your WWID"
            onChange={(e) => setWwid(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') handleLogin() }}
            className="w-full h-11 rounded-lg bg-white/[0.06] border border-white/[0.12] text-white placeholder:text-white/25 px-4 text-sm outline-none transition-all duration-150 focus:border-blue-bright focus:bg-white/[0.09]"
          />
        </div>

        {/* Error */}
        <div className="h-4 mb-3">
          {error && <p className="text-xs text-rag-red-soft">{error}</p>}
        </div>

        {/* Submit */}
        <button
          onClick={handleLogin}
          disabled={loading}
          className="w-full h-11 rounded-lg bg-gradient-to-r from-blue-brand to-blue-bright text-white text-sm font-semibold transition-all duration-150 hover:-translate-y-px hover:shadow-lg hover:shadow-blue-bright/40 disabled:opacity-60 disabled:cursor-not-allowed shadow-md shadow-blue-bright/30"
        >
          {loading ? 'Signing in...' : 'Sign In'}
        </button>

        <p className="mt-5 text-2xs text-white/30 text-center leading-relaxed">
          Access governed by WWID and assigned role.<br />
          Contact your admin if you do not have access.
        </p>
      </div>
    </div>
  )
}
