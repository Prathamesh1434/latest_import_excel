import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getSheetData } from '@/api'
import { Skeleton, EmptyState } from '@/components/ui/index'
import type { ScorecardSummary } from '@/types'

interface RawDataProps {
  scorecard: ScorecardSummary
}

export function RawDataFeature({ scorecard }: RawDataProps) {
  const sheets = scorecard.sheet_names ?? []
  const [activeSheet, setActiveSheet] = useState(sheets[0] ?? '')

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ['sheetData', scorecard.scorecard_id, activeSheet],
    queryFn: () => getSheetData(scorecard.scorecard_id, activeSheet, 200),
    enabled: Boolean(activeSheet),
    staleTime: 120_000,
  })

  if (!sheets.length) return <EmptyState message="No sheets available in this scorecard." />

  const cols = rows.length > 0 ? Object.keys(rows[0]) : []

  return (
    <div>
      {/* Sheet tabs */}
      <div className="flex gap-1.5 mb-4 flex-wrap">
        {sheets.map((s) => (
          <button
            key={s}
            onClick={() => setActiveSheet(s)}
            className={`px-3.5 py-1.5 rounded border text-xs font-medium transition-all duration-150 ${
              activeSheet === s
                ? 'bg-navy text-white border-navy'
                : 'bg-white border-border text-ink-sec hover:border-blue-brand hover:text-blue-brand'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Table */}
      {isLoading ? (
        <Skeleton className="h-64" />
      ) : rows.length === 0 ? (
        <EmptyState message="No data in this sheet." />
      ) : (
        <div className="bg-surface-card border border-border rounded shadow-sm overflow-auto max-h-[600px]">
          <table className="w-full">
            <thead>
              <tr>
                {cols.map((c) => (
                  <th
                    key={c}
                    className="sticky top-0 bg-surface-raised px-3 py-2 text-2xs font-semibold uppercase tracking-wide text-ink-sec text-left whitespace-nowrap border-b-2 border-border"
                  >
                    {c}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr key={i} className="hover:bg-blue-brand/[0.025] transition-colors">
                  {cols.map((c) => {
                    const v = String(row[c] ?? '')
                    const vl = v.toLowerCase()
                    let cls = 'px-3 py-1.5 text-xs border-b border-black/[0.04] whitespace-nowrap'
                    if (vl === 'red') cls += ' text-rag-red font-bold bg-rag-red/[0.06]'
                    else if (vl === 'amber') cls += ' text-rag-amber font-bold bg-rag-amber/[0.06]'
                    else if (vl === 'dark green') cls += ' text-rag-dkgreen font-bold bg-rag-dkgreen/[0.06]'
                    else if (vl === 'green') cls += ' text-rag-green font-bold bg-rag-green/[0.06]'
                    return <td key={c} className={cls}>{v}</td>
                  })}
                </tr>
              ))}
            </tbody>
          </table>
          <div className="px-4 py-2 border-t border-border bg-surface-raised text-xs text-ink-dim">
            Showing {rows.length} rows (max 200)
          </div>
        </div>
      )}
    </div>
  )
}
