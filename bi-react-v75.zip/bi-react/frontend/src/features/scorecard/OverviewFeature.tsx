import { useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { ResponsivePie } from '@nivo/pie'
import { getPivotData } from '@/api'
import { passRateVariant, fmtNum, isPass, isFail, normaliseRag, RAG_CHART_COLORS } from '@/utils/rag'
import { KpiCard, Skeleton, PanelBox } from '@/components/ui/index'
import type { ScorecardSummary, PivotRow } from '@/types'

interface OverviewProps {
  scorecard: ScorecardSummary
  activeMonth: string
}

export function OverviewFeature({ scorecard, activeMonth }: OverviewProps) {
  // Use first pivot sheet to derive accurate KPIs
  const primarySheet = scorecard.pivot_sheet_names?.[0] ?? ''

  const { data: pivotData, isLoading } = useQuery({
    queryKey: ['pivotData', scorecard.scorecard_id, primarySheet, activeMonth],
    queryFn: () => getPivotData(scorecard.scorecard_id, primarySheet, activeMonth || undefined),
    enabled: Boolean(scorecard.scorecard_id && primarySheet),
    staleTime: 60_000,
  })

  const kpis = useMemo(() => {
    if (!pivotData) return null
    const ragCols = pivotData.meta.rag_columns ?? []
    const totalCol = pivotData.meta.total_column ?? ''
    const gt = pivotData.meta.grand_total ?? {}

    const totalRules = totalCol
      ? Number(gt[totalCol]) || 0
      : ragCols.reduce((s, c) => s + (Number(gt[c]) || 0), 0)

    const failRules = ragCols
      .filter(isFail)
      .reduce((s, c) => s + (Number(gt[c]) || 0), 0)

    const amberRules = ragCols
      .filter((c) => normaliseRag(c) === 'amber')
      .reduce((s, c) => s + (Number(gt[c]) || 0), 0)

    const passRules = ragCols
      .filter(isPass)
      .reduce((s, c) => s + (Number(gt[c]) || 0), 0)

    const passRate = totalRules > 0 ? (passRules / totalRules) * 100 : 0

    return { totalRules, failRules, amberRules, passRules, passRate }
  }, [pivotData])

  const ragDist = useMemo(() => {
    if (!pivotData) return {}
    const ragCols = pivotData.meta.rag_columns ?? []
    const gt = pivotData.meta.grand_total ?? {}
    const dist: Record<string, number> = {}
    ragCols.forEach((c) => {
      const v = Number(gt[c]) || 0
      if (v > 0) dist[c] = v
    })
    return dist
  }, [pivotData])

  // Concise executive narrative derived from pivot
  const narrative = useMemo(() => {
    if (!kpis || !pivotData) return scorecard.narrative ?? ''
    const rows = pivotData.data as PivotRow[]
    const ragCols = pivotData.meta.rag_columns ?? []
    const dimCol = pivotData.meta.dim_column ?? ''

    const pr = kpis.passRate.toFixed(1)
    const failingCdes = rows
      .filter((r) => ragCols.filter(isFail).reduce((s, c) => s + (Number(r[c]) || 0), 0) > 0)
      .map((r) => String(r[dimCol] ?? ''))
      .filter(Boolean)
      .slice(0, 3)

    let text = `${kpis.totalRules} rules across ${rows.length} CDEs. Pass rate: ${pr}%.`
    if (kpis.failRules > 0) text += ` ${kpis.failRules} Red failure${kpis.failRules !== 1 ? 's' : ''}.`
    if (kpis.amberRules > 0) text += ` ${kpis.amberRules} Amber (at risk).`
    if (failingCdes.length > 0) {
      text += ` Failing CDEs: ${failingCdes.join(', ')}${failingCdes.length === 3 ? ' and others' : ''}.`
    } else if (kpis.failRules === 0) {
      text += ' All CDEs passing.'
    }
    return text
  }, [kpis, pivotData, scorecard])

  const anomalies = scorecard.anomalies ?? []
  const passRate = kpis?.passRate ?? 0
  const prVariant = passRateVariant(passRate)

  const pieData = Object.entries(ragDist)
    .filter(([, v]) => Number(v) > 0)
    .map(([k, v]) => ({
      id: k,
      label: k,
      value: Number(v),
      color: RAG_CHART_COLORS[normaliseRag(k)] ?? '#8898AA',
    }))

  if (isLoading || (!kpis && Boolean(primarySheet))) {
    return (
      <div className="space-y-5">
        <div className="grid grid-cols-4 gap-4">
          {Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
        <Skeleton className="h-40" />
      </div>
    )
  }

  return (
    <div className="space-y-5">
      {/* KPI grid — all from pivot grand total */}
      <div className="grid grid-cols-4 gap-4">
        <KpiCard
          label="Total Rules"
          value={(kpis?.totalRules ?? scorecard.row_count ?? 0).toLocaleString()}
          sub="From pivot data"
          variant="blue"
        />
        <KpiCard
          label="Failed Rules"
          value={fmtNum(kpis?.failRules ?? 0)}
          sub="Red status"
          variant="red"
        />
        <KpiCard
          label="Pass Rate"
          value={`${passRate.toFixed(1)}%`}
          sub={
            passRate >= 95
              ? 'Within threshold'
              : passRate >= 80
              ? 'At risk'
              : 'Below threshold'
          }
          variant={prVariant}
        />
        <KpiCard
          label="Months Available"
          value={scorecard.month_count ?? 0}
          sub="Reporting periods"
          variant="blue"
        />
      </div>

      {/* Summary + RAG pie */}
      <div className={`grid gap-5 ${pieData.length > 0 ? 'grid-cols-[1fr_220px]' : 'grid-cols-1'}`}>
        {narrative && (
          <div className="bg-surface-card border border-border rounded shadow-sm p-5">
            <div className="flex items-center gap-2 mb-3">
              <svg
                className="w-4 h-4 text-ink-dim flex-shrink-0"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <circle cx="12" cy="12" r="10"/>
                <path d="M12 16v-4M12 8h.01"/>
              </svg>
              <h3 className="text-sm font-bold text-navy">Summary</h3>
            </div>
            <p className="text-sm text-ink-sec leading-relaxed">{narrative}</p>
          </div>
        )}

        {pieData.length > 0 && (
          <div className="bg-surface-card border border-border rounded shadow-sm p-4">
            <div className="text-2xs font-bold uppercase tracking-wide text-ink-dim mb-1">
              RAG Distribution
            </div>
            <div style={{ height: 140 }}>
              <ResponsivePie
                data={pieData}
                margin={{ top: 8, right: 8, bottom: 8, left: 8 }}
                innerRadius={0.55}
                padAngle={2}
                cornerRadius={3}
                colors={{ datum: 'data.color' }}
                borderWidth={2}
                borderColor="#FFFFFF"
                enableArcLabels={false}
                arcLinkLabelsSkipAngle={15}
                arcLinkLabelsTextColor="#8898AA"
                arcLinkLabelsThickness={1}
                arcLinkLabelsColor={{ from: 'color' }}
                arcLinkLabel="label"
                theme={{ fontSize: 10 }}
                tooltip={({ datum }) => (
                  <div className="bg-navy text-white text-xs px-3 py-1.5 rounded shadow-lg">
                    {datum.label}: <strong>{datum.value}</strong>
                  </div>
                )}
              />
            </div>
            <div className="space-y-1 mt-2">
              {pieData.map((d) => (
                <div key={d.id} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <div
                      className="w-2 h-2 rounded-full flex-shrink-0"
                      style={{ background: d.color }}
                    />
                    <span className="text-ink-sec">{d.label}</span>
                  </div>
                  <span className="font-bold font-mono text-navy">{d.value}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Anomalies */}
      {anomalies.length > 0 && (
        <PanelBox>
          <div className="flex items-center gap-2 mb-4">
            <svg
              className="w-4 h-4 text-rag-amber flex-shrink-0"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0zM12 9v4M12 17h.01"/>
            </svg>
            <h3 className="text-sm font-bold text-navy">Anomalies &amp; Signals</h3>
          </div>
          <div className="space-y-2">
            {anomalies.map((a, i) => {
              const severityStyle: Record<string, string> = {
                critical: 'bg-rag-red/[0.06] border-l-[3px] border-l-rag-red',
                high: 'bg-rag-red/[0.04] border-l-[3px] border-l-rag-red-soft',
                medium: 'bg-rag-amber/[0.05] border-l-[3px] border-l-rag-amber-soft',
                low: 'bg-surface border-l-[3px] border-l-border',
              }
              const badgeStyle: Record<string, string> = {
                critical: 'bg-rag-red text-white',
                high: 'bg-rag-red-soft text-white',
                medium: 'bg-rag-amber-soft text-white',
                low: 'bg-border text-ink-sec',
              }
              return (
                <div
                  key={i}
                  className={`flex items-start gap-3 px-3.5 py-2.5 rounded ${severityStyle[a.severity] ?? severityStyle.low}`}
                >
                  <span
                    className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded flex-shrink-0 mt-0.5 ${badgeStyle[a.severity] ?? badgeStyle.low}`}
                  >
                    {a.severity}
                  </span>
                  <div>
                    <div className="text-xs font-semibold text-ink">{a.description}</div>
                    {a.context && (
                      <div className="text-xs text-ink-dim mt-0.5">{a.context}</div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </PanelBox>
      )}
    </div>
  )
}
