import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { User, ScorecardSummary, DataTableFilter } from '@/types'

interface AppState {
  user: User | null
  setUser: (u: User | null) => void

  currentScorecard: ScorecardSummary | null
  setCurrentScorecard: (sc: ScorecardSummary | null) => void

  activePivotSheet: string
  setActivePivotSheet: (s: string) => void

  activeMonth: string
  setActiveMonth: (m: string) => void

  activeTab: string
  setActiveTab: (t: string) => void

  chatPanelWidth: number
  setChatPanelWidth: (w: number) => void

  // Drill-down filters from heatmap click
  drillFilters: DataTableFilter[]
  setDrillFilters: (f: DataTableFilter[]) => void
  clearDrillFilters: () => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      setUser: (u) => set({ user: u }),

      currentScorecard: null,
      setCurrentScorecard: (sc) =>
        set({
          currentScorecard: sc,
          activePivotSheet: sc?.pivot_sheet_names?.[0] ?? '',
          activeMonth: sc?.months_available?.slice(-1)[0] ?? '',
        }),

      activePivotSheet: '',
      setActivePivotSheet: (s) => set({ activePivotSheet: s }),

      activeMonth: '',
      setActiveMonth: (m) => set({ activeMonth: m }),

      activeTab: 'overview',
      setActiveTab: (t) => set({ activeTab: t }),

      chatPanelWidth: 360,
      setChatPanelWidth: (w) => set({ chatPanelWidth: w }),

      drillFilters: [],
      setDrillFilters: (f) => set({ drillFilters: f }),
      clearDrillFilters: () => set({ drillFilters: [] }),
    }),
    {
      name: 'bi-cde-app',
      partialize: (s) => ({
        user: s.user,
        chatPanelWidth: s.chatPanelWidth,
      }),
    },
  ),
)
