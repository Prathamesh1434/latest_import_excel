import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { listScorecards } from '@/api'
import { formatMonth, fmtNum, passRateColor, isPass, isFail, normaliseRag } from '@/utils/rag'
import { AppHeader } from '@/components/ui/AppHeader'
import { SkeletonCard } from '@/components/ui/index'
import type { ScorecardSummary, SheetMeta } from '@/types'

export function LandingPage() {
  const [search, setSearch] = useState('')
  const [entity, setEntity] = useState('ALL')
  const navigate = useNavigate()

  const { data: scorecards = [], isLoading, error } = useQuery({
    queryKey: ['scorecards'],
    queryFn: listScorecards,
    staleTime: 60_000,
  })

  const entities = useMemo(() => {
    const ents = [...new Set(scorecards.map((s) => s.legal_entity || 'ALL'))].sort()
    return ents
  }, [scorecards])

  const filtered = useMemo(() => {
    let list = scorecards
    if (entity !== 'ALL') list = list.filter((s) => (s.legal_entity || 'ALL') === entity)
    if (search.trim()) {
      const q = search.toLowerCase()
      list = list.filter(
        (s) =>
          (s.display_title ?? '').toLowerCase().includes(q) ||
          (s.display_name ?? '').toLowerCase().includes(q) ||
          (s.scorecard_id ?? '').toLowerCase().includes(q) ||
          (s.legal_entity ?? '').toLowerCase().includes(q),
      )
    }
    return list
  }, [scorecards, entity, search])

  return (
    <div className="min-h-screen bg-surface">
      <AppHeader showSearch onSearch={setSearch} />

      <main className="pt-14">
        <div className="px-9 py-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-navy tracking-tight">CDE Scorecards</h2>
            <p className="text-sm text-ink-sec mt-1">
              {isLoading
                ? 'Loading...'
                : `${filtered.length} scorecard${filtered.length !== 1 ? 's' : ''} available`}
            </p>
          </div>

          <div className="flex items-center gap-2 mb-6 flex-wrap">
            <span className="text-2xs font-bold uppercase tracking-widest text-ink-dim mr-1">
              Entity
            </span>
            <EntityPill label="All" active={entity === 'ALL'} onClick={() => setEntity('ALL')} />
            {entities
              .filter((e) => e !== 'ALL')
              .map((e) => (
                <EntityPill key={e} label={e} active={entity === e} onClick={() => setEntity(e)} />
              ))}
          </div>

          {error ? (
            <div className="text-rag-red text-sm py-8 px-4">
              Failed to load scorecards. Is the server running?
            </div>
          ) : (
            <div className="grid grid-cols-[repeat(auto-fill,minmax(300px,1fr))] gap-5">
              {isLoading
                ? Array(6)
                    .fill(0)
                    .map((_, i) => <SkeletonCard key={i} />)
                : filtered.map((sc) => (
                    <ScorecardCard
                      key={sc.scorecard_id}
                      sc={sc}
                      onClick={() => navigate(`/scorecard/${sc.scorecard_id}`)}
                    />
                  ))}
              {!isLoading && filtered.length === 0 && (
                <p className="text-ink-sec text-sm py-6">
                  No scorecards match your search. Use the Admin panel to onboard data.
                </p>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

// ─── Derive pivot-accurate metrics from sheet_meta ────────────────
function derivePivotMetrics(sc: ScorecardSummary): {
  totalRules: number
  failedRules: number
  amberRules: number
  passRate: number
  hasData: boolean
} {
  const sheetMeta = sc.sheet_meta ?? {}

  // Find first pivot sheet meta
  const pivotMeta: SheetMeta | undefined = Object.values(sheetMeta).find((m) => m.is_pivot)

  if (!pivotMeta || !pivotMeta.grand_total) {
    // Fall back to rag_summary if no pivot meta
    const rag = sc.rag_summary ?? {}
    const red = rag.Red ?? rag.red ?? 0
    const amber = rag.Amber ?? rag.amber ?? 0
    const green = rag.Green ?? rag.green ?? 0
    const dkgreen = rag['Dark Green'] ?? rag['dark green'] ?? rag.dark_green ?? 0
    const total = red + amber + green + dkgreen
    const pass = green + dkgreen
    return {
      totalRules: total,
      failedRules: red,
      amberRules: amber,
      passRate: total > 0 ? (pass / total) * 100 : 0,
      hasData: total > 0,
    }
  }

  const gt = pivotMeta.grand_total
  const ragCols = pivotMeta.rag_columns ?? []
  const totalCol = pivotMeta.total_column ?? ''

  const totalRules = totalCol
    ? Number(gt[totalCol]) || 0
    : ragCols.reduce((s, c) => s + (Number(gt[c]) || 0), 0)

  const failedRules = ragCols
    .filter(isFail)
    .reduce((s, c) => s + (Number(gt[c]) || 0), 0)

  const amberRules = ragCols
    .filter((c) => normaliseRag(c) === 'amber')
    .reduce((s, c) => s + (Number(gt[c]) || 0), 0)

  const passRules = ragCols
    .filter(isPass)
    .reduce((s, c) => s + (Number(gt[c]) || 0), 0)

  const passRate = totalRules > 0 ? (passRules / totalRules) * 100 : 0

  return { totalRules, failedRules, amberRules, passRate, hasData: totalRules > 0 }
}

// ─── Derive RAG bar segments from pivot meta ──────────────────────
function derivePivotRagBar(sc: ScorecardSummary): {
  red: number; amber: number; green: number; dkgreen: number; total: number
} {
  const sheetMeta = sc.sheet_meta ?? {}
  const pivotMeta: SheetMeta | undefined = Object.values(sheetMeta).find((m) => m.is_pivot)

  if (!pivotMeta?.grand_total) {
    const rag = sc.rag_summary ?? {}
    return {
      red: rag.Red ?? rag.red ?? 0,
      amber: rag.Amber ?? rag.amber ?? 0,
      green: rag.Green ?? rag.green ?? 0,
      dkgreen: rag['Dark Green'] ?? rag['dark green'] ?? rag.dark_green ?? 0,
      total: 0,
    }
  }

  const gt = pivotMeta.grand_total
  const ragCols = pivotMeta.rag_columns ?? []

  const red = ragCols.filter(isFail).reduce((s, c) => s + (Number(gt[c]) || 0), 0)
  const amber = ragCols
    .filter((c) => normaliseRag(c) === 'amber')
    .reduce((s, c) => s + (Number(gt[c]) || 0), 0)
  const green = ragCols
    .filter((c) => normaliseRag(c) === 'green')
    .reduce((s, c) => s + (Number(gt[c]) || 0), 0)
  const dkgreen = ragCols
    .filter((c) => normaliseRag(c) === 'dark green')
    .reduce((s, c) => s + (Number(gt[c]) || 0), 0)
  const total = red + amber + green + dkgreen

  return { red, amber, green, dkgreen, total }
}

function EntityPill({
  label,
  active,
  onClick,
}: {
  label: string
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={`px-3.5 py-1.5 rounded-full text-xs font-medium border transition-all duration-150 ${
        active
          ? 'bg-navy text-white border-navy'
          : 'bg-white text-ink-sec border-border hover:border-blue-brand hover:text-blue-brand'
      }`}
    >
      {label}
    </button>
  )
}

function ScorecardCard({
  sc,
  onClick,
}: {
  sc: ScorecardSummary
  onClick: () => void
}) {
  const { totalRules, failedRules, passRate } = derivePivotMetrics(sc)
  const { red, amber, green, dkgreen, total } = derivePivotRagBar(sc)
  const months = sc.months_available ?? []

  return (
    <div
      onClick={onClick}
      className="group bg-surface-card border border-border rounded-lg p-5 cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:border-blue-brand/35 hover:shadow-lg relative overflow-hidden shadow-sm"
    >
      {/* Accent bar */}
      <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-blue-brand to-accent opacity-0 group-hover:opacity-100 transition-opacity duration-200 rounded-t-lg" />

      {/* Top row */}
      <div className="flex items-start justify-between mb-3">
        <h3
          className="text-md font-bold text-navy leading-snug max-w-[220px] line-clamp-2"
          title={sc.display_title || sc.display_name || sc.scorecard_id}
        >
          {sc.display_title || sc.display_name || sc.scorecard_id}
        </h3>
        {sc.is_stale ? (
          <span className="text-2xs font-bold px-2 py-0.5 rounded-xl bg-amber-50 text-rag-amber uppercase tracking-wide flex-shrink-0">
            Stale
          </span>
        ) : (
          <span className="text-2xs font-bold px-2 py-0.5 rounded-xl bg-blue-brand/[0.08] text-blue-brand uppercase tracking-wide flex-shrink-0">
            {sc.legal_entity || 'ALL'}
          </span>
        )}
      </div>

      {/* RAG bar — derived from pivot */}
      <div className="h-1.5 rounded-full overflow-hidden flex mb-4 bg-border">
        {red > 0 && (
          <div style={{ flex: red }} className="bg-rag-red h-full" />
        )}
        {amber > 0 && (
          <div style={{ flex: amber }} className="bg-rag-amber-soft h-full" />
        )}
        {green > 0 && (
          <div style={{ flex: green }} className="bg-rag-green-soft h-full" />
        )}
        {dkgreen > 0 && (
          <div style={{ flex: dkgreen }} className="bg-rag-dkgreen-soft h-full" />
        )}
        {total === 0 && <div className="flex-1 bg-border h-full" />}
      </div>

      {/* Metrics — pivot-derived */}
      <div className="grid grid-cols-4 gap-1.5 mb-4">
        <Metric value={fmtNum(totalRules)} label="Rules" />
        <Metric value={fmtNum(failedRules)} label="Failed" color="#C62828" />
        <Metric
          value={`${passRate.toFixed(1)}%`}
          label="Pass Rate"
          color={passRateColor(passRate)}
        />
        <Metric value={String(sc.month_count ?? 0)} label="Months" />
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-border">
        <span className="text-xs text-ink-dim">
          {months.length
            ? `Months: ${months.slice(-3).map(formatMonth).join(', ')}`
            : 'No month data'}
        </span>
        <div className="w-7 h-7 rounded-lg bg-surface border border-border flex items-center justify-center text-ink-sec group-hover:bg-navy group-hover:border-navy group-hover:text-white transition-all duration-200">
          <svg
            className="w-3.5 h-3.5"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
          >
            <path d="M5 12h14M12 5l7 7-7 7"/>
          </svg>
        </div>
      </div>
    </div>
  )
}

function Metric({
  value,
  label,
  color,
}: {
  value: string
  label: string
  color?: string
}) {
  return (
    <div className="text-center">
      <span
        className="block text-lg font-bold font-mono text-navy leading-tight"
        style={color ? { color } : {}}
      >
        {value}
      </span>
      <span className="text-2xs text-ink-dim mt-0.5 block">{label}</span>
    </div>
  )
}
