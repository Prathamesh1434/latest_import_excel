import { useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { listScorecards } from '@/api'
import { useAppStore } from '@/store/appStore'
import { formatMonth } from '@/utils/rag'
import { AppHeader } from '@/components/ui/AppHeader'
import { Skeleton } from '@/components/ui/index'
import { OverviewFeature } from '@/features/scorecard/OverviewFeature'
import { CDEDashboard } from '@/features/cde/CDEDashboard'
import { DataTableFeature } from '@/features/datatable/DataTableFeature'
import { MoMCompareFeature } from '@/features/mom/MoMCompareFeature'
import { RawDataFeature } from '@/features/rawdata/RawDataFeature'
import { ChatPanel } from '@/features/chat/ChatPanel'
import type { ScorecardSummary } from '@/types'

const TABS = [
  { id: 'overview', label: 'Overview' },
  { id: 'cde-dashboard', label: 'CDE Scorecard' },
  { id: 'data-table', label: 'Data Table' },
  { id: 'mom-compare', label: 'MoM Compare' },
  { id: 'raw-data', label: 'Raw Data' },
]

export function DetailPage() {
  const { scorecardId } = useParams<{ scorecardId: string }>()
  const navigate = useNavigate()

  const setCurrentScorecard = useAppStore((s) => s.setCurrentScorecard)
  const activePivotSheet = useAppStore((s) => s.activePivotSheet)
  const setActivePivotSheet = useAppStore((s) => s.setActivePivotSheet)
  const activeMonth = useAppStore((s) => s.activeMonth)
  const setActiveMonth = useAppStore((s) => s.setActiveMonth)
  const activeTab = useAppStore((s) => s.activeTab)
  const setActiveTab = useAppStore((s) => s.setActiveTab)
  const drillFilters = useAppStore((s) => s.drillFilters)
  const clearDrillFilters = useAppStore((s) => s.clearDrillFilters)

  const { data: scorecards = [], isLoading } = useQuery({
    queryKey: ['scorecards'],
    queryFn: listScorecards,
    staleTime: 60_000,
  })

  const scorecard: ScorecardSummary | undefined = scorecards.find(
    (s) => s.scorecard_id === scorecardId,
  )

  useEffect(() => {
    if (scorecard) {
      setCurrentScorecard(scorecard)
    }
    return () => {
      setCurrentScorecard(null)
    }
  }, [scorecard?.scorecard_id])

  useEffect(() => {
    setActiveTab('overview')
    clearDrillFilters()
  }, [scorecardId])

  if (isLoading) return <DetailSkeleton />
  if (!scorecard) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center">
        <div className="text-center">
          <p className="text-ink-sec text-sm mb-4">Scorecard not found.</p>
          <button
            onClick={() => navigate('/')}
            className="text-blue-brand text-sm font-medium hover:underline"
          >
            Back to scorecards
          </button>
        </div>
      </div>
    )
  }

  const pivots = scorecard.pivot_sheet_names ?? []
  const raws = scorecard.raw_sheet_names ?? scorecard.sheet_names ?? []
  const months = scorecard.months_available ?? []
  const currentSheet = activePivotSheet || pivots[0] || ''
  const currentMonth = activeMonth || months[months.length - 1] || ''

  return (
    <div className="min-h-screen bg-surface flex flex-col">
      <AppHeader />

      {/* Sub-topbar */}
      <div className="fixed top-14 left-0 right-0 h-12 z-[900] bg-white border-b border-border flex items-center px-6 gap-3 shadow-[0_1px_0_#E1E5ED]">
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-1.5 text-xs font-medium text-ink-sec px-2.5 py-1.5 rounded hover:bg-surface hover:text-navy transition-all duration-150 flex-shrink-0"
        >
          <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
          Back
        </button>

        <div className="w-px h-6 bg-border flex-shrink-0" />

        <span
          className="text-sm font-bold text-navy flex-shrink-0 max-w-xs truncate"
          title={scorecard.display_title || scorecard.display_name}
        >
          {scorecard.display_title || scorecard.display_name || scorecard.scorecard_id}
        </span>

        <span className="text-2xs font-bold px-2 py-0.5 rounded-xl bg-blue-brand/[0.08] text-blue-brand uppercase tracking-wide flex-shrink-0">
          {scorecard.legal_entity || 'ALL'}
        </span>

        {currentMonth && (
          <span className="text-xs text-ink-dim flex-shrink-0">
            Reporting: {formatMonth(currentMonth)}
          </span>
        )}

        <nav className="flex gap-0.5 ml-auto">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id)
                if (tab.id !== 'data-table') clearDrillFilters()
              }}
              className={`px-4 py-2 text-xs font-medium border-b-2 whitespace-nowrap rounded-t transition-all duration-150 ${
                activeTab === tab.id
                  ? 'text-navy border-navy font-semibold bg-navy/[0.03]'
                  : 'text-ink-sec border-transparent hover:text-navy hover:bg-navy/[0.02]'
              }`}
            >
              {tab.label}
              {tab.id === 'data-table' && drillFilters.length > 0 && (
                <span className="ml-1.5 text-2xs bg-blue-brand text-white px-1.5 py-0.5 rounded-full">
                  {drillFilters.length}
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Body */}
      <div className="flex mt-[calc(3.5rem+3rem)] h-[calc(100vh-3.5rem-3rem)] overflow-hidden">

        {/* Sidebar */}
        <aside className="w-56 min-w-[224px] bg-white border-r border-border flex-shrink-0 overflow-y-auto hidden lg:block">
          <div className="p-3">

            {months.length > 0 && (
              <>
                <div className="text-2xs font-bold uppercase tracking-widest text-ink-dim px-2 py-1.5 mt-1">
                  Reporting Month
                </div>
                {months.map((m) => (
                  <button
                    key={m}
                    onClick={() => {
                      setActiveMonth(m)
                      // Force re-render of active tab
                      if (activeTab === 'overview') setActiveTab('overview')
                      if (activeTab === 'cde-dashboard') setActiveTab('cde-dashboard')
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded text-xs font-medium transition-all duration-150 mb-0.5 ${
                      currentMonth === m
                        ? 'bg-navy text-white'
                        : 'text-ink-sec hover:bg-navy/[0.05] hover:text-navy'
                    }`}
                  >
                    {formatMonth(m)}
                  </button>
                ))}
              </>
            )}

            {pivots.length > 0 && (
              <>
                <div className="text-2xs font-bold uppercase tracking-widest text-ink-dim px-2 py-1.5 mt-3">
                  Pivot Sheets
                </div>
                {pivots.map((p) => (
                  <button
                    key={p}
                    onClick={() => {
                      setActivePivotSheet(p)
                      setActiveTab('cde-dashboard')
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded text-xs font-medium transition-all duration-150 mb-0.5 ${
                      currentSheet === p
                        ? 'bg-navy text-white'
                        : 'text-ink-sec hover:bg-navy/[0.05] hover:text-navy'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </>
            )}

            {raws.length > 0 && (
              <>
                <div className="text-2xs font-bold uppercase tracking-widest text-ink-dim px-2 py-1.5 mt-3">
                  Data Sheets
                </div>
                {raws.map((r) => (
                  <button
                    key={r}
                    onClick={() => setActiveTab('raw-data')}
                    className="w-full text-left px-2.5 py-1.5 rounded text-xs font-medium text-ink-sec hover:bg-navy/[0.05] hover:text-navy transition-all duration-150 mb-0.5"
                  >
                    {r}
                  </button>
                ))}
              </>
            )}

            {scorecard.onboarded_at && (
              <div className="text-xs text-ink-dim px-2 mt-4 pb-2">
                Updated{' '}
                {new Date(scorecard.onboarded_at).toLocaleDateString('en-GB', {
                  day: 'numeric',
                  month: 'short',
                  year: 'numeric',
                })}
              </div>
            )}
          </div>
        </aside>

        {/* Main */}
        <main className="flex-1 overflow-y-auto min-w-0">
          <div className="p-6">
            {activeTab === 'overview' && (
              <OverviewFeature scorecard={scorecard} activeMonth={currentMonth} />
            )}
            {activeTab === 'cde-dashboard' && (
              <CDEDashboard
                scorecardId={scorecard.scorecard_id}
                sheetName={currentSheet}
                activeMonth={currentMonth}
              />
            )}
            {activeTab === 'data-table' && (
              <DataTableFeature
                scorecardId={scorecard.scorecard_id}
                initialFilters={drillFilters}
                onFiltersCleared={clearDrillFilters}
              />
            )}
            {activeTab === 'mom-compare' && (
              <MoMCompareFeature
                scorecardId={scorecard.scorecard_id}
                activePivotSheet={currentSheet}
                scorecard={scorecard}
              />
            )}
            {activeTab === 'raw-data' && (
              <RawDataFeature scorecard={scorecard} />
            )}
          </div>
        </main>

        <ChatPanel scorecard={scorecard} />
      </div>
    </div>
  )
}

function DetailSkeleton() {
  return (
    <div className="min-h-screen bg-surface pt-14">
      <div className="h-12 bg-white border-b border-border" />
      <div className="flex h-[calc(100vh-6.5rem)]">
        <div className="w-56 bg-white border-r border-border" />
        <div className="flex-1 p-6 space-y-5">
          <div className="grid grid-cols-4 gap-4">
            {Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-28" />)}
          </div>
          <Skeleton className="h-48" />
          <Skeleton className="h-64" />
        </div>
      </div>
    </div>
  )
}
