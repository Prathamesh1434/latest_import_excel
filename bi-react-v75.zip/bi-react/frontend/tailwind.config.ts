import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#0A1628',
          mid: '#112240',
          light: '#1A3358',
        },
        blue: {
          brand: '#1565C0',
          bright: '#2196F3',
        },
        accent: '#00BCD4',
        rag: {
          red: '#C62828',
          'red-soft': '#EF5350',
          amber: '#E65100',
          'amber-soft': '#FF9800',
          green: '#1B5E20',
          'green-soft': '#4CAF50',
          dkgreen: '#0D3B1F',
          'dkgreen-soft': '#2E7D32',
        },
        surface: {
          DEFAULT: '#F5F7FA',
          card: '#FFFFFF',
          raised: '#FAFBFC',
        },
        border: {
          DEFAULT: '#E1E5ED',
          strong: '#C8CDD8',
        },
        ink: {
          DEFAULT: '#0D1B2E',
          sec: '#4A5568',
          dim: '#8898AA',
        },
      },
      fontFamily: {
        sans: ['DM Sans', 'system-ui', 'sans-serif'],
        mono: ['DM Mono', 'monospace'],
      },
      fontSize: {
        '2xs': ['10px', '14px'],
        xs: ['11px', '16px'],
        sm: ['12px', '18px'],
        base: ['13px', '20px'],
        md: ['14px', '20px'],
        lg: ['15px', '22px'],
        xl: ['18px', '26px'],
        '2xl': ['22px', '30px'],
      },
      borderRadius: {
        sm: '6px',
        DEFAULT: '10px',
        lg: '14px',
      },
      boxShadow: {
        sm: '0 1px 3px rgba(10,22,40,.07),0 1px 2px rgba(10,22,40,.05)',
        DEFAULT: '0 4px 12px rgba(10,22,40,.08),0 1px 3px rgba(10,22,40,.06)',
        lg: '0 10px 32px rgba(10,22,40,.12),0 2px 8px rgba(10,22,40,.07)',
        xl: '0 20px 60px rgba(10,22,40,.16),0 4px 16px rgba(10,22,40,.08)',
      },
      keyframes: {
        shimmer: {
          '0%': { backgroundPosition: '200% 0' },
          '100%': { backgroundPosition: '-200% 0' },
        },
        pulseDot: {
          '0%,100%': { opacity: '1' },
          '50%': { opacity: '0.4' },
        },
        bounceUp: {
          '0%': { transform: 'translateY(0)', opacity: '1' },
          '100%': { transform: 'translateY(-6px)', opacity: '0.4' },
        },
        fadeIn: {
          from: { opacity: '0', transform: 'translateY(4px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        slideIn: {
          from: { opacity: '0', transform: 'translateX(8px)' },
          to: { opacity: '1', transform: 'translateX(0)' },
        },
      },
      animation: {
        shimmer: 'shimmer 1.4s infinite',
        pulseDot: 'pulseDot 2s infinite',
        bounceUp: 'bounceUp 0.6s infinite alternate',
        fadeIn: 'fadeIn 0.2s ease-out',
        slideIn: 'slideIn 0.2s ease-out',
      },
    },
  },
  plugins: [],
}

export default config
