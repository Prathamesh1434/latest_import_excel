"""
main.py — v7

Application entrypoint with:
- Lifespan: restores scorecards from disk on startup
- SSE endpoint for real-time onboarding progress
- CORS middleware
- All router mounts
"""
import asyncio
import json
import logging
from contextlib import asynccontextmanager

from backend.config import setup_logging
setup_logging()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from backend.routers.api import router as api_router
from backend.routers.onboard import router as onboard_router, get_progress
from backend.routers.data import router as data_router
from backend.routers.chat import router as chat_router
from backend.routers.docs import router as docs_router
from backend.routers.auth import router as auth_router

from backend.services.scorecard_registry import restore_all_from_disk

log = logging.getLogger("main")


# ══════ LIFESPAN — restore on startup ══════

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: restore all scorecards from storage/ directory."""
    log.info("=" * 60)
    log.info("B&I CDE Intelligence Platform v7.0 starting...")
    log.info("=" * 60)

    count = restore_all_from_disk()
    log.info(f"Startup complete. Restored {count} scorecards from disk.")
    log.info("=" * 60)

    yield  # App runs here

    log.info("Shutting down...")


# ══════ APP ══════

app = FastAPI(
    title="B&I CDE Intelligence Platform",
    description="Standalone Enterprise Data Intelligence Platform v7",
    version="7.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"],
)

# ══════ ROUTERS ══════

app.include_router(api_router, tags=["API"])
app.include_router(auth_router, prefix="/auth", tags=["Auth"])
app.include_router(onboard_router, prefix="/scorecards", tags=["Onboard"])
app.include_router(data_router, prefix="/data", tags=["Data"])
app.include_router(chat_router, prefix="/chat", tags=["Chat"])
app.include_router(docs_router, prefix="/docs", tags=["Docs"])


# ══════ SSE PROGRESS ENDPOINT ══════

@app.get("/progress/{scorecard_id}")
async def sse_progress(scorecard_id: str):
    """Server-Sent Events stream for real-time onboarding progress."""

    async def event_stream():
        last_step = -1
        timeout_count = 0
        max_timeout = 120  # 2 minutes max

        while timeout_count < max_timeout:
            progress = get_progress(scorecard_id)
            current_step = progress.get("step", 0)

            if current_step != last_step:
                data = json.dumps(progress)
                yield f"data: {data}\n\n"
                last_step = current_step

                if progress.get("status") in ("done", "error"):
                    break

            await asyncio.sleep(0.3)
            timeout_count += 1

        # Final event
        yield f"data: {json.dumps({'step': 7, 'label': 'Complete', 'status': 'done'})}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ══════ STATIC FILE SERVING ══════

from fastapi.responses import FileResponse, HTMLResponse
from pathlib import Path

# Serve HTML files from the project root
PROJECT_ROOT = Path(__file__).resolve().parent.parent


@app.get("/")
def root():
    """Redirect root to end-user page."""
    index_path = PROJECT_ROOT / "index.html"
    if index_path.exists():
        return FileResponse(str(index_path), media_type="text/html")
    return {
        "service": "B&I CDE Intelligence Platform",
        "version": "7.0.0",
        "docs": "/docs",
    }


@app.get("/index.html")
def serve_index():
    """Serve the end-user page."""
    index_path = PROJECT_ROOT / "index.html"
    if not index_path.exists():
        return HTMLResponse("<h1>index.html not found</h1>", status_code=404)
    return FileResponse(str(index_path), media_type="text/html")


@app.get("/dashboard.html")
def serve_dashboard():
    """Serve the admin dashboard page."""
    dash_path = PROJECT_ROOT / "dashboard.html"
    if not dash_path.exists():
        return HTMLResponse("<h1>dashboard.html not found</h1>", status_code=404)
    return FileResponse(str(dash_path), media_type="text/html")
