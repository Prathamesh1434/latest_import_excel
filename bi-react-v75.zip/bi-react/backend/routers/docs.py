from fastapi import APIRouter, Request
from backend.services.scorecard_registry import get_scorecard
from backend.services.document_service import search_documents

router = APIRouter()

@router.post("/{scorecard_id}/search")
async def search_docs(scorecard_id: str, request: Request):
    sc = get_scorecard(scorecard_id)
    body = await request.json()
    query = body.get("query")
    
    if not query:
        return {"results": []}
        
    vectorizer = sc.get("doc_index")
    chunks = sc.get("doc_chunks", [])
    
    if not vectorizer or not chunks:
        return {"results": []}
        
    results = search_documents(query, vectorizer, chunks)
    return {"results": results}

@router.get("/{scorecard_id}/list")
def list_docs(scorecard_id: str):
    sc = get_scorecard(scorecard_id)
    chunks = sc.get("doc_chunks", [])
    
    docs_summary = {}
    for c in chunks:
        doc_name = c["doc_name"]
        if doc_name not in docs_summary:
            docs_summary[doc_name] = 0
        docs_summary[doc_name] += 1
        
    return {"documents": docs_summary}
