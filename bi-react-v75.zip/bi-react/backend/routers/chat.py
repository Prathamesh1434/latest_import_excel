"""
routers/chat.py -- v7.2

Chat endpoint with full 3-tier support, mode selection,
tier badges, confidence, latency, chat history persistence,
and LLM context injection from previous conversations.
"""
import os
import json
import time
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List
from fastapi import APIRouter, Request, Header, HTTPException

from backend.services.scorecard_registry import get_scorecard, list_all, STORAGE_DIR
from backend.services.query_engine import query_scorecard
from backend.routers.auth import check_role, get_user

log = logging.getLogger("chat")

router = APIRouter()


def _save_chat_message(scorecard_id: str, user_id: str, role: str, content: str, meta: Dict = None):
    """Persist a chat message to disk."""
    history_dir = STORAGE_DIR / scorecard_id / "chat_history"
    history_dir.mkdir(parents=True, exist_ok=True)
    history_file = history_dir / f"{user_id}.json"

    messages = []
    if history_file.exists():
        try:
            with open(history_file, "r", encoding="utf-8") as f:
                messages = json.load(f)
        except Exception:
            messages = []

    messages.append({
        "role": role,
        "content": content,
        "timestamp": datetime.utcnow().isoformat(),
        **(meta or {}),
    })

    # Keep last 200 messages
    messages = messages[-200:]

    with open(history_file, "w", encoding="utf-8") as f:
        json.dump(messages, f, indent=2, default=str)


def _load_chat_history(scorecard_id: str, user_id: str) -> List[Dict]:
    """Load chat history from disk."""
    history_file = STORAGE_DIR / scorecard_id / "chat_history" / f"{user_id}.json"
    if history_file.exists():
        try:
            with open(history_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
    return []


def _build_chat_context(scorecard_id: str, user_id: str, max_pairs: int = 15) -> str:
    """
    Build context from previous chat sessions for LLM injection.
    Extracts recent Q&A pairs that are most informative.
    """
    history = _load_chat_history(scorecard_id, user_id)
    if not history:
        return ""

    # Extract Q&A pairs (user -> assistant)
    qa_pairs = []
    for i in range(len(history) - 1):
        if history[i]["role"] == "user" and history[i + 1]["role"] == "assistant":
            q = history[i]["content"]
            a = history[i + 1]["content"]
            # Skip trivial interactions
            if len(q) < 5 or len(a) < 10:
                continue
            # Truncate long answers
            if len(a) > 300:
                a = a[:300] + "..."
            qa_pairs.append((q, a))

    if not qa_pairs:
        return ""

    # Take the most recent pairs
    recent = qa_pairs[-max_pairs:]

    context_lines = ["Previous conversations about this scorecard:"]
    for q, a in recent:
        context_lines.append(f"Q: {q}")
        context_lines.append(f"A: {a}")
        context_lines.append("")

    return "\n".join(context_lines)


@router.post("/query")
async def chat_query(request: Request, x_user_id: str = Header(default="PG23137")):
    """
    Process a chat query through the 3-tier engine.

    Body:
      scorecard_id: str
      question: str
      mode: 'auto' | 't1' | 't2' | 't3'  (default: 'auto')
      cross_scorecard: bool (default: false)
    """
    body = await request.json()
    scorecard_id = body.get("scorecard_id")
    question = body.get("question", "").strip()
    mode = body.get("mode", "auto")
    cross_scorecard = body.get("cross_scorecard", False)

    if not question:
        return {"reply": "Please provide a question.", "tier": 0, "tier_label": "ERROR",
                "confidence": 0, "latency_ms": 0}

    # Check viewer role restrictions (no T3/LLM)
    user = get_user(x_user_id)
    if user and user.get("role") == "viewer" and mode == "t3":
        return {"reply": "Viewer role cannot access Tier 3 (Gemini AI). Use AUTO, T1, or T2.",
                "tier": 0, "tier_label": "BLOCKED", "confidence": 0, "latency_ms": 0}

    # Cross-scorecard mode
    if cross_scorecard and not scorecard_id:
        return _cross_scorecard_query(question, mode, x_user_id)

    if not scorecard_id:
        return {"reply": "Please select a scorecard first.", "tier": 0, "tier_label": "ERROR",
                "confidence": 0, "latency_ms": 0}

    try:
        sc = get_scorecard(scorecard_id)
    except KeyError:
        return {"reply": f"Scorecard '{scorecard_id}' not found.", "tier": 0, "tier_label": "ERROR",
                "confidence": 0, "latency_ms": 0}

    # Save user message to history
    _save_chat_message(scorecard_id, x_user_id, "user", question)

    # Build chat context from previous conversations (for T3)
    chat_context = _build_chat_context(scorecard_id, x_user_id)

    # Route through query engine (passing chat context for T3)
    result = query_scorecard(sc, question, mode=mode, chat_context=chat_context)

    # Add data freshness timestamp
    result["data_freshness"] = sc.get("onboarded_at", "")

    # Save AI response to history
    _save_chat_message(scorecard_id, x_user_id, "assistant", result.get("reply", ""),
                       {"tier": result.get("tier"), "tier_label": result.get("tier_label")})

    return result


@router.get("/history/{scorecard_id}")
async def get_chat_history(scorecard_id: str, x_user_id: str = Header(default="PG23137")):
    """Get chat history for a scorecard + user."""
    return _load_chat_history(scorecard_id, x_user_id)


@router.delete("/history/{scorecard_id}")
async def clear_chat_history(scorecard_id: str, x_user_id: str = Header(default="PG23137")):
    """Clear chat history for a scorecard + user."""
    history_file = STORAGE_DIR / scorecard_id / "chat_history" / f"{x_user_id}.json"
    if history_file.exists():
        history_file.unlink()
    return {"status": "cleared"}


def _cross_scorecard_query(question: str, mode: str, user_id: str) -> Dict[str, Any]:
    """Query across all scorecards."""
    all_sc = list_all()
    if not all_sc:
        return {"reply": "No scorecards onboarded.", "tier": 0, "tier_label": "ERROR",
                "confidence": 0, "latency_ms": 0}

    t0 = time.time()
    summaries = []
    for sid, sc in all_sc.items():
        df = sc.get("df")
        if df is not None:
            schema = sc.get("schema", {})
            rag_cols = schema.get("rag_status", [])
            total = len(df)
            failed = 0
            if rag_cols:
                try:
                    failed = len(df[df[rag_cols[0]].str.lower() == "red"])
                except Exception:
                    pass
            pass_rate = ((total - failed) / total * 100) if total > 0 else 0
            months = sc.get("months", {})
            month_info = f", {len(months)} months" if months else ""
            summaries.append(
                f"<strong>{sc.get('display_name', sid)}</strong>: "
                f"{total:,} rows, {failed} failures, {pass_rate:.1f}% pass rate{month_info}"
            )

    reply = "<strong>Cross-Scorecard Summary:</strong><br><br>" + "<br>".join(summaries)
    ms = int((time.time() - t0) * 1000)

    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": None, "chart": None,
        "confidence": 0.85, "latency_ms": ms,
        "data_source": f"Cross-scorecard ({len(all_sc)} scorecards)",
        "model_used": "pandas",
    }
