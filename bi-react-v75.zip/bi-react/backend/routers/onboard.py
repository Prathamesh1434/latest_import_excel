"""
routers/onboard.py -- v7.4

Multi-sheet Excel onboarding with sheet_meta extraction, reporting_month
capture, display_title auto-generation, month population on initial
onboard, anomaly detection, smart question generation, SSE progress,
and disk persistence.
"""
import os
import re
import time
import json
import logging
from datetime import datetime
from typing import List, Dict, Any
from fastapi import APIRouter, File, UploadFile, Form, HTTPException, Header
from pathlib import Path

from backend.services.scorecard_registry import (
    add_scorecard, persist_to_disk, delete_scorecard, get_scorecard, refresh_from_disk
)
from backend.services.data_service import (
    process_all_sheets, calculate_kri, validate_upload, load_all_sheets
)
from backend.services.document_service import parse_and_index_documents
from backend.routers.auth import check_role

log = logging.getLogger("onboard")

router = APIRouter()

# SSE progress state (in-memory, per scorecard_id)
_PROGRESS: Dict[str, Dict[str, Any]] = {}

MONTH_NAMES = {
    "01": "Jan", "02": "Feb", "03": "Mar", "04": "Apr",
    "05": "May", "06": "Jun", "07": "Jul", "08": "Aug",
    "09": "Sep", "10": "Oct", "11": "Nov", "12": "Dec",
}


def _set_progress(scorecard_id: str, step: int, label: str, status: str = "active"):
    _PROGRESS[scorecard_id] = {"step": step, "label": label, "status": status}


def _format_month_label(reporting_month: str) -> str:
    """Convert YYYY-MM to 'Feb 2026' style label."""
    if not reporting_month or len(reporting_month) < 7:
        return reporting_month
    parts = reporting_month.split("-")
    if len(parts) >= 2:
        month_name = MONTH_NAMES.get(parts[1], parts[1])
        return f"{month_name} {parts[0]}"
    return reporting_month


def _detect_anomalies(df, schema) -> List[Dict[str, Any]]:
    """Auto-detect anomalies in the data."""
    anomalies = []
    rag_cols = schema.get("rag_status", [])
    measure_cols = schema.get("measure", [])

    # 1. Rules with failures (Red status)
    if rag_cols:
        rag_col = rag_cols[0]
        try:
            red_count = len(df[df[rag_col].str.lower() == "red"])
            if red_count > 0:
                anomalies.append({
                    "signal_type": "breach",
                    "severity": "critical" if red_count > 5 else "high",
                    "description": f"{red_count} records with RED status detected",
                    "col": rag_col,
                    "context": f"Total records: {len(df)}, Failure rate: {red_count/len(df)*100:.1f}%",
                })
            amber_count = len(df[df[rag_col].str.lower() == "amber"])
            if amber_count > 0:
                anomalies.append({
                    "signal_type": "warning",
                    "severity": "medium",
                    "description": f"{amber_count} records with AMBER status (at risk)",
                    "col": rag_col,
                    "context": f"At-risk rate: {amber_count/len(df)*100:.1f}%",
                })
        except Exception:
            pass

    # 2. Measure columns with outliers
    for col in measure_cols[:3]:
        try:
            vals = df[col].dropna()
            if len(vals) > 2:
                mean_val = vals.mean()
                std_val = vals.std()
                if std_val > 0:
                    outliers = vals[abs(vals - mean_val) > 2 * std_val]
                    if len(outliers) > 0:
                        anomalies.append({
                            "signal_type": "outlier",
                            "severity": "medium",
                            "description": f"{len(outliers)} outliers in '{col}' (>2 std from mean)",
                            "col": col,
                            "context": f"Mean: {mean_val:.2f}, Std: {std_val:.2f}",
                        })
        except Exception:
            pass

    return anomalies


def _generate_starter_questions(df, schema, sheets=None, sheet_meta=None) -> List[str]:
    """Generate contextual starter questions from actual data columns."""
    questions = []
    rag_cols = schema.get("rag_status", [])
    dim_cols = schema.get("dimension", [])
    measure_cols = schema.get("measure", [])
    id_cols = schema.get("identifier", [])

    if rag_cols:
        questions.append("Show RAG status distribution")
        questions.append("How many rules are failing?")

    if id_cols:
        col = id_cols[0]
        questions.append(f"How many unique {col.replace('_', ' ')}s are there?")
        questions.append(f"List all {col.replace('_', ' ')}s")

    if dim_cols:
        for col in dim_cols[:2]:
            sample_vals = df[col].dropna().unique()[:3]
            if len(sample_vals) > 0:
                questions.append(f"Show data for {col.replace('_', ' ')} = {sample_vals[0]}")

    if measure_cols:
        col = measure_cols[0]
        questions.append(f"What is the average {col.replace('_', ' ')}?")

    if rag_cols and dim_cols:
        questions.append(f"Which {dim_cols[0].replace('_', ' ')} has the most failures?")

    # Sheet-specific questions using original names
    if sheet_meta:
        pivot_names = [n for n, m in sheet_meta.items() if m.get("is_pivot")]
        for pname in pivot_names[:2]:
            questions.append(f"Show me {pname} results")
        if len(pivot_names) >= 2:
            questions.append(f"Compare {pivot_names[0]} vs {pivot_names[1]}")
    elif sheets:
        sheet_names = list(sheets.keys())
        if any("solo" in s.lower() for s in sheet_names):
            questions.append("Show me Solo results")
        if any("conso" in s.lower() or "consolidated" in s.lower() for s in sheet_names):
            questions.append("Show me Consolidated results")
        if len(sheet_names) > 2:
            questions.append("Compare Solo vs Consolidated")

    questions.append("Give me a dashboard summary")
    questions.append("What are the key anomalies?")
    questions.append("Show the CDE pass rate")

    return questions[:10]


def _generate_narrative(df, schema, kpis, anomalies, sheet_meta=None) -> str:
    """Auto-generate a 2-3 sentence summary."""
    parts = []
    total = kpis.get("total", len(df))
    failed = kpis.get("failed", 0)

    parts.append(f"Dataset contains {len(df):,} records across {len(df.columns)} columns.")

    if failed > 0:
        parts.append(f"{failed} rules are failing out of {total} total (KRI: {failed/total*100:.1f}%).")
    else:
        parts.append(f"All {total} rules are passing.")

    if anomalies:
        critical = [a for a in anomalies if a["severity"] == "critical"]
        if critical:
            parts.append(f"{len(critical)} critical anomalies detected requiring attention.")

    # Add pivot summary from sheet_meta if available
    if sheet_meta:
        pivot_sheets = [n for n, m in sheet_meta.items() if m.get("is_pivot")]
        if pivot_sheets:
            first_pivot = pivot_sheets[0]
            gt = sheet_meta[first_pivot].get("grand_total", {})
            row_total = gt.get("Row_Total", 0)
            red_total = gt.get("Red", 0)
            if row_total:
                parts.append(
                    f"CDE scorecard ({first_pivot}): {row_total} total rules, "
                    f"{red_total} Red failures across {len(pivot_sheets)} pivot sheets."
                )

    return " ".join(parts)


@router.post("/onboard")
async def onboard_scorecard(
    scorecard_id: str = Form(...),
    display_name: str = Form(...),
    legal_entity: str = Form("ALL"),
    kri_id: str = Form(""),
    reporting_month: str = Form(""),
    data_file: UploadFile = File(...),
    doc_files: List[UploadFile] = File([]),
    x_user_id: str = Header(default="PG23137"),
):
    """Onboard a new scorecard with multi-sheet support. Admin role required."""
    if not check_role(x_user_id, "admin"):
        raise HTTPException(status_code=403, detail="Admin role required to onboard scorecards")

    try:
        # Step 1: Parse file
        _set_progress(scorecard_id, 1, f"Parsing {data_file.filename}...")
        data_content = await data_file.read()

        # Step 1b: Validate
        _set_progress(scorecard_id, 1, "Validating file...")
        validation = validate_upload(data_content, data_file.filename)
        if not validation["valid"]:
            errors = "; ".join(validation["errors"])
            _set_progress(scorecard_id, 1, f"Validation failed: {errors}", "error")
            raise HTTPException(status_code=400, detail=f"Validation failed: {errors}")

        # Step 2: Load all sheets and detect columns (5-tuple return)
        _set_progress(scorecard_id, 2, "Detecting columns and schema...")
        all_sheets, primary_df, schema, visual_config, sheet_meta = process_all_sheets(
            data_content, data_file.filename
        )
        sheet_count = len(all_sheets)
        _set_progress(
            scorecard_id, 2,
            f"Found {len(primary_df.columns)} columns, {sheet_count} sheet(s), "
            f"{len(schema.get('measure', []))} measures, {len(schema.get('dimension', []))} dimensions"
        )

        # Derive pivot/raw sheet name lists from sheet_meta
        pivot_sheet_names = [n for n, m in sheet_meta.items() if m.get("is_pivot")]
        raw_sheet_names = [n for n, m in sheet_meta.items() if not m.get("is_pivot")]
        all_sheet_names = list(all_sheets.keys())

        # Auto-detect reporting_month from first pivot sheet if not provided
        if not reporting_month:
            for pname in pivot_sheet_names:
                bd = sheet_meta[pname].get("business_date", "")
                if bd and len(bd) >= 7:
                    reporting_month = bd[:7]
                    log.info(f"Auto-detected reporting_month from '{pname}': {reporting_month}")
                    break
        if not reporting_month:
            reporting_month = datetime.utcnow().strftime("%Y-%m")
            log.info(f"No reporting_month detected, defaulting to current: {reporting_month}")

        # Generate display_title
        display_label = _format_month_label(reporting_month)
        display_title = f"{display_name} -- {display_label}"

        # Step 3: Build visual config (already done in process_all_sheets)
        _set_progress(scorecard_id, 3, "Building visual configuration...")

        # Step 4: Index documents
        docs_parsed = []
        for doc in doc_files:
            if getattr(doc, "filename", None) and doc.filename:
                content = await doc.read()
                if len(content) > 0:
                    docs_parsed.append((doc.filename, content))

        vectorizer, chunks = None, []
        tfidf_matrix = None
        if docs_parsed:
            _set_progress(scorecard_id, 4, f"Indexing {len(docs_parsed)} documents...")
            vectorizer, chunks = parse_and_index_documents(docs_parsed)
            if vectorizer and chunks:
                corpus = [c["content"] for c in chunks]
                tfidf_matrix = vectorizer.transform(corpus)
                _set_progress(scorecard_id, 4, f"Indexed {len(docs_parsed)} files, {len(chunks)} chunks")
        else:
            _set_progress(scorecard_id, 4, "No documents to index")

        # Step 5: Compute KPIs and anomalies
        _set_progress(scorecard_id, 5, "Detecting anomalies...")
        kri_data = calculate_kri(primary_df, schema)
        anomalies = _detect_anomalies(primary_df, schema)
        questions = _generate_starter_questions(primary_df, schema, all_sheets, sheet_meta)
        narrative = _generate_narrative(primary_df, schema, kri_data, anomalies, sheet_meta)

        # Build KPIs list
        kpis_list = []
        if kri_data:
            total = kri_data.get("total", 0)
            failed = kri_data.get("failed", 0)
            kri_val = kri_data.get("kri", 0)
            kpis_list.append({
                "name": f"KRI Score ({kri_id or scorecard_id})",
                "current_val": kri_val,
                "threshold": 0.05,
                "direction": "lower_is_better",
                "status": "breaching" if kri_val > 0.05 else "on_track",
                "trend": "stable",
                "pct_change": 0,
            })
            kpis_list.append({
                "name": "Pass Rate",
                "current_val": (1 - kri_val),
                "threshold": 0.95,
                "direction": "higher_is_better",
                "status": "on_track" if (1 - kri_val) >= 0.95 else "at_risk",
                "trend": "stable",
                "pct_change": 0,
            })

        capabilities = {
            "time_series": bool(schema.get("date")),
            "geographic": False,
            "rag_status": bool(schema.get("rag_status")),
            "thresholds": bool(schema.get("threshold")),
            "multi_measure": len(schema.get("measure", [])) > 1,
            "multi_sheet": sheet_count > 1,
        }

        now_iso = datetime.utcnow().isoformat()

        # Build months entry for initial onboard
        month_entry = {
            "reporting_month": reporting_month,
            "display_label": display_label,
            "month_label": reporting_month,
            "df": primary_df,
            "sheets": all_sheets,
            "sheet_meta": sheet_meta,
            "uploaded_at": now_iso,
            "filename": data_file.filename,
            "row_count": len(primary_df),
            "col_count": len(primary_df.columns),
        }

        # Register
        scorecard_data = {
            "scorecard_id": scorecard_id,
            "display_name": display_name,
            "display_title": display_title,
            "source_name": display_name,
            "legal_entity": legal_entity,
            "kri_id": kri_id,
            "reporting_month": reporting_month,
            "df": primary_df,
            "sheets": all_sheets,
            "sheet_meta": sheet_meta,
            "pivot_sheet_names": pivot_sheet_names,
            "raw_sheet_names": raw_sheet_names,
            "all_sheet_names": all_sheet_names,
            "months": {reporting_month: month_entry},
            "schema": schema,
            "visual_config": visual_config,
            "doc_index": vectorizer,
            "tfidf_matrix": tfidf_matrix,
            "doc_chunks": chunks,
            "onboarded_at": now_iso,
            "row_count": len(primary_df),
            "col_count": len(primary_df.columns),
            "anomalies": anomalies,
            "anomaly_count": len(anomalies),
            "kpis": kpis_list,
            "narrative": narrative,
            "questions": questions,
            "capabilities": capabilities,
            "data_filename": data_file.filename,
            "file_modified": now_iso,
            "periods": {},
        }

        add_scorecard(scorecard_id, scorecard_data)

        # Step 6: Persist to disk
        _set_progress(scorecard_id, 6, "Persisting to disk...")
        persist_to_disk(scorecard_id)

        # Also persist the initial month
        from backend.services.scorecard_registry import persist_month_to_disk
        persist_month_to_disk(scorecard_id, reporting_month)

        # Save uploaded doc files to disk
        from backend.services.scorecard_registry import STORAGE_DIR
        docs_dir = STORAGE_DIR / scorecard_id / "docs"
        docs_dir.mkdir(parents=True, exist_ok=True)
        for doc_name, doc_content in docs_parsed:
            with open(docs_dir / doc_name, "wb") as f:
                f.write(doc_content)

        _set_progress(scorecard_id, 7, "Ready", "done")
        log.info(
            f"Onboarded '{scorecard_id}': {len(primary_df)} rows, "
            f"{sheet_count} sheets ({pivot_sheet_names}), "
            f"reporting_month={reporting_month}, "
            f"{len(anomalies)} anomalies, {len(questions)} questions"
        )

        # Prepare sheet_meta for response (no DataFrames)
        resp_sheet_meta = {}
        for sname, smeta in sheet_meta.items():
            resp_sheet_meta[sname] = {k: v for k, v in smeta.items() if k != "df"}

        return {
            "status": "success",
            "scorecard_id": scorecard_id,
            "source_id": scorecard_id,
            "source_name": display_name,
            "display_title": display_title,
            "reporting_month": reporting_month,
            "dashboard_type": "CDE Exception Scorecard",
            "extraction_strategy": "csv" if data_file.filename.endswith(".csv") else "excel",
            "total_rows": len(primary_df),
            "total_cols": len(primary_df.columns),
            "onboarded_at": now_iso,
            "schema_detected": schema,
            "visual_config": visual_config,
            "anomalies": anomalies,
            "anomaly_count": len(anomalies),
            "kpis": kpis_list,
            "narrative": narrative,
            "questions": questions,
            "capabilities": capabilities,
            "dimensions": schema.get("dimension", []),
            "measures": schema.get("measure", []),
            "time_cols": schema.get("date", []),
            "status_cols": schema.get("rag_status", []),
            "entities": [],
            "sheet_count": sheet_count,
            "sheet_names": all_sheet_names,
            "pivot_sheet_names": pivot_sheet_names,
            "raw_sheet_names": raw_sheet_names,
            "sheet_meta": resp_sheet_meta,
            "validation": validation,
        }

    except HTTPException:
        raise
    except Exception as e:
        _set_progress(scorecard_id, 0, str(e), "error")
        log.error(f"Onboard failed for '{scorecard_id}': {e}")
        raise HTTPException(status_code=500, detail=f"Onboarding failed: {str(e)}")


@router.delete("/{scorecard_id}")
async def delete_scorecard_endpoint(scorecard_id: str, x_user_id: str = Header(default="PG23137")):
    """Delete a scorecard. Admin role required."""
    if not check_role(x_user_id, "admin"):
        raise HTTPException(status_code=403, detail="Admin role required to delete scorecards")

    removed = delete_scorecard(scorecard_id)
    if not removed:
        raise HTTPException(status_code=404, detail=f"Scorecard '{scorecard_id}' not found")

    return {"status": "deleted", "scorecard_id": scorecard_id}


@router.post("/{scorecard_id}/refresh")
async def refresh_scorecard(scorecard_id: str, x_user_id: str = Header(default="PG23137")):
    """Re-read data file from disk and recompute schema."""
    if not check_role(x_user_id, "analyst"):
        raise HTTPException(status_code=403, detail="Analyst role or higher required")

    ok = refresh_from_disk(scorecard_id)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Could not refresh '{scorecard_id}'")

    return {"status": "refreshed", "scorecard_id": scorecard_id}


def get_progress(scorecard_id: str) -> Dict[str, Any]:
    """Get current progress for SSE streaming."""
    return _PROGRESS.get(scorecard_id, {"step": 0, "label": "Waiting...", "status": "wait"})
