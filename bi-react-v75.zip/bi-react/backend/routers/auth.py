"""
routers/auth.py — v7

Simple WWID-based login + role enforcement.
Loads users from users.json in project root.
"""
import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any
from fastapi import APIRouter, Request, HTTPException, Header

log = logging.getLogger("auth")

router = APIRouter()

USERS_FILE = Path(__file__).parent.parent.parent / "users.json"
_USERS: Dict[str, Dict[str, Any]] = {}


def _load_users() -> None:
    """Load users from users.json file."""
    global _USERS
    if USERS_FILE.exists():
        with open(USERS_FILE, "r", encoding="utf-8") as f:
            _USERS = json.load(f)
        log.info(f"Loaded {len(_USERS)} users from {USERS_FILE}")
    else:
        log.warning(f"users.json not found at {USERS_FILE}, creating default")
        _USERS = {
            "PG23137": {"name": "Prathmesh Gayakwad", "role": "admin", "entity": "ALL"},
        }
        with open(USERS_FILE, "w", encoding="utf-8") as f:
            json.dump(_USERS, f, indent=2)


# Load on import
_load_users()


def get_user(user_id: str) -> Optional[Dict[str, Any]]:
    """Get user config by WWID. Returns None if not found."""
    if not _USERS:
        _load_users()
    user = _USERS.get(user_id)
    if user:
        return {**user, "user_id": user_id}
    return None


def check_role(user_id: str, required_role: str) -> bool:
    """
    Check if user has the required role level.
    admin > analyst > viewer
    """
    role_levels = {"admin": 3, "analyst": 2, "viewer": 1}
    user = get_user(user_id)
    if not user:
        return False
    user_level = role_levels.get(user.get("role", "viewer"), 0)
    required_level = role_levels.get(required_role, 99)
    return user_level >= required_level


def check_entity_access(user_id: str, scorecard_entity: str) -> bool:
    """Check if user can access a scorecard based on entity scope."""
    user = get_user(user_id)
    if not user:
        return False
    user_entity = user.get("entity", "ALL")
    if user_entity == "ALL":
        return True
    return user_entity == scorecard_entity


# ── API Endpoints ──

@router.post("/login")
async def login(request: Request):
    """Login with WWID. No password for now (Citi AD integration later)."""
    body = await request.json()
    wwid = body.get("wwid", "").strip().upper()

    if not wwid:
        raise HTTPException(status_code=400, detail="WWID is required")

    user = get_user(wwid)
    if not user:
        raise HTTPException(status_code=403, detail=f"User '{wwid}' not found. Contact admin to get access.")

    log.info(f"Login: {wwid} ({user['name']}, role={user['role']})")
    return {
        "status": "ok",
        "user_id": wwid,
        "name": user["name"],
        "role": user["role"],
        "entity": user.get("entity", "ALL"),
    }


@router.get("/users")
async def list_users(x_user_id: str = Header(default="")):
    """Admin-only: list all users."""
    if not check_role(x_user_id, "admin"):
        raise HTTPException(status_code=403, detail="Admin access required")

    return [
        {"user_id": uid, **udata}
        for uid, udata in _USERS.items()
    ]
