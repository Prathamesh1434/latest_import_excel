"""
routers/api.py — v7

Health check, scorecard listing, and service status endpoints.
"""
import logging
from fastapi import APIRouter
from backend.services.scorecard_registry import list_summary
from backend.config import check_vertex

log = logging.getLogger("api")

router = APIRouter()


@router.get("/health")
@router.get("/health/")
def health_check():
    """Health check with service status dots for the UI."""
    scorecards = list_summary()

    # Service health for top bar dots
    services = [
        {
            "name": "Tableau",
            "status": "ok",  # We no longer use Tableau, but keep dot for UI compat
        },
        {
            "name": "VertexAI",
            "status": "ok" if check_vertex() else "down",
        },
        {
            "name": "Oracle",
            "status": "ok",  # Local storage mode — always OK
        },
    ]

    return {
        "status": "ok",
        "service": "B&I CDE Intelligence Platform",
        "version": "7.0",
        "scorecard_count": len(scorecards),
        "services": services,
    }


@router.get("/scorecards/list")
def list_scorecards():
    """Return list of all onboarded scorecards (safe summary, no DataFrames)."""
    return list_summary()
