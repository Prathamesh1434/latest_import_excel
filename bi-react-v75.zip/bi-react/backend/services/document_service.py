"""
services/document_service.py — v7.1

Enhanced document parser with:
- PDF text + table extraction (via pdfplumber)
- DOCX text + table extraction (via python-docx)
- Image-based table extraction (via pytesseract OCR fallback)
- Plain text / markdown parsing
- TF-IDF indexing and cosine similarity search
"""
import os
import re
import io
import logging
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from typing import List, Dict, Any, Tuple, Optional

log = logging.getLogger("document_service")


# ══════ PARSERS ══════

def _parse_txt(content: bytes, filename: str) -> str:
    """Parse plain text / markdown files."""
    try:
        return content.decode("utf-8")
    except UnicodeDecodeError:
        return content.decode("latin-1", errors="replace")


def _parse_pdf(content: bytes, filename: str) -> str:
    """
    Parse PDF: extract text + tables.
    Tables are converted to markdown format for better TF-IDF matching.
    """
    text_parts = []

    try:
        import pdfplumber

        with pdfplumber.open(io.BytesIO(content)) as pdf:
            for page_num, page in enumerate(pdf.pages, 1):
                # Extract text
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(f"[Page {page_num}]\n{page_text}")

                # Extract tables
                tables = page.extract_tables()
                for t_idx, table in enumerate(tables):
                    if not table or not table[0]:
                        continue
                    # Convert table to markdown format
                    md_table = _table_to_markdown(table)
                    text_parts.append(f"[Page {page_num} - Table {t_idx + 1}]\n{md_table}")

                # Try to extract images with text (OCR fallback)
                try:
                    images = page.images
                    if images and not page_text:
                        # Page has images but no text — try OCR
                        ocr_text = _ocr_page_image(page)
                        if ocr_text:
                            text_parts.append(f"[Page {page_num} - OCR]\n{ocr_text}")
                except Exception:
                    pass

        log.info(f"Parsed PDF '{filename}': {len(pdf.pages)} pages, {len(text_parts)} sections")

    except ImportError:
        log.warning("pdfplumber not installed. Falling back to basic text extraction.")
        # Fallback: try PyPDF2
        try:
            from PyPDF2 import PdfReader
            reader = PdfReader(io.BytesIO(content))
            for i, page in enumerate(reader.pages, 1):
                t = page.extract_text()
                if t:
                    text_parts.append(f"[Page {i}]\n{t}")
        except ImportError:
            log.warning("PyPDF2 also not installed. PDF content will be limited.")
            text_parts.append(_parse_txt(content, filename))
        except Exception as e:
            log.warning(f"PyPDF2 fallback failed for '{filename}': {e}")

    except Exception as e:
        log.error(f"PDF parsing failed for '{filename}': {e}")
        text_parts.append(_parse_txt(content, filename))

    return "\n\n".join(text_parts)


def _parse_docx(content: bytes, filename: str) -> str:
    """
    Parse DOCX: extract paragraphs + tables.
    Tables are converted to markdown format.
    """
    text_parts = []

    try:
        from docx import Document

        doc = Document(io.BytesIO(content))

        # Extract paragraphs
        for para in doc.paragraphs:
            text = para.text.strip()
            if text:
                # Detect heading styles
                if para.style and para.style.name and "Heading" in para.style.name:
                    level = para.style.name.replace("Heading", "").strip()
                    prefix = "#" * (int(level) if level.isdigit() else 1)
                    text_parts.append(f"{prefix} {text}")
                else:
                    text_parts.append(text)

        # Extract tables
        for t_idx, table in enumerate(doc.tables):
            rows = []
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                rows.append(cells)

            if rows:
                md_table = _table_to_markdown(rows)
                text_parts.append(f"[Table {t_idx + 1}]\n{md_table}")

        # Try to extract images (embedded) — get alt text at minimum
        try:
            for rel in doc.part.rels.values():
                if "image" in rel.reltype:
                    # We can't OCR embedded images easily without saving to disk,
                    # but we note their presence
                    text_parts.append("[Embedded Image detected — OCR not available for inline DOCX images]")
                    break
        except Exception:
            pass

        log.info(f"Parsed DOCX '{filename}': {len(doc.paragraphs)} paras, {len(doc.tables)} tables")

    except ImportError:
        log.warning("python-docx not installed. DOCX tables won't be extracted.")
        text_parts.append(_parse_txt(content, filename))

    except Exception as e:
        log.error(f"DOCX parsing failed for '{filename}': {e}")
        text_parts.append(_parse_txt(content, filename))

    return "\n\n".join(text_parts)


def _table_to_markdown(table: List[List[str]]) -> str:
    """Convert a 2D table (list of rows) to markdown table format."""
    if not table:
        return ""

    # Clean cells
    cleaned = []
    for row in table:
        cleaned.append([str(cell).strip().replace("|", "/").replace("\n", " ") if cell else "" for cell in row])

    if not cleaned:
        return ""

    # Determine column widths
    num_cols = max(len(r) for r in cleaned)

    # Pad rows to same length
    for row in cleaned:
        while len(row) < num_cols:
            row.append("")

    lines = []
    # Header
    lines.append("| " + " | ".join(cleaned[0]) + " |")
    lines.append("| " + " | ".join(["---"] * num_cols) + " |")
    # Data rows
    for row in cleaned[1:]:
        lines.append("| " + " | ".join(row) + " |")

    # Also add a flat text version for TF-IDF (tables in markdown may not tokenize well)
    flat_parts = []
    for row in cleaned:
        flat_parts.append(", ".join([c for c in row if c]))

    return "\n".join(lines) + "\n\nFlat data: " + "; ".join(flat_parts)


def _ocr_page_image(page) -> Optional[str]:
    """
    Attempt OCR on a PDF page image.
    Requires: Pillow, pytesseract, and tesseract binary installed.
    """
    try:
        from PIL import Image
        import pytesseract

        # Convert PDF page to image
        img = page.to_image(resolution=200)
        pil_img = img.original

        # Run OCR
        text = pytesseract.image_to_string(pil_img)
        return text.strip() if text and text.strip() else None

    except ImportError:
        return None
    except Exception as e:
        log.debug(f"OCR failed: {e}")
        return None


# ══════ SMART CHUNKER ══════

def _smart_chunk(text: str, filename: str, max_chunk_size: int = 800) -> List[Dict[str, Any]]:
    """
    Chunk text intelligently:
    - Split on section headers (markdown ## or [Page X])
    - Keep tables intact as single chunks
    - Respect max chunk size
    """
    chunks = []

    # Split on section markers
    sections = re.split(r'\n(?=\[Page \d|#{1,3} |---)', text)

    for section in sections:
        section = section.strip()
        if not section:
            continue

        # Detect section name
        section_name = "Content"
        header_match = re.match(r'^(\[.*?\]|#{1,3}\s+.*)', section)
        if header_match:
            section_name = header_match.group(1).strip("[]# ")

        # If section is small enough, keep as one chunk
        if len(section) <= max_chunk_size:
            chunks.append({
                "doc_name": filename,
                "section": section_name,
                "content": section,
            })
        else:
            # Split into smaller chunks by paragraph
            paragraphs = section.split("\n\n")
            current_chunk = ""
            for para in paragraphs:
                if len(current_chunk) + len(para) + 2 > max_chunk_size and current_chunk:
                    chunks.append({
                        "doc_name": filename,
                        "section": section_name,
                        "content": current_chunk.strip(),
                    })
                    current_chunk = para
                else:
                    current_chunk += "\n\n" + para if current_chunk else para

            if current_chunk.strip():
                chunks.append({
                    "doc_name": filename,
                    "section": section_name,
                    "content": current_chunk.strip(),
                })

    return chunks


# ══════ MAIN ENTRY POINTS ══════

def parse_and_index_documents(doc_files: List[Tuple[str, bytes]]) -> Tuple[Any, List[Dict[str, Any]]]:
    """
    Parses document bytes (TXT, PDF, DOCX), splits into chunks,
    and builds a TF-IDF index.
    Returns the vectorizer and the list of document chunks.
    """
    all_chunks = []

    for filename, content in doc_files:
        fname_lower = filename.lower()

        try:
            if fname_lower.endswith(".pdf"):
                text = _parse_pdf(content, filename)
            elif fname_lower.endswith((".docx", ".doc")):
                text = _parse_docx(content, filename)
            else:
                # .txt, .md, .csv, etc.
                text = _parse_txt(content, filename)

            # Smart chunk the parsed text
            file_chunks = _smart_chunk(text, filename)

            if not file_chunks:
                # Fallback: simple paragraph split
                paragraphs = text.split("\n\n")
                for i, p in enumerate(paragraphs):
                    p = p.strip()
                    if p:
                        file_chunks.append({
                            "doc_name": filename,
                            "section": f"Chunk {i}",
                            "content": p,
                        })

            all_chunks.extend(file_chunks)
            log.info(f"Parsed '{filename}': {len(file_chunks)} chunks")

        except Exception as e:
            log.error(f"Failed to parse '{filename}': {e}")
            # Still try to extract raw text
            try:
                raw = content.decode("utf-8", errors="replace")
                if raw.strip():
                    all_chunks.append({
                        "doc_name": filename,
                        "section": "Raw",
                        "content": raw[:2000],
                    })
            except Exception:
                pass

    if not all_chunks:
        return None, []

    vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)
    corpus = [c["content"] for c in all_chunks]
    vectorizer.fit(corpus)

    log.info(f"TF-IDF index built: {len(all_chunks)} chunks, {len(vectorizer.vocabulary_)} features")
    return vectorizer, all_chunks


def search_documents(query: str, vectorizer: TfidfVectorizer, chunks: List[Dict[str, Any]], top_k: int = 5) -> List[Dict[str, Any]]:
    """Search indexed documents using cosine similarity."""
    if not vectorizer or not chunks:
        return []

    corpus = [c["content"] for c in chunks]
    tfidf_matrix = vectorizer.transform(corpus)
    query_vec = vectorizer.transform([query])

    similarities = cosine_similarity(query_vec, tfidf_matrix).flatten()
    top_indices = similarities.argsort()[-top_k:][::-1]

    results = []
    for idx in top_indices:
        if similarities[idx] > 0.03:  # Lower threshold for table content
            res = chunks[idx].copy()
            res["score"] = float(similarities[idx])
            results.append(res)

    return results
