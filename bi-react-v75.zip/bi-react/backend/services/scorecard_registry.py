"""
services/scorecard_registry.py -- v7.4

In-memory registry with full disk persistence.
Supports multiple sheets per scorecard, sheet_meta with pivot metadata,
reporting_month tracking, and month-based data storage.

Storage layout:
  storage/{scorecard_id}/
    data.csv                    <- primary sheet
    metadata.json               <- config, schema, KPIs, anomalies, sheet_meta
    sheets/                     <- all Excel sheets (original names)
      Raw Data.csv
      Consolidated.csv
      Solo CGME.csv
    months/                     <- month-based data
      2026-01/
        data.csv                <- primary sheet for that month
        sheets/                 <- all sheets for that month
        metadata.json
      2026-02/
    docs/                       <- uploaded documents
    index/                      <- TF-IDF vectorizer + matrix
    chat_history/               <- per-user chat logs
"""
import os
import json
import pickle
import logging
import shutil
import re
import pandas as pd
from datetime import datetime
from typing import Dict, Any, Optional, List
from pathlib import Path

log = logging.getLogger("scorecard_registry")

STORAGE_DIR = Path(__file__).parent.parent.parent / "storage"

# In-memory registry
_REGISTRY: Dict[str, Dict[str, Any]] = {}


# ============================================================
# CRUD
# ============================================================

def add_scorecard(scorecard_id: str, data: Dict[str, Any]) -> None:
    """Add a scorecard to the in-memory registry."""
    _REGISTRY[scorecard_id] = data
    log.info(f"Registered scorecard '{scorecard_id}' ({data.get('row_count', 0)} rows)")


def get_scorecard(scorecard_id: str) -> Dict[str, Any]:
    """Get a scorecard from the registry. Raises if not found."""
    if scorecard_id not in _REGISTRY:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"Scorecard '{scorecard_id}' not found")
    return _REGISTRY[scorecard_id]


def delete_scorecard(scorecard_id: str) -> bool:
    """Remove a scorecard from registry and disk."""
    if scorecard_id not in _REGISTRY:
        return False

    del _REGISTRY[scorecard_id]

    sc_dir = STORAGE_DIR / scorecard_id
    if sc_dir.exists():
        shutil.rmtree(sc_dir)
        log.info(f"Deleted scorecard '{scorecard_id}' from registry and disk")
    else:
        log.info(f"Deleted scorecard '{scorecard_id}' from registry (no disk data)")
    return True


def list_all() -> Dict[str, Dict[str, Any]]:
    """Return the full registry (for internal use)."""
    return _REGISTRY


def list_summary() -> List[Dict[str, Any]]:
    """Return a safe summary list of all scorecards for the API."""
    result = []
    for sid, data in _REGISTRY.items():
        # Basic dates
        onboarded_at = data.get("onboarded_at", "")
        file_modified = data.get("file_modified", "")

        # Month info
        months = data.get("months", {})
        month_count = len(months)
        months_available = sorted(list(months.keys()))

        # Sheet info
        sheets = data.get("sheets", {})
        sheet_names = list(sheets.keys()) if sheets else ["raw"]

        # Sheet meta (serializable -- no DataFrames)
        raw_sheet_meta = data.get("sheet_meta", {})
        safe_sheet_meta = {}
        for sname, smeta in raw_sheet_meta.items():
            safe_sheet_meta[sname] = {k: v for k, v in smeta.items() if k != "df"}

        # Pivot and raw sheet name lists
        pivot_sheet_names = data.get("pivot_sheet_names", [])
        raw_sheet_names = data.get("raw_sheet_names", [])

        # RAG summary from first pivot sheet grand_total
        rag_summary = data.get("rag_summary", {})
        if not rag_summary and raw_sheet_meta:
            for sname, smeta in raw_sheet_meta.items():
                if smeta.get("is_pivot") and smeta.get("grand_total"):
                    gt = smeta["grand_total"]
                    rag_summary = {
                        "Red": gt.get("Red", 0),
                        "Amber": gt.get("Amber", 0),
                        "Green": gt.get("Green", 0),
                        "Dark Green": gt.get("Dark Green", 0),
                        "Row_Total": gt.get("Row_Total", 0),
                    }
                    break

        # Days since update
        try:
            mod_dt = datetime.fromisoformat(file_modified) if file_modified else datetime.utcnow()
            days_since_update = (datetime.utcnow() - mod_dt).days
        except Exception:
            days_since_update = 0

        result.append({
            "scorecard_id": sid,
            "display_name": data.get("display_name", sid),
            "display_title": data.get("display_title", data.get("display_name", sid)),
            "source_name": data.get("source_name", data.get("display_name", sid)),
            "legal_entity": data.get("legal_entity", "ALL"),
            "kri_id": data.get("kri_id", ""),
            "row_count": data.get("row_count", 0),
            "col_count": data.get("col_count", 0),
            "total_rows": data.get("row_count", 0),
            "total_cols": data.get("col_count", 0),
            "onboarded_at": onboarded_at,
            "file_modified": file_modified,
            "anomaly_count": data.get("anomaly_count", 0),
            "anomalies": data.get("anomalies", []),
            "month_count": month_count,
            "months_available": months_available,
            "reporting_month": data.get("reporting_month", ""),
            "sheet_names": sheet_names,
            "pivot_sheet_names": pivot_sheet_names,
            "raw_sheet_names": raw_sheet_names,
            "sheet_meta": safe_sheet_meta,
            "rag_summary": rag_summary,
            "narrative": data.get("narrative", ""),
            "kpis": data.get("kpis", []),
            "days_since_update": days_since_update,
            "is_stale": days_since_update > 30,
            "questions": data.get("questions", []),
            "capabilities": data.get("capabilities", {}),
        })
    return result


def _safe_filename(name: str) -> str:
    """Convert sheet name to a safe filename."""
    s = re.sub(r'[<>:"/\\|?*]', '_', name.strip())
    return s[:80] if s else "unnamed"


# ============================================================
# DISK PERSISTENCE
# ============================================================

def persist_to_disk(scorecard_id: str) -> None:
    """Persist a scorecard from memory to storage/{scorecard_id}/."""
    if scorecard_id not in _REGISTRY:
        log.warning(f"Cannot persist '{scorecard_id}': not in registry")
        return

    data = _REGISTRY[scorecard_id]
    sc_dir = STORAGE_DIR / scorecard_id
    sc_dir.mkdir(parents=True, exist_ok=True)

    # 1. Save primary DataFrame
    df = data.get("df")
    if df is not None:
        df.to_csv(sc_dir / "data.csv", index=False)

    # 2. Save all sheets (using safe filenames from original names)
    sheets = data.get("sheets", {})
    if sheets:
        sheets_dir = sc_dir / "sheets"
        sheets_dir.mkdir(exist_ok=True)
        for sheet_name, sheet_df in sheets.items():
            if isinstance(sheet_df, pd.DataFrame):
                safe_name = _safe_filename(sheet_name)
                sheet_df.to_csv(sheets_dir / f"{safe_name}.csv", index=False)

    # 3. Prepare sheet_meta for serialization (no DataFrames)
    raw_sheet_meta = data.get("sheet_meta", {})
    serializable_sheet_meta = {}
    for sname, smeta in raw_sheet_meta.items():
        serializable_sheet_meta[sname] = {k: v for k, v in smeta.items() if k != "df"}

    # 4. Save metadata
    meta = {
        "scorecard_id": scorecard_id,
        "display_name": data.get("display_name", ""),
        "display_title": data.get("display_title", ""),
        "source_name": data.get("source_name", ""),
        "legal_entity": data.get("legal_entity", "ALL"),
        "kri_id": data.get("kri_id", ""),
        "reporting_month": data.get("reporting_month", ""),
        "onboarded_at": data.get("onboarded_at", ""),
        "row_count": data.get("row_count", 0),
        "col_count": data.get("col_count", 0),
        "schema": data.get("schema", {}),
        "visual_config": data.get("visual_config", {}),
        "anomalies": data.get("anomalies", []),
        "anomaly_count": data.get("anomaly_count", 0),
        "kpis": data.get("kpis", []),
        "narrative": data.get("narrative", ""),
        "questions": data.get("questions", []),
        "capabilities": data.get("capabilities", {}),
        "file_modified": data.get("file_modified", ""),
        "data_filename": data.get("data_filename", ""),
        "sheet_names": list(sheets.keys()) if sheets else ["raw"],
        "pivot_sheet_names": data.get("pivot_sheet_names", []),
        "raw_sheet_names": data.get("raw_sheet_names", []),
        "all_sheet_names": data.get("all_sheet_names", []),
        "sheet_meta": serializable_sheet_meta,
        "periods": data.get("periods", {}),
        # Store sheet_name -> safe_filename mapping for restore
        "_sheet_name_to_file": {name: _safe_filename(name) for name in sheets.keys()} if sheets else {},
    }
    with open(sc_dir / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, default=str)

    # 5. Save TF-IDF index
    idx_dir = sc_dir / "index"
    idx_dir.mkdir(exist_ok=True)

    vectorizer = data.get("doc_index")
    if vectorizer is not None:
        with open(idx_dir / "tfidf_vectorizer.pkl", "wb") as f:
            pickle.dump(vectorizer, f)

    tfidf_matrix = data.get("tfidf_matrix")
    if tfidf_matrix is not None:
        with open(idx_dir / "tfidf_matrix.pkl", "wb") as f:
            pickle.dump(tfidf_matrix, f)

    chunks = data.get("doc_chunks", [])
    if chunks:
        with open(idx_dir / "doc_chunks.json", "w", encoding="utf-8") as f:
            json.dump(chunks, f, indent=2)

    log.info(f"Persisted '{scorecard_id}' to {sc_dir}")


def persist_month_to_disk(scorecard_id: str, month_label: str) -> None:
    """Persist a single month's data to disk."""
    if scorecard_id not in _REGISTRY:
        return

    data = _REGISTRY[scorecard_id]
    months = data.get("months", {})
    month_data = months.get(month_label)
    if not month_data:
        return

    month_dir = STORAGE_DIR / scorecard_id / "months" / month_label
    month_dir.mkdir(parents=True, exist_ok=True)

    # Save primary DataFrame
    df = month_data.get("df")
    if df is not None:
        df.to_csv(month_dir / "data.csv", index=False)

    # Save all sheets for this month
    sheets = month_data.get("sheets", {})
    if sheets:
        sheets_dir = month_dir / "sheets"
        sheets_dir.mkdir(exist_ok=True)
        for sheet_name, sheet_df in sheets.items():
            if isinstance(sheet_df, pd.DataFrame):
                safe_name = _safe_filename(sheet_name)
                sheet_df.to_csv(sheets_dir / f"{safe_name}.csv", index=False)

    # Prepare month sheet_meta for serialization
    month_sheet_meta = month_data.get("sheet_meta", {})
    serializable_month_meta = {}
    for sname, smeta in month_sheet_meta.items():
        serializable_month_meta[sname] = {k: v for k, v in smeta.items() if k != "df"}

    # Save month metadata
    meta = {
        "month_label": month_label,
        "reporting_month": month_data.get("reporting_month", month_label),
        "display_label": month_data.get("display_label", ""),
        "uploaded_at": month_data.get("uploaded_at", ""),
        "filename": month_data.get("filename", ""),
        "row_count": month_data.get("row_count", 0),
        "col_count": month_data.get("col_count", 0),
        "sheet_names": list(sheets.keys()) if sheets else ["raw"],
        "sheet_meta": serializable_month_meta,
        "_sheet_name_to_file": {name: _safe_filename(name) for name in sheets.keys()} if sheets else {},
    }
    with open(month_dir / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, default=str)

    # Update main metadata with periods info
    persist_to_disk(scorecard_id)
    log.info(f"Persisted month '{month_label}' for '{scorecard_id}' to {month_dir}")


# ============================================================
# RESTORE FROM DISK
# ============================================================

def restore_all_from_disk() -> int:
    """Scan storage/ and restore all scorecards into memory. Returns count."""
    if not STORAGE_DIR.exists():
        STORAGE_DIR.mkdir(parents=True, exist_ok=True)
        log.info("Created storage/ directory")
        return 0

    restored = 0
    for sc_dir in STORAGE_DIR.iterdir():
        if not sc_dir.is_dir():
            continue

        scorecard_id = sc_dir.name
        meta_path = sc_dir / "metadata.json"
        data_path = sc_dir / "data.csv"

        if not meta_path.exists():
            log.warning(f"Skipping {scorecard_id}: no metadata.json")
            continue

        try:
            # Load metadata
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)

            # Load primary DataFrame
            df = None
            if data_path.exists():
                df = pd.read_csv(data_path)
                _fill_string_na(df)

            # Build name-to-file mapping from metadata
            name_to_file = meta.get("_sheet_name_to_file", {})

            # Load all sheets
            sheets = {}
            sheets_dir = sc_dir / "sheets"
            if sheets_dir.exists():
                if name_to_file:
                    # Use the mapping to restore original names
                    for orig_name, safe_name in name_to_file.items():
                        csv_path = sheets_dir / f"{safe_name}.csv"
                        if csv_path.exists():
                            try:
                                sheet_df = pd.read_csv(csv_path)
                                _fill_string_na(sheet_df)
                                sheets[orig_name] = sheet_df
                            except Exception as e:
                                log.warning(f"  Failed to load sheet '{orig_name}': {e}")
                else:
                    # Legacy: use filenames as keys
                    for csv_file in sheets_dir.glob("*.csv"):
                        sheet_name = csv_file.stem
                        try:
                            sheet_df = pd.read_csv(csv_file)
                            _fill_string_na(sheet_df)
                            sheets[sheet_name] = sheet_df
                        except Exception as e:
                            log.warning(f"  Failed to load sheet '{sheet_name}': {e}")

            if not sheets and df is not None:
                sheets["raw"] = df

            # Load TF-IDF index
            vectorizer = None
            tfidf_matrix = None
            chunks = []

            idx_dir = sc_dir / "index"
            if (idx_dir / "tfidf_vectorizer.pkl").exists():
                with open(idx_dir / "tfidf_vectorizer.pkl", "rb") as f:
                    vectorizer = pickle.load(f)
            if (idx_dir / "tfidf_matrix.pkl").exists():
                with open(idx_dir / "tfidf_matrix.pkl", "rb") as f:
                    tfidf_matrix = pickle.load(f)
            if (idx_dir / "doc_chunks.json").exists():
                with open(idx_dir / "doc_chunks.json", "r", encoding="utf-8") as f:
                    chunks = json.load(f)

            # Load months
            months = {}
            months_dir = sc_dir / "months"
            if months_dir.exists():
                for month_dir in sorted(months_dir.iterdir()):
                    if not month_dir.is_dir():
                        continue
                    month_label = month_dir.name
                    month_data_path = month_dir / "data.csv"
                    month_meta_path = month_dir / "metadata.json"

                    month_entry = {"month_label": month_label}

                    # Load month metadata first to get name mapping
                    month_name_map = {}
                    month_sheet_meta_restored = {}
                    if month_meta_path.exists():
                        try:
                            with open(month_meta_path, "r", encoding="utf-8") as f:
                                mm = json.load(f)
                            month_entry["uploaded_at"] = mm.get("uploaded_at", "")
                            month_entry["filename"] = mm.get("filename", "")
                            month_entry["reporting_month"] = mm.get("reporting_month", month_label)
                            month_entry["display_label"] = mm.get("display_label", "")
                            month_entry["row_count"] = mm.get("row_count", 0)
                            month_name_map = mm.get("_sheet_name_to_file", {})
                            month_sheet_meta_restored = mm.get("sheet_meta", {})
                        except Exception:
                            pass

                    if month_data_path.exists():
                        month_df = pd.read_csv(month_data_path)
                        _fill_string_na(month_df)
                        month_entry["df"] = month_df
                        month_entry["row_count"] = len(month_df)
                        month_entry["col_count"] = len(month_df.columns)

                    # Load month sheets
                    month_sheets_dir = month_dir / "sheets"
                    month_sheets = {}
                    if month_sheets_dir.exists():
                        if month_name_map:
                            for orig_name, safe_name in month_name_map.items():
                                csv_path = month_sheets_dir / f"{safe_name}.csv"
                                if csv_path.exists():
                                    try:
                                        msdf = pd.read_csv(csv_path)
                                        _fill_string_na(msdf)
                                        month_sheets[orig_name] = msdf
                                    except Exception:
                                        pass
                        else:
                            for csv_file in month_sheets_dir.glob("*.csv"):
                                try:
                                    msdf = pd.read_csv(csv_file)
                                    _fill_string_na(msdf)
                                    month_sheets[csv_file.stem] = msdf
                                except Exception:
                                    pass
                    month_entry["sheets"] = month_sheets
                    month_entry["sheet_meta"] = month_sheet_meta_restored

                    months[month_label] = month_entry

            # Restore sheet_meta from metadata.json
            sheet_meta = meta.get("sheet_meta", {})

            # Derive pivot/raw sheet name lists
            pivot_sheet_names = meta.get("pivot_sheet_names", [])
            raw_sheet_names = meta.get("raw_sheet_names", [])
            all_sheet_names = meta.get("all_sheet_names", list(sheets.keys()))

            if not pivot_sheet_names and sheet_meta:
                pivot_sheet_names = [n for n, m in sheet_meta.items() if m.get("is_pivot")]
                raw_sheet_names = [n for n, m in sheet_meta.items() if not m.get("is_pivot")]

            # Reconstruct registry entry
            entry = {
                "scorecard_id": scorecard_id,
                "display_name": meta.get("display_name", scorecard_id),
                "display_title": meta.get("display_title", meta.get("display_name", scorecard_id)),
                "source_name": meta.get("source_name", meta.get("display_name", scorecard_id)),
                "legal_entity": meta.get("legal_entity", "ALL"),
                "kri_id": meta.get("kri_id", ""),
                "reporting_month": meta.get("reporting_month", ""),
                "df": df,
                "sheets": sheets,
                "sheet_meta": sheet_meta,
                "pivot_sheet_names": pivot_sheet_names,
                "raw_sheet_names": raw_sheet_names,
                "all_sheet_names": all_sheet_names,
                "months": months,
                "schema": meta.get("schema", {}),
                "visual_config": meta.get("visual_config", {}),
                "doc_index": vectorizer,
                "tfidf_matrix": tfidf_matrix,
                "doc_chunks": chunks,
                "onboarded_at": meta.get("onboarded_at", ""),
                "row_count": meta.get("row_count", 0),
                "col_count": meta.get("col_count", 0),
                "anomalies": meta.get("anomalies", []),
                "anomaly_count": meta.get("anomaly_count", 0),
                "kpis": meta.get("kpis", []),
                "narrative": meta.get("narrative", ""),
                "questions": meta.get("questions", []),
                "capabilities": meta.get("capabilities", {}),
                "file_modified": meta.get("file_modified", ""),
                "data_filename": meta.get("data_filename", ""),
                "periods": meta.get("periods", {}),
            }
            _REGISTRY[scorecard_id] = entry
            restored += 1

            month_info = f", {len(months)} months" if months else ""
            sheet_info = f", {len(sheets)} sheets" if len(sheets) > 1 else ""
            log.info(f"Restored '{scorecard_id}' from disk ({meta.get('row_count', 0)} rows{sheet_info}{month_info})")

        except Exception as e:
            log.error(f"Failed to restore '{scorecard_id}': {e}")

    log.info(f"Restored {restored} scorecards from disk")
    return restored


def refresh_from_disk(scorecard_id: str) -> bool:
    """Re-read the CSV from disk if the file has changed."""
    sc_dir = STORAGE_DIR / scorecard_id
    data_path = sc_dir / "data.csv"
    if not data_path.exists():
        return False

    if scorecard_id not in _REGISTRY:
        return False

    try:
        from backend.services.column_classifier import classify_columns
        from backend.services.visual_generator import generate_visual_config

        df = pd.read_csv(data_path)
        _fill_string_na(df)

        schema = classify_columns(df)
        visual_config = generate_visual_config(df, schema)

        _REGISTRY[scorecard_id]["df"] = df
        _REGISTRY[scorecard_id]["schema"] = schema
        _REGISTRY[scorecard_id]["visual_config"] = visual_config
        _REGISTRY[scorecard_id]["row_count"] = len(df)
        _REGISTRY[scorecard_id]["col_count"] = len(df.columns)
        _REGISTRY[scorecard_id]["file_modified"] = datetime.utcnow().isoformat()

        persist_to_disk(scorecard_id)
        log.info(f"Refreshed '{scorecard_id}' from disk ({len(df)} rows)")
        return True
    except Exception as e:
        log.error(f"Failed to refresh '{scorecard_id}': {e}")
        return False


def _fill_string_na(df: pd.DataFrame):
    """Fill NA for string columns."""
    for col in df.columns:
        if pd.api.types.is_string_dtype(df[col]):
            df[col] = df[col].fillna("")
