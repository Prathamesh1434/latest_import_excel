# Mock vertex_util for running without real COIN Auth
class MockLLM:
    def invoke(self, messages):
        class Resp:
            content = '{"reply": "This is a mock response because the real vertex_util.py is missing.", "chart_type": "text", "chart": null}'
        return Resp()

class MockEmbeddings:
    pass

llm = MockLLM()
embeddings = MockEmbeddings()
