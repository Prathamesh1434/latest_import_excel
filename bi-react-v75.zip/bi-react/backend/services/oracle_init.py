"""
services/oracle_init.py — Auto-DDL on startup

On application startup:
  1. Connects to Oracle using .env credentials
  2. Checks which tables already exist
  3. Creates missing tables (idempotent — no duplicate errors)
  4. Logs every step

Call init_oracle_schema() from main.py lifespan.
"""

import logging
from typing import List

from backend.config import check_oracle

log = logging.getLogger("oracle_init")

# ── Required tables and their DDL ─────────────────────────────────────
REQUIRED_TABLES = [
    "BI_CHAT_SESSION",
    "BI_CHAT_HISTORY",
    "BI_API_AUDIT",
    "BI_SNAPSHOT_LOG",
    "BI_DATA_CONTEXT",
]

# Each DDL block creates ONE table + its indexes.
# Order matters: BI_CHAT_SESSION must be before BI_CHAT_HISTORY (FK).
TABLE_DDL = {
    "BI_CHAT_SESSION": [
        """CREATE TABLE BI_CHAT_SESSION (
            SESSION_ID       VARCHAR2(64)    NOT NULL,
            USER_ID          VARCHAR2(50)    NOT NULL,
            SCORECARD_ID     VARCHAR2(100)   NOT NULL,
            SCORECARD_NAME   VARCHAR2(200),
            LEGAL_ENTITY     VARCHAR2(20),
            REGION           VARCHAR2(20),
            DASHBOARD_TYPE   VARCHAR2(50),
            CREATED_DT       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
            LAST_ACTIVE_DT   TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
            MESSAGE_COUNT    NUMBER(6,0)     DEFAULT 0 NOT NULL,
            STATUS           VARCHAR2(20)    DEFAULT 'ACTIVE' NOT NULL,
            CONSTRAINT PK_BI_CHAT_SESSION PRIMARY KEY (SESSION_ID),
            CONSTRAINT CK_BI_SESS_STATUS  CHECK (STATUS IN ('ACTIVE','CLOSED','EXPIRED')),
            CONSTRAINT CK_BI_SESS_ENTITY  CHECK (LEGAL_ENTITY IN ('CGML','CGMSE','CGME','ALL') OR LEGAL_ENTITY IS NULL)
        )""",
        "CREATE INDEX IDX_BI_SESS_USER   ON BI_CHAT_SESSION (USER_ID)",
        "CREATE INDEX IDX_BI_SESS_SC     ON BI_CHAT_SESSION (SCORECARD_ID)",
        "CREATE INDEX IDX_BI_SESS_ENTITY ON BI_CHAT_SESSION (LEGAL_ENTITY)",
        "CREATE INDEX IDX_BI_SESS_DT     ON BI_CHAT_SESSION (CREATED_DT)",
        "CREATE INDEX IDX_BI_SESS_STATUS ON BI_CHAT_SESSION (STATUS)",
    ],

    "BI_CHAT_HISTORY": [
        """CREATE TABLE BI_CHAT_HISTORY (
            ID               NUMBER          GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) PRIMARY KEY,
            SESSION_ID       VARCHAR2(64)    NOT NULL,
            USER_ID          VARCHAR2(50)    NOT NULL,
            SCORECARD_ID     VARCHAR2(100)   NOT NULL,
            ROLE             VARCHAR2(20)    NOT NULL,
            CONTENT          CLOB            NOT NULL,
            CHART_TYPE       VARCHAR2(30),
            MODEL_VERSION    VARCHAR2(100),
            QUERY_METHOD     VARCHAR2(20),
            INPUT_TOKENS     NUMBER(8,0),
            OUTPUT_TOKENS    NUMBER(8,0),
            RESPONSE_TIME_MS NUMBER(8,0),
            CONFIDENCE       NUMBER(4,3),
            CREATED_DT       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
            CONSTRAINT FK_BI_HIST_SESSION FOREIGN KEY (SESSION_ID) REFERENCES BI_CHAT_SESSION (SESSION_ID),
            CONSTRAINT CK_BI_HIST_ROLE CHECK (ROLE IN ('user','assistant','system')),
            CONSTRAINT CK_BI_HIST_METHOD CHECK (QUERY_METHOD IN ('llm','rules','hybrid') OR QUERY_METHOD IS NULL),
            CONSTRAINT CK_BI_HIST_CONF CHECK (CONFIDENCE BETWEEN 0 AND 1 OR CONFIDENCE IS NULL)
        )""",
        "CREATE INDEX IDX_BI_HIST_SESSION ON BI_CHAT_HISTORY (SESSION_ID)",
        "CREATE INDEX IDX_BI_HIST_USER    ON BI_CHAT_HISTORY (USER_ID)",
        "CREATE INDEX IDX_BI_HIST_SC      ON BI_CHAT_HISTORY (SCORECARD_ID)",
        "CREATE INDEX IDX_BI_HIST_DT      ON BI_CHAT_HISTORY (CREATED_DT)",
        "CREATE INDEX IDX_BI_HIST_METHOD  ON BI_CHAT_HISTORY (QUERY_METHOD)",
    ],

    "BI_API_AUDIT": [
        """CREATE TABLE BI_API_AUDIT (
            ID               NUMBER          GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) PRIMARY KEY,
            ENDPOINT         VARCHAR2(200)   NOT NULL,
            HTTP_METHOD      VARCHAR2(10)    NOT NULL,
            USER_ID          VARCHAR2(50),
            SCORECARD_ID     VARCHAR2(100),
            STATUS_CODE      NUMBER(3,0),
            RESPONSE_TIME_MS NUMBER(8,0),
            ERROR_MESSAGE    VARCHAR2(2000),
            IP_ADDRESS       VARCHAR2(50),
            REQUEST_BODY_LEN NUMBER(10,0),
            CREATED_DT       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
            CONSTRAINT CK_BI_AUDIT_METHOD CHECK (HTTP_METHOD IN ('GET','POST','PUT','DELETE','PATCH'))
        )""",
        "CREATE INDEX IDX_BI_AUDIT_DT     ON BI_API_AUDIT (CREATED_DT)",
        "CREATE INDEX IDX_BI_AUDIT_USER   ON BI_API_AUDIT (USER_ID)",
        "CREATE INDEX IDX_BI_AUDIT_SC     ON BI_API_AUDIT (SCORECARD_ID)",
        "CREATE INDEX IDX_BI_AUDIT_STATUS ON BI_API_AUDIT (STATUS_CODE)",
        "CREATE INDEX IDX_BI_AUDIT_ENDPT  ON BI_API_AUDIT (ENDPOINT)",
    ],

    "BI_SNAPSHOT_LOG": [
        """CREATE TABLE BI_SNAPSHOT_LOG (
            ID               NUMBER          GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) PRIMARY KEY,
            VIEW_ID          VARCHAR2(200)   NOT NULL,
            SCORECARD_ID     VARCHAR2(100),
            USER_ID          VARCHAR2(50),
            FILE_TYPE        VARCHAR2(10)    NOT NULL,
            SUCCESS          CHAR(1)         DEFAULT 'Y' NOT NULL,
            CACHED           CHAR(1)         DEFAULT 'N' NOT NULL,
            ERROR_MESSAGE    VARCHAR2(500),
            FILE_SIZE_BYTES  NUMBER(12,0),
            RESPONSE_TIME_MS NUMBER(8,0),
            API_VERSION      VARCHAR2(10),
            CREATED_DT       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
            CONSTRAINT CK_BI_SNAP_TYPE    CHECK (FILE_TYPE IN ('PNG','PDF','CSV','JSON','EXCEL')),
            CONSTRAINT CK_BI_SNAP_SUCCESS CHECK (SUCCESS IN ('Y','N')),
            CONSTRAINT CK_BI_SNAP_CACHED  CHECK (CACHED IN ('Y','N'))
        )""",
        "CREATE INDEX IDX_BI_SNAP_SC   ON BI_SNAPSHOT_LOG (SCORECARD_ID)",
        "CREATE INDEX IDX_BI_SNAP_DT   ON BI_SNAPSHOT_LOG (CREATED_DT)",
        "CREATE INDEX IDX_BI_SNAP_VIEW ON BI_SNAPSHOT_LOG (VIEW_ID)",
        "CREATE INDEX IDX_BI_SNAP_TYPE ON BI_SNAPSHOT_LOG (FILE_TYPE)",
    ],

    "BI_DATA_CONTEXT": [
        """CREATE TABLE BI_DATA_CONTEXT (
            ID               NUMBER          GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1) PRIMARY KEY,
            SOURCE_ID        VARCHAR2(200)   NOT NULL,
            SOURCE_NAME      VARCHAR2(500),
            CHUNK_ID         VARCHAR2(50)    NOT NULL,
            CHUNK_TYPE       VARCHAR2(50)    NOT NULL,
            CONTENT          CLOB            NOT NULL,
            TOKEN_COUNT      NUMBER(8,0)     DEFAULT 0,
            METADATA         CLOB,
            TOTAL_ROWS       NUMBER(10,0)    DEFAULT 0,
            TOTAL_COLS       NUMBER(5,0)     DEFAULT 0,
            DASHBOARD_TYPE   VARCHAR2(50),
            VISUAL_COUNT     NUMBER(4,0)     DEFAULT 0,
            EXTRACTED_DT     TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
            EXPIRES_DT       TIMESTAMP,
            CONSTRAINT UQ_BI_CTX_CHUNK UNIQUE (SOURCE_ID, CHUNK_ID),
            CONSTRAINT CK_BI_CTX_TYPE  CHECK (CHUNK_TYPE IN ('summary','schema','stats','rows','visual','kpi','universal_schema'))
        )""",
        "CREATE INDEX IDX_BI_CTX_SOURCE  ON BI_DATA_CONTEXT (SOURCE_ID)",
        "CREATE INDEX IDX_BI_CTX_EXPIRES ON BI_DATA_CONTEXT (EXPIRES_DT)",
        "CREATE INDEX IDX_BI_CTX_TYPE    ON BI_DATA_CONTEXT (CHUNK_TYPE)",
        "CREATE INDEX IDX_BI_CTX_DTYPE   ON BI_DATA_CONTEXT (DASHBOARD_TYPE)",
        "CREATE INDEX IDX_BI_CTX_DT      ON BI_DATA_CONTEXT (EXTRACTED_DT)",
    ],
}


def _get_existing_tables(cursor) -> List[str]:
    """Query USER_TABLES to find which BI_ tables already exist."""
    placeholders = ",".join([f"'{t}'" for t in REQUIRED_TABLES])
    cursor.execute(
        f"SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME IN ({placeholders})"
    )
    return [row[0] for row in cursor.fetchall()]


def _get_existing_indexes(cursor) -> List[str]:
    """Query USER_INDEXES to find which BI_ indexes already exist."""
    cursor.execute(
        "SELECT INDEX_NAME FROM USER_INDEXES WHERE INDEX_NAME LIKE 'IDX_BI_%'"
    )
    return [row[0] for row in cursor.fetchall()]


def init_oracle_schema() -> bool:
    """
    Auto-create Oracle tables on startup. Idempotent.

    Returns True if all tables exist (created or already existed).
    Returns False if Oracle is not configured or connection fails.
    """
    if not check_oracle():
        log.info("Oracle not configured — skipping auto-DDL")
        return False

    try:
        from backend.services.oracle_service import _get_pool
        pool = _get_pool()
    except Exception as e:
        log.error(f"Oracle connection failed — cannot auto-create tables: {e}")
        return False

    try:
        with pool.acquire() as conn:
            cursor = conn.cursor()

            # ── Check existing tables ─────────────────────────────────
            existing_tables = _get_existing_tables(cursor)
            existing_indexes = _get_existing_indexes(cursor)
            missing = [t for t in REQUIRED_TABLES if t not in existing_tables]

            if not missing:
                log.info(f"Oracle auto-DDL: all {len(REQUIRED_TABLES)} tables exist ✓")
                return True

            log.info(f"Oracle auto-DDL: {len(existing_tables)} exist, {len(missing)} to create")
            log.info(f"  Missing: {missing}")

            # ── Create missing tables (in order) ─────────────────────
            for table_name in REQUIRED_TABLES:
                if table_name in existing_tables:
                    log.info(f"  │ {table_name} — already exists ✓")
                    continue

                ddl_statements = TABLE_DDL.get(table_name, [])
                if not ddl_statements:
                    log.warning(f"  │ {table_name} — no DDL found!")
                    continue

                for i, stmt in enumerate(ddl_statements):
                    try:
                        # Skip index if it already exists
                        if stmt.strip().upper().startswith("CREATE INDEX"):
                            idx_name = stmt.split()[2]
                            if idx_name in existing_indexes:
                                continue

                        cursor.execute(stmt)
                        if i == 0:
                            log.info(f"  │ {table_name} — CREATED ✓")
                    except Exception as e:
                        err_str = str(e)
                        # ORA-00955 = name already used (idempotent — skip)
                        if "ORA-00955" in err_str:
                            log.info(f"  │ {table_name} — already exists (ORA-00955) ✓")
                        else:
                            log.error(f"  │ {table_name} DDL failed: {e}")

            conn.commit()
            log.info("Oracle auto-DDL complete ✓")
            return True

    except Exception as e:
        log.error(f"Oracle auto-DDL failed: {e}")
        return False
