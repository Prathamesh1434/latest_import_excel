import pandas as pd
from typing import Dict, List, Any

def generate_visual_config(df: pd.DataFrame, schema: Dict[str, List[str]]) -> Dict[str, Any]:
    config = {
        "tabs": ["Overview", "Details"],
        "charts": []
    }
    
    if schema.get("threshold") and schema.get("rag_status"):
        config["tabs"].append("KRI Dashboard")
        
    # Check for Jira/DCRM
    jira_cols = [c for c in df.columns if 'jira' in c.lower() or 'dcrm' in c.lower()]
    if jira_cols:
        config["tabs"].append("DCRM / Concerns")
        
    # Generate RAG Distribution Bar
    if schema.get("rag_status"):
        rag_col = schema["rag_status"][0]
        dist = df[rag_col].value_counts().to_dict()
        config["charts"].append({
            "type": "stacked_bar",
            "title": "Pass Rate / RAG Distribution",
            "data": dist
        })
        
    # Trend over time
    if schema.get("date") and schema.get("rag_status"):
        config["charts"].append({
            "type": "line",
            "title": "Failures over time",
            "x": schema["date"][0],
            "y": schema["rag_status"][0] # simplified representation
        })
        
    return config
