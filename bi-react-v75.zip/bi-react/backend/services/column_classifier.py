import pandas as pd
import re
from typing import Dict, List, Any

def classify_columns(df: pd.DataFrame) -> Dict[str, List[str]]:
    """ Auto-detects column roles based on patterns and data types. """
    schema: Dict[str, List[str]] = {
        "identifier": [],
        "dimension": [],
        "measure": [],
        "threshold": [],
        "rag_status": [],
        "date": [],
        "text": [],
        "null_heavy": []
    }
    
    total_rows = len(df)
    if total_rows == 0:
        return schema
        
    for col in df.columns:
        col_lower = str(col).lower()
        col_type = df[col].dtype
        null_count = df[col].isna().sum()
        
        # 1. Null-heavy
        if null_count / total_rows > 0.8:
            schema["null_heavy"].append(col)
            continue
            
        # 2. Date
        if pd.api.types.is_datetime64_any_dtype(col_type) or 'date' in col_lower or col_lower.endswith('dt'):
            schema["date"].append(col)
            continue
            
        # 3. Identifier
        if col_lower.endswith('_id') or col_lower.endswith('_code') or col_lower in ['csi', 'rule_id']:
            schema["identifier"].append(col)
            continue
            
        # 4. Threshold
        if 'threshold' in col_lower:
            schema["threshold"].append(col)
            continue
            
        # 5. RAG status
        sample_vals = set(df[col].dropna().astype(str).str.lower().unique())
        if len(sample_vals) > 0 and sample_vals.issubset({'red', 'amber', 'green', 'dark green'}):
            schema["rag_status"].append(col)
            continue
            
        # 6. Measure (Numeric)
        if pd.api.types.is_numeric_dtype(col_type):
            schema["measure"].append(col)
            continue
            
        # 7. Text vs Dimension
        if pd.api.types.is_string_dtype(col_type):
            unique_ratio = df[col].nunique() / total_rows
            mean_length = df[col].dropna().astype(str).str.len().mean()
            
            # If length is long or almost all unique, it's text
            if mean_length > 50 or (unique_ratio > 0.5 and total_rows > 100):
                schema["text"].append(col)
            else:
                schema["dimension"].append(col)
        else:
            schema["dimension"].append(col)
            
    return schema
