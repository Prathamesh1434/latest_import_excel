"""
services/oracle_service.py (Migrated to SQLite)
Local DB — connection, chat history, audit, analytics.
"""
import sqlite3, uuid, logging, time
from typing import List, Optional, Dict
from backend.config import check_oracle

log = logging.getLogger("sqlite")
DB_PATH = "local_db.sqlite"

def _get_conn():
    if not check_oracle():
        raise RuntimeError("SQLite (Oracle override) not configured in .env")
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    return conn



# ── Sessions ──────────────────────────────────────────────────────────────────

def get_or_create_session(user_id: str, scorecard_id: str, name: str, session_id: Optional[str]=None) -> str:
    sid = session_id or str(uuid.uuid4())
    try:
        with _get_conn() as conn:
            cursor = conn.cursor()
            if session_id:
                cursor.execute(
                    "SELECT SESSION_ID FROM BI_CHAT_SESSION WHERE SESSION_ID=? AND USER_ID=? AND STATUS='ACTIVE'",
                    [session_id, user_id])
                row = cursor.fetchone()
                if row:
                    cursor.execute("UPDATE BI_CHAT_SESSION SET LAST_ACTIVE_DT=CURRENT_TIMESTAMP WHERE SESSION_ID=?", [session_id])
                    conn.commit()
                    return session_id
            cursor.execute(
                "INSERT INTO BI_CHAT_SESSION(SESSION_ID,USER_ID,SCORECARD_ID,SCORECARD_NAME,CREATED_DT,LAST_ACTIVE_DT,MESSAGE_COUNT,STATUS) VALUES(?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,0,'ACTIVE')",
                [sid, user_id, scorecard_id, name])
            conn.commit()
        return sid
    except Exception as e:
        log.error(f"get_or_create_session: {e}")
        return str(uuid.uuid4())


def save_message(session_id: str, user_id: str, scorecard_id: str,
                 role: str, content: str, model_ver="", in_tok=0, out_tok=0, resp_ms=0):
    try:
        with _get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO BI_CHAT_HISTORY(SESSION_ID,USER_ID,SCORECARD_ID,ROLE,CONTENT,MODEL_VERSION,INPUT_TOKENS,OUTPUT_TOKENS,RESPONSE_TIME_MS,CREATED_DT) VALUES(?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
                [session_id, user_id, scorecard_id, role, content, model_ver, in_tok, out_tok, resp_ms])
            cursor.execute(
                "UPDATE BI_CHAT_SESSION SET MESSAGE_COUNT=MESSAGE_COUNT+1,LAST_ACTIVE_DT=CURRENT_TIMESTAMP WHERE SESSION_ID=?",
                [session_id])
            conn.commit()
        return True
    except Exception as e:
        log.error(f"save_message: {e}")
        return False


def get_user_sessions(user_id: str, scorecard_id: Optional[str]=None, limit: int=20) -> List[Dict]:
    try:
        with _get_conn() as conn:
            cursor = conn.cursor()
            sc_clause = "AND SCORECARD_ID=?" if scorecard_id else ""
            params = [user_id] + ([scorecard_id] if scorecard_id else []) + [limit]
            cursor.execute(
                f"SELECT SESSION_ID,SCORECARD_ID,SCORECARD_NAME,MESSAGE_COUNT,CREATED_DT,LAST_ACTIVE_DT FROM BI_CHAT_SESSION WHERE USER_ID=? {sc_clause} ORDER BY LAST_ACTIVE_DT DESC LIMIT ?",
                params)
            rows = cursor.fetchall()
            return [{"session_id":r[0],"scorecard_id":r[1],"scorecard_name":r[2],"message_count":r[3],"created_dt":r[4],"last_active_dt":r[5]} for r in rows]
    except Exception as e:
        log.error(f"get_user_sessions: {e}")
        return []


def get_session_messages(session_id: str, user_id: str, limit: int=50) -> Dict:
    try:
        with _get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT SESSION_ID,SCORECARD_ID,SCORECARD_NAME,MESSAGE_COUNT,CREATED_DT,LAST_ACTIVE_DT FROM BI_CHAT_SESSION WHERE SESSION_ID=? AND USER_ID=?",
                [session_id, user_id])
            s = cursor.fetchone()
            if not s: return {}
            cursor.execute(
                "SELECT ID,ROLE,CONTENT,CREATED_DT,RESPONSE_TIME_MS FROM BI_CHAT_HISTORY WHERE SESSION_ID=? ORDER BY CREATED_DT ASC LIMIT ?",
                [session_id, limit])
            msgs = cursor.fetchall()
            return {
                "session": {"session_id":s[0],"scorecard_id":s[1],"scorecard_name":s[2],"message_count":s[3],"created_dt":s[4],"last_active_dt":s[5]},
                "messages": [{"id":r[0],"role":r[1],"content":r[2],"created_dt":r[3],"response_ms":r[4]} for r in msgs]
            }
    except Exception as e:
        log.error(f"get_session_messages: {e}")
        return {}


def get_recent_for_llm(session_id: str, limit: int=20) -> List[Dict]:
    try:
        with _get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT ROLE,CONTENT FROM (SELECT ROLE,CONTENT,CREATED_DT FROM BI_CHAT_HISTORY WHERE SESSION_ID=? AND ROLE IN ('user','assistant') ORDER BY CREATED_DT DESC LIMIT ?) ORDER BY CREATED_DT ASC",
                [session_id, limit])
            rows = cursor.fetchall()
            return [{"role":r[0],"content":r[1]} for r in rows]
    except Exception as e:
        log.error(f"get_recent_for_llm: {e}")
        return []


# ── Audit ─────────────────────────────────────────────────────────────────────

def log_api(endpoint: str, method: str, user_id="", scorecard_id="",
            status=200, resp_ms=0, error="", ip=""):
    try:
        with _get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO BI_API_AUDIT(ENDPOINT,HTTP_METHOD,USER_ID,SCORECARD_ID,STATUS_CODE,RESPONSE_TIME_MS,ERROR_MESSAGE,IP_ADDRESS,CREATED_DT) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
                [endpoint, method, user_id, scorecard_id, status, resp_ms, error[:2000], ip])
            conn.commit()
    except Exception as e:
        log.warning(f"log_api failed (non-critical): {e}")


def log_snapshot(view_id: str, scorecard_id: str, user_id: str,
                 ftype: str, success: bool, error="", size=0, ms=0):
    try:
        with _get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO BI_SNAPSHOT_LOG(VIEW_ID,SCORECARD_ID,USER_ID,FILE_TYPE,SUCCESS,ERROR_MESSAGE,FILE_SIZE_BYTES,RESPONSE_TIME_MS,CREATED_DT) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
                [view_id, scorecard_id, user_id, ftype, 'Y' if success else 'N', error[:500], size, ms])
            conn.commit()
    except Exception as e:
        log.warning(f"log_snapshot failed (non-critical): {e}")


# ── Analytics ─────────────────────────────────────────────────────────────────

def get_analytics(days: int=30) -> Dict:
    try:
        with _get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute(
                f"SELECT COUNT(DISTINCT s.SESSION_ID),COUNT(h.ID),COUNT(DISTINCT s.USER_ID),AVG(h.RESPONSE_TIME_MS) FROM BI_CHAT_SESSION s LEFT JOIN BI_CHAT_HISTORY h ON s.SESSION_ID=h.SESSION_ID WHERE s.CREATED_DT>=date('now', '-{days} days')")
            summ = cursor.fetchone() or (0,0,0,None)
            
            cursor.execute(
                f"SELECT s.SCORECARD_ID,COUNT(DISTINCT s.SESSION_ID),COUNT(h.ID),COUNT(DISTINCT s.USER_ID),AVG(h.RESPONSE_TIME_MS) FROM BI_CHAT_SESSION s LEFT JOIN BI_CHAT_HISTORY h ON s.SESSION_ID=h.SESSION_ID WHERE s.CREATED_DT>=date('now', '-{days} days') GROUP BY s.SCORECARD_ID ORDER BY 2 DESC")
            by_sc = cursor.fetchall() or []
            
        return {
            "total_sessions": summ[0] or 0,
            "total_messages": summ[1] or 0,
            "unique_users":   summ[2] or 0,
            "avg_response_ms":round(summ[3],1) if summ[3] else None,
            "most_queried":   by_sc[0][0] if by_sc else None,
            "by_scorecard":   [{"scorecard_id":r[0],"sessions":r[1]or 0,"messages":r[2]or 0,"users":r[3]or 0,"avg_ms":round(r[4],1) if r[4] else None} for r in by_sc],
        }
    except Exception as e:
        log.error(f"get_analytics: {e}")
        return {"error": str(e)}


def ping() -> bool:
    try:
        with _get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
        return True
    except:
        return False
