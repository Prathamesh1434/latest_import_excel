"""
services/query_engine.py -- v7.2

Full 3-tier query routing engine:
  Tier 1 (DIRECT/PANDAS)  -- $0, <50ms  -- pattern-match + pandas ops
  Tier 2 (SEMANTIC/TF-IDF) -- $0, <100ms -- cosine similarity on indexed docs
  Tier 3 (LLM/GEMINI)     -- ~$0.002, 1-3s -- Vertex AI with T1+T2 context

Enhancements in v7.2:
  - Fuzzy column name matching (difflib)
  - Sheet-aware routing (solo/conso/cgme pivot sheets)
  - T2->T3 pipeline: semantic results formatted by LLM
  - Empty chart guard: never return chart with no data
  - Proper list/unique value queries routed to T1
  - Month-aware queries
"""
import time
import re
import json
import difflib
import logging
import pandas as pd
from typing import Dict, Any, List, Optional, Tuple

log = logging.getLogger("query_engine")


# ============================================================
# FUZZY COLUMN MATCHING
# ============================================================

def _fuzzy_match_column(user_ref: str, columns: List[str], threshold: float = 0.5) -> Optional[str]:
    """
    Match a user's column reference to an actual column name.
    Tries: exact, case-insensitive, underscore-replaced, substring, then difflib fuzzy.
    """
    ref = user_ref.lower().strip()

    # 1. Exact match (case-insensitive)
    for col in columns:
        if col.lower() == ref:
            return col

    # 2. Underscore/space normalization
    ref_norm = ref.replace("_", " ").replace("-", " ")
    for col in columns:
        col_norm = col.lower().replace("_", " ").replace("-", " ")
        if col_norm == ref_norm:
            return col

    # 3. Substring match (user says "rule_names" matches "source_system_rule_name")
    for col in columns:
        col_lower = col.lower()
        if ref in col_lower or ref_norm in col_lower.replace("_", " "):
            return col

    # 4. Reverse substring (column name contained in user ref)
    for col in columns:
        col_norm = col.lower().replace("_", " ")
        if col_norm in ref_norm and len(col_norm) > 3:
            return col

    # 5. difflib fuzzy matching
    matches = difflib.get_close_matches(ref, [c.lower() for c in columns], n=1, cutoff=threshold)
    if matches:
        for col in columns:
            if col.lower() == matches[0]:
                return col

    # 6. Word overlap
    ref_words = set(ref_norm.split())
    best_col = None
    best_overlap = 0
    for col in columns:
        col_words = set(col.lower().replace("_", " ").split())
        overlap = len(ref_words & col_words)
        if overlap > best_overlap and overlap >= 1:
            best_overlap = overlap
            best_col = col
    if best_col and best_overlap >= 1:
        return best_col

    return None


def _extract_column_ref(question: str, columns: List[str]) -> Optional[str]:
    """Find a column name referenced in the question using fuzzy matching."""
    q = question.lower()

    # Try direct column name references
    for col in columns:
        if col.lower() in q or col.lower().replace("_", " ") in q:
            return col

    # Extract potential column references from question
    patterns = [
        r"(?:all|the|show|list|give|get|display)\s+(?:me\s+)?(?:the\s+)?(?:all\s+)?(?:unique\s+)?(.+?)$",
        r"(?:all|the|show|list|give|get|display)\s+(?:me\s+)?(?:the\s+)?(?:all\s+)?(?:unique\s+)?(.+?)\s+(?:are|in|from|for|of|that|which|please)",
        r"(?:distribution|breakdown|split|values)\s+(?:of|for|in)\s+(.+?)(?:\s|$)",
        r"(?:count|number|total)\s+(?:of|for)\s+(.+?)(?:\s|$)",
        r"(?:top|bottom|max|min|highest|lowest)\s+\d*\s*(.+?)(?:\s|$)",
    ]

    for pattern in patterns:
        match = re.search(pattern, q)
        if match:
            ref = match.group(1).strip().rstrip("s").strip("?.,!")
            if len(ref) > 1:
                col = _fuzzy_match_column(ref, columns)
                if col:
                    return col

    # Fallback: try fuzzy matching content words, preferring longer matches
    words = re.findall(r"[a-z_]+", q)
    stop_words = {"the", "a", "an", "is", "are", "in", "of", "for", "all", "me",
                  "give", "show", "list", "get", "what", "how", "many", "please",
                  "can", "you", "i", "do", "does", "it", "this", "that"}
    content_words = [w for w in words if w not in stop_words and len(w) > 2]

    # Try pairs first (more specific)
    for i in range(len(content_words) - 1):
        ref = content_words[i] + "_" + content_words[i + 1]
        col = _fuzzy_match_column(ref, columns)
        if col:
            return col

    # Then singles
    for w in content_words:
        col = _fuzzy_match_column(w, columns)
        if col:
            return col

    return None


def _extract_value_ref(question: str, df: pd.DataFrame, col: str) -> Optional[str]:
    """Find a specific value from a column referenced in the question."""
    q = question.lower()
    try:
        uniques = df[col].dropna().unique()
        for val in uniques:
            if str(val).lower() in q:
                return str(val)
    except Exception:
        pass
    return None


# ============================================================
# SHEET-AWARE ROUTING
# ============================================================

SHEET_KEYWORDS = {
    "pivot_solo": ["solo", "individual", "single entity", "solo report"],
    "pivot_conso": ["conso", "consolidated", "combined", "merged", "group report"],
    "pivot_cgme": ["cgme", "cgm-e", "cgm e"],
    "pivot_cgml": ["cgml", "cgm-l", "cgm l"],
    "pivot_cgmfl": ["cgmfl", "cgm-fl"],
}


def _detect_target_sheet(question: str, available_sheets: Dict[str, Any]) -> Optional[str]:
    """Detect which sheet the user is referring to based on question keywords."""
    q = question.lower()

    for sheet_key, keywords in SHEET_KEYWORDS.items():
        if sheet_key in available_sheets:
            for kw in keywords:
                if kw in q:
                    return sheet_key

    return None


def _detect_sheet_comparison(question: str, available_sheets: Dict[str, Any]) -> Optional[Tuple[str, str]]:
    """Detect if user wants to compare two sheets (e.g., 'compare solo vs consolidated')."""
    q = question.lower()
    if not any(w in q for w in ["compare", "vs", "versus", "difference", "differ"]):
        return None

    found = []
    for sheet_key, keywords in SHEET_KEYWORDS.items():
        if sheet_key in available_sheets:
            for kw in keywords:
                if kw in q:
                    found.append(sheet_key)
                    break

    if len(found) >= 2:
        return (found[0], found[1])
    return None


# ============================================================
# MONTH-AWARE ROUTING
# ============================================================

MONTH_KEYWORDS = [
    "month on month", "month over month", "mom", "compare months",
    "trend", "what changed", "delta", "previous month", "last month",
    "monthly comparison", "month comparison",
]


def _detect_month_query(question: str) -> bool:
    """Check if question is about month-over-month comparison."""
    q = question.lower()
    return any(kw in q for kw in MONTH_KEYWORDS)


def _handle_month_query(question: str, scorecard: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Handle month-related queries."""
    months = scorecard.get("months", {})
    t0 = time.time()

    if not months or len(months) < 1:
        # Check if we have period data from the old system
        periods = scorecard.get("periods", {})
        if not periods:
            display = scorecard.get("display_name", "this scorecard")
            return {
                "tier": 1, "tier_label": "DIRECT",
                "reply": f"Only the current month's data is available for {display}. Upload another month's data using the 'MoM Compare' tab to enable month-over-month comparison.",
                "table_data": None, "chart": None,
                "confidence": 0.90, "latency_ms": int((time.time() - t0) * 1000),
                "data_source": "pandas", "model_used": "pandas",
            }

    if len(months) == 1:
        month_label = list(months.keys())[0]
        return {
            "tier": 1, "tier_label": "DIRECT",
            "reply": f"Only data for **{month_label}** is available. Upload another month's data to enable comparison.",
            "table_data": None, "chart": None,
            "confidence": 0.85, "latency_ms": int((time.time() - t0) * 1000),
            "data_source": "pandas", "model_used": "pandas",
        }

    # Multiple months available -- provide summary
    month_labels = sorted(months.keys())
    parts = [f"**{len(month_labels)} months** of data available: {', '.join(month_labels)}\n"]

    from backend.services.data_service import calculate_kri

    schema = scorecard.get("schema", {})
    for ml in month_labels:
        md = months[ml]
        mdf = md.get("df")
        if mdf is not None:
            kri = calculate_kri(mdf, schema)
            total = kri.get("total", len(mdf))
            failed = kri.get("failed", 0)
            rate = ((total - failed) / total * 100) if total > 0 else 0
            parts.append(f"- **{ml}**: {len(mdf)} rows, {failed} failures, {rate:.1f}% pass rate")

    reply = "\n".join(parts)
    reply += "\n\nUse the **MoM Compare** tab to see detailed comparison charts and status flips."

    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": None, "chart": None,
        "confidence": 0.90, "latency_ms": int((time.time() - t0) * 1000),
        "data_source": "pandas", "model_used": "pandas",
    }


# ============================================================
# TIER 1: PANDAS DIRECT
# ============================================================

T1_KEYWORDS = {
    "list": ["give me", "list", "show me", "show all", "display", "what are", "get all", "get me"],
    "count": ["how many", "count", "total", "number of"],
    "filter": ["filter", "where", "which"],
    "rank": ["top", "bottom", "highest", "lowest", "max", "min", "best", "worst"],
    "aggregate": ["sum", "average", "mean", "avg", "group by", "group", "aggregate"],
    "distribution": ["distribution", "breakdown", "split", "rag status", "pass rate", "status breakdown"],
}


def _detect_t1_intent(question: str) -> Optional[str]:
    """Detect if the question can be answered by pandas. Returns intent or None."""
    q = question.lower().strip()
    for intent, keywords in T1_KEYWORDS.items():
        for kw in keywords:
            if kw in q:
                return intent
    return None


def try_pandas_query(question: str, df: pd.DataFrame, schema: Dict, sheets: Dict = None) -> Optional[Dict[str, Any]]:
    """
    Attempt to answer the question using pandas operations.
    Returns result dict with reply, data, confidence -- or None if cannot answer.
    """
    if df is None or df.empty:
        return None

    t0 = time.time()
    q = question.lower().strip()

    # Check for sheet-specific queries first
    if sheets:
        target_sheet = _detect_target_sheet(question, sheets)
        if target_sheet and target_sheet in sheets:
            target_df = sheets[target_sheet]
            if isinstance(target_df, pd.DataFrame) and not target_df.empty:
                return _query_pivot_sheet(question, target_df, target_sheet, t0)

        # Check for sheet comparison
        pair = _detect_sheet_comparison(question, sheets)
        if pair:
            return _compare_sheets(question, sheets, pair, t0)

    intent = _detect_t1_intent(question)
    if intent is None:
        return None

    columns = list(df.columns)
    rag_cols = schema.get("rag_status", [])
    id_cols = schema.get("identifier", [])
    dim_cols = schema.get("dimension", [])
    measure_cols = schema.get("measure", [])

    reply = ""
    table_data = None
    chart = None
    confidence = 0.85

    try:
        # -- LIST / SHOW ALL queries --
        if intent == "list":
            col_ref = _extract_column_ref(question, columns)
            if col_ref:
                unique_vals = df[col_ref].dropna().unique().tolist()
                unique_vals = [str(v) for v in unique_vals if str(v).strip()]
                count = len(unique_vals)

                if count <= 20:
                    items = "\n".join(f"{i+1}. {v}" for i, v in enumerate(unique_vals))
                    reply = f"**{count} unique values in '{col_ref}':**\n\n{items}"
                else:
                    shown = "\n".join(f"{i+1}. {v}" for i, v in enumerate(unique_vals[:20]))
                    reply = f"**{count} unique values in '{col_ref}'** (showing first 20):\n\n{shown}\n\n...and {count - 20} more."

                confidence = 0.95
            elif any(w in q for w in ["fail", "red", "breach"]) and rag_cols:
                rag_col = rag_cols[0]
                fails = df[df[rag_col].str.lower() == "red"]
                reply = f"Found **{len(fails)}** failing (Red) records."
                table_data = fails.head(20).fillna("").to_dict(orient="records")
                confidence = 0.92
            elif any(w in q for w in ["column", "columns", "fields", "field"]):
                items = "\n".join(f"{i+1}. {c}" for i, c in enumerate(columns))
                reply = f"**{len(columns)} columns:**\n\n{items}"
                confidence = 0.95
            else:
                return None

        # -- COUNT queries --
        elif intent == "count":
            if any(w in q for w in ["fail", "red", "breach"]):
                if rag_cols:
                    rag_col = rag_cols[0]
                    fail_count = len(df[df[rag_col].str.lower().isin(["red"])])
                    total = len(df)
                    reply = f"There are **{fail_count:,}** failed (Red) records out of **{total:,}** total records."
                    confidence = 0.95
                else:
                    return None
            elif any(w in q for w in ["pass", "green", "dark green"]):
                if rag_cols:
                    rag_col = rag_cols[0]
                    pass_count = len(df[df[rag_col].str.lower().isin(["green", "dark green"])])
                    total = len(df)
                    reply = f"There are **{pass_count:,}** passing (Green/Dark Green) records out of **{total:,}** total."
                    confidence = 0.95
                else:
                    return None
            else:
                col_ref = _extract_column_ref(question, columns)
                if col_ref:
                    unique_count = df[col_ref].nunique()
                    reply = f"There are **{unique_count:,}** unique values in '{col_ref}'."
                    confidence = 0.90
                else:
                    reply = f"The dataset contains **{len(df):,}** total records across **{len(columns)}** columns."
                    confidence = 0.80

        # -- FILTER queries --
        elif intent == "filter":
            col_ref = _extract_column_ref(question, columns)
            if col_ref:
                val_ref = _extract_value_ref(question, df, col_ref)
                if val_ref:
                    filtered = df[df[col_ref].astype(str).str.lower() == val_ref.lower()]
                    reply = f"Found **{len(filtered):,}** records where '{col_ref}' = '{val_ref}'."
                    table_data = filtered.head(20).fillna("").to_dict(orient="records")
                    confidence = 0.92
                else:
                    vals = df[col_ref].value_counts().head(10).to_dict()
                    reply = f"Top values in '{col_ref}':\n" + "\n".join(f"- **{k}**: {v:,}" for k, v in vals.items())
                    confidence = 0.85
            elif any(w in q for w in ["fail", "red"]) and rag_cols:
                rag_col = rag_cols[0]
                fails = df[df[rag_col].str.lower() == "red"]
                reply = f"Found **{len(fails):,}** failing (Red) records."
                table_data = fails.head(20).fillna("").to_dict(orient="records")
                confidence = 0.90
            else:
                return None

        # -- RANK queries --
        elif intent == "rank":
            col_ref = _extract_column_ref(question, measure_cols + columns)
            if col_ref and pd.api.types.is_numeric_dtype(df[col_ref]):
                is_top = any(w in q for w in ["top", "highest", "max", "best"])
                n = 5
                nums = re.findall(r"\d+", question)
                if nums:
                    n = min(int(nums[0]), 20)
                sorted_df = df.sort_values(col_ref, ascending=not is_top).head(n)
                direction = "highest" if is_top else "lowest"
                reply = f"**{direction.capitalize()} {n}** records by '{col_ref}':"
                table_data = sorted_df.fillna("").to_dict(orient="records")
                confidence = 0.90
            else:
                return None

        # -- AGGREGATE queries --
        elif intent == "aggregate":
            col_ref = _extract_column_ref(question, measure_cols)
            group_col = _extract_column_ref(question, dim_cols)
            if col_ref and group_col:
                if "sum" in q:
                    agg = df.groupby(group_col)[col_ref].sum().reset_index()
                elif any(w in q for w in ["average", "mean", "avg"]):
                    agg = df.groupby(group_col)[col_ref].mean().reset_index()
                else:
                    agg = df.groupby(group_col)[col_ref].sum().reset_index()
                reply = f"Aggregation of '{col_ref}' grouped by '{group_col}':"
                table_data = agg.head(20).to_dict(orient="records")

                # Build chart only if we have data
                if len(agg) > 0:
                    labels = agg[group_col].astype(str).tolist()[:15]
                    values = [round(float(v), 2) for v in agg[col_ref].head(15)]
                    chart = _build_chart("bar", f"{'Sum' if 'sum' in q else 'Average'} of {col_ref} by {group_col}", labels, values)

                confidence = 0.88
            elif col_ref:
                total = df[col_ref].sum()
                avg = df[col_ref].mean()
                reply = f"'{col_ref}': Sum = **{total:,.2f}**, Average = **{avg:,.2f}**, Count = **{df[col_ref].count():,}**"
                confidence = 0.85
            else:
                return None

        # -- DISTRIBUTION queries --
        elif intent == "distribution":
            if rag_cols and any(w in q for w in ["rag", "status", "pass", "fail", "distribution", "breakdown"]):
                rag_col = rag_cols[0]
                dist = df[rag_col].value_counts().to_dict()
                total = sum(dist.values())
                reply = "**RAG Status Distribution:**\n" + "\n".join(
                    f"- {k}: **{v:,}** ({v/total*100:.1f}%)" for k, v in dist.items()
                )
                # Build chart
                labels = list(dist.keys())
                values = list(dist.values())
                if labels:
                    chart = _build_rag_chart(labels, values)
                confidence = 0.95
            else:
                col_ref = _extract_column_ref(question, dim_cols + columns)
                if col_ref:
                    dist = df[col_ref].value_counts().head(15).to_dict()
                    reply = f"**Distribution of '{col_ref}':**\n" + "\n".join(
                        f"- {k}: **{v:,}**" for k, v in dist.items()
                    )
                    labels = list(dist.keys())
                    values = list(dist.values())
                    if labels:
                        chart = _build_chart("bar", f"Distribution of {col_ref}", [str(l) for l in labels], values)
                    confidence = 0.85
                else:
                    return None

        else:
            return None

        ms = int((time.time() - t0) * 1000)
        log.info(f"T1 PANDAS: intent={intent}, conf={confidence:.2f}, {ms}ms")

        return {
            "tier": 1,
            "tier_label": "DIRECT",
            "reply": reply,
            "table_data": table_data,
            "chart": chart,
            "confidence": confidence,
            "latency_ms": ms,
            "data_source": f"pandas ({len(df):,} rows)",
            "model_used": "pandas",
        }

    except Exception as e:
        log.warning(f"T1 pandas query failed: {e}")
        return None


def _query_pivot_sheet(question: str, df: pd.DataFrame, sheet_name: str, t0: float) -> Dict[str, Any]:
    """Query a specific pivot sheet and format nicely."""
    label = sheet_name.replace("pivot_", "").replace("_", " ").title()

    # Build a clean summary table
    table_data = df.head(30).fillna("").to_dict(orient="records")

    # Try to build a chart from the pivot
    chart = None
    if len(df.columns) >= 2:
        first_col = df.columns[0]
        numeric_cols = [c for c in df.columns[1:] if pd.api.types.is_numeric_dtype(df[c])]
        if numeric_cols and len(df) > 0:
            labels = df[first_col].astype(str).tolist()[:15]
            datasets = []
            COLORS = ["#003B6F", "#C8102E", "#047857", "#D97706", "#6D28D9", "#0891B2"]
            for i, nc in enumerate(numeric_cols[:6]):
                datasets.append({
                    "label": str(nc),
                    "data": [round(float(v), 2) if pd.notna(v) else 0 for v in df[nc].head(15)],
                    "color": COLORS[i % len(COLORS)],
                })
            chart = {
                "chart_type": "bar",
                "title": f"{label} Pivot Data",
                "labels": labels,
                "datasets": datasets,
            }

    reply = f"**{label} Pivot** ({len(df)} rows, {len(df.columns)} columns):"
    ms = int((time.time() - t0) * 1000)

    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": table_data,
        "chart": chart,
        "confidence": 0.92,
        "latency_ms": ms,
        "data_source": f"Sheet: {sheet_name} ({len(df)} rows)",
        "model_used": "pandas",
    }


def _compare_sheets(question: str, sheets: Dict, pair: Tuple[str, str], t0: float) -> Dict[str, Any]:
    """Compare two pivot sheets side by side."""
    name_a, name_b = pair
    df_a = sheets[name_a]
    df_b = sheets[name_b]
    label_a = name_a.replace("pivot_", "").replace("_", " ").title()
    label_b = name_b.replace("pivot_", "").replace("_", " ").title()

    reply = f"**Comparison: {label_a} vs {label_b}**\n\n"
    reply += f"- {label_a}: {len(df_a)} rows, {len(df_a.columns)} columns\n"
    reply += f"- {label_b}: {len(df_b)} rows, {len(df_b.columns)} columns\n"

    # Compare common numeric columns
    common_cols = [c for c in df_a.columns if c in df_b.columns and pd.api.types.is_numeric_dtype(df_a[c])]
    if common_cols:
        reply += "\n**Numeric column comparison:**\n"
        for col in common_cols[:5]:
            sum_a = df_a[col].sum()
            sum_b = df_b[col].sum()
            delta = sum_b - sum_a
            reply += f"- {col}: {label_a}={sum_a:,.0f}, {label_b}={sum_b:,.0f} (delta: {delta:+,.0f})\n"

    ms = int((time.time() - t0) * 1000)
    return {
        "tier": 1, "tier_label": "DIRECT",
        "reply": reply,
        "table_data": None, "chart": None,
        "confidence": 0.88,
        "latency_ms": ms,
        "data_source": f"Sheets: {name_a} vs {name_b}",
        "model_used": "pandas",
    }


# ============================================================
# CHART BUILDERS (with empty guard)
# ============================================================

CITI_COLORS = ["#003B6F", "#0057A8", "#C8102E", "#047857", "#D97706", "#6D28D9", "#0891B2", "#BE185D"]
RAG_COLORS = {
    "red": "#C8102E", "amber": "#D97706", "green": "#047857",
    "dark green": "#065F46", "dark_green": "#065F46",
}


def _build_chart(chart_type: str, title: str, labels: List, values: List, color: str = None) -> Optional[Dict]:
    """Build a chart dict, returning None if data is empty."""
    if not labels or not values or all(v == 0 for v in values):
        return None
    return {
        "chart_type": chart_type,
        "title": title,
        "labels": [str(l) for l in labels],
        "datasets": [{
            "label": title,
            "data": [round(float(v), 2) if v is not None else 0 for v in values],
            "color": color or CITI_COLORS[0],
        }],
    }


def _build_rag_chart(labels: List[str], values: List[int]) -> Optional[Dict]:
    """Build a RAG distribution chart with proper colors."""
    if not labels or not values:
        return None

    colors = []
    for label in labels:
        lbl = str(label).lower().strip()
        colors.append(RAG_COLORS.get(lbl, "#6B7280"))

    return {
        "chart_type": "doughnut",
        "title": "RAG Status Distribution",
        "labels": [str(l) for l in labels],
        "data": values,
        "colors": colors,
    }


# ============================================================
# TIER 2: SEMANTIC SEARCH
# ============================================================

T2_KEYWORDS = [
    "what is", "how does", "explain", "process", "architecture",
    "steps", "logic", "formula", "calculation", "workflow",
    "module", "define", "definition", "document", "policy",
    "procedure", "guideline", "standard", "requirement",
    "describe", "overview", "methodology", "approach",
]


def _detect_t2_intent(question: str) -> bool:
    """Check if question looks like a documentation/semantic query."""
    q = question.lower()
    return any(kw in q for kw in T2_KEYWORDS)


def try_semantic_search(question: str, scorecard: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Attempt to answer using TF-IDF indexed documents.
    Returns raw chunks for further processing (T2->T3 pipeline).
    """
    from backend.services.document_service import search_documents

    vectorizer = scorecard.get("doc_index")
    chunks = scorecard.get("doc_chunks", [])

    if not vectorizer or not chunks:
        return None

    t0 = time.time()

    results = search_documents(question, vectorizer, chunks)

    if not results or results[0].get("score", 0) < 0.08:
        return None

    ms = int((time.time() - t0) * 1000)
    top_score = results[0]["score"]
    confidence = min(top_score + 0.3, 0.95)

    log.info(f"T2 SEMANTIC: top_score={top_score:.3f}, conf={confidence:.2f}, {ms}ms, {len(results)} results")

    return {
        "tier": 2,
        "tier_label": "SEMANTIC",
        "raw_chunks": results[:5],
        "confidence": confidence,
        "latency_ms": ms,
        "data_source": f"TF-IDF ({len(chunks)} chunks)",
        "model_used": "scikit-learn TfidfVectorizer",
    }


def _format_t2_through_t3(question: str, t2_result: Dict, scorecard: Dict) -> Dict[str, Any]:
    """
    Pass T2 semantic results through T3 (Gemini) for clean formatting.
    Falls back to local formatting if Gemini is unavailable.
    """
    chunks = t2_result.get("raw_chunks", [])
    t0 = time.time()

    # Build context from chunks
    chunk_texts = []
    sources = []
    for c in chunks:
        chunk_texts.append(c.get("content", ""))
        src = f"{c.get('doc_name', 'Unknown')} (Section: {c.get('section', 'N/A')})"
        if src not in sources:
            sources.append(src)

    context = "\n\n---\n\n".join(chunk_texts)

    # Try T3 formatting
    try:
        from backend.services.vertex_service import chat as vertex_chat

        system_prompt = f"""You are a professional data analyst for an enterprise intelligence platform.
Based on the following document excerpts, provide a clear, structured answer to the user's question.

FORMAT RULES:
- No raw markdown artifacts, no table separators like | --- |, no section headers from the source
- If the documents describe architecture, present as a numbered flow
- If they contain tables, present key data as clean bullet points or a formatted HTML table
- Use clean HTML formatting: <strong>, <br>, <ol>/<li>, <table>
- Numbers with commas (1,000 not 1000), percentages with 2 decimal places
- Go straight to the answer, no preamble like "Based on the documents..."
- Keep response concise and professional

User question: {question}

Document context:
{context}"""

        reply, chart, in_tok, out_tok, resp_ms = vertex_chat(
            system_prompt,
            messages=[{"role": "user", "content": question}]
        )
        ms = int((time.time() - t0) * 1000)

        # Append source attribution
        source_line = "<br><br><small style='color:#6B7280'>Sources: " + ", ".join(sources) + "</small>"
        reply = reply + source_line

        log.info(f"T2+T3: formatted semantic results via Gemini, {ms}ms")

        return {
            "tier": 2,
            "tier_label": "SEMANTIC+LLM",
            "reply": reply,
            "table_data": None,
            "chart": chart if _validate_chart(chart) else None,
            "confidence": t2_result["confidence"],
            "latency_ms": ms,
            "data_source": t2_result["data_source"],
            "model_used": "TF-IDF + Gemini",
        }

    except Exception as e:
        log.info(f"T2+T3 fallback: Gemini unavailable ({e}), using local formatting")
        return _format_t2_locally(question, chunks, sources, t2_result, t0)


def _format_t2_locally(question: str, chunks: List, sources: List, t2_result: Dict, t0: float) -> Dict[str, Any]:
    """Format T2 results locally when Gemini is unavailable. Clean up raw text."""
    reply_parts = []
    for i, chunk in enumerate(chunks[:3], 1):
        content = chunk.get("content", "")
        # Clean up raw markdown/table artifacts
        content = re.sub(r'\|\s*---\s*\|', '', content)
        content = re.sub(r'\|', ' ', content)
        content = re.sub(r'#{1,3}\s+', '', content)
        content = re.sub(r'\*\*', '', content)
        content = re.sub(r'\n{3,}', '\n\n', content)
        content = content.strip()

        if content:
            # Truncate long chunks
            if len(content) > 400:
                content = content[:400] + "..."
            reply_parts.append(content)

    reply = "\n\n".join(reply_parts)

    # Append sources
    reply += "\n\n---\nSources: " + ", ".join(sources)

    ms = int((time.time() - t0) * 1000)

    return {
        "tier": 2,
        "tier_label": "SEMANTIC",
        "reply": reply,
        "table_data": None,
        "chart": None,
        "confidence": t2_result["confidence"],
        "latency_ms": ms,
        "data_source": t2_result["data_source"],
        "model_used": "scikit-learn TfidfVectorizer",
    }


def _validate_chart(chart: Optional[Dict]) -> bool:
    """Validate that a chart has actual data. Returns False for empty charts."""
    if not chart:
        return False
    if chart.get("datasets"):
        for ds in chart["datasets"]:
            data = ds.get("data", [])
            if data and any(v != 0 and v is not None for v in data):
                return True
    if chart.get("data"):
        return any(v != 0 and v is not None for v in chart["data"])
    if chart.get("labels") and not chart.get("datasets") and not chart.get("data"):
        return False
    return False


# ============================================================
# TIER 3: LLM (GEMINI)
# ============================================================

def try_llm_query(question: str, scorecard: Dict[str, Any],
                  t1_context: Optional[str] = None, t2_context: Optional[str] = None,
                  chat_context: Optional[str] = None) -> Dict[str, Any]:
    """
    Call Vertex AI Gemini with context from T1, T2, and chat history.
    Always returns a result (this is the fallback tier).
    """
    from backend.services.vertex_service import chat as vertex_chat

    df = scorecard.get("df")
    schema = scorecard.get("schema", {})

    t0 = time.time()

    # Build context
    preview = ""
    if df is not None:
        preview = df.head(5).to_csv(index=False)

    context_parts = [f"Data Schema: {json.dumps(schema)}"]
    context_parts.append(f"Data Preview (first 5 rows):\n{preview}")

    if t1_context:
        context_parts.append(f"Pandas Analysis Result:\n{t1_context}")
    if t2_context:
        context_parts.append(f"Relevant Documentation:\n{t2_context}")
    if chat_context:
        context_parts.append(f"Previous Conversations:\n{chat_context}")

    system_prompt = f"""You are an AI assistant for the B&I CDE Intelligence Platform at Citi.
You answer questions about data quality scorecards, KRIs, and CDE exception reports.

FORMAT RULES:
- Use clean HTML: <strong>, <br>, <table>, <ol>/<li>. No raw markdown.
- Numbers with commas (1,000). Percentages with % and 2 decimal places.
- Go straight to the answer, no preamble.
- If generating a chart, ensure it has actual data labels and values.
- Keep responses concise and professional.

{chr(10).join(context_parts)}

User Question: {question}"""

    try:
        reply, chart, in_tok, out_tok, resp_ms = vertex_chat(
            system_prompt,
            messages=[{"role": "user", "content": question}]
        )
        ms = int((time.time() - t0) * 1000)

        # Validate chart -- never return empty
        if not _validate_chart(chart):
            chart = None

        log.info(f"T3 GEMINI: in={in_tok} out={out_tok}, {ms}ms")

        return {
            "tier": 3,
            "tier_label": "LLM",
            "reply": reply,
            "table_data": None,
            "chart": chart,
            "confidence": 0.75,
            "latency_ms": ms,
            "data_source": f"Vertex AI Gemini (in={in_tok}, out={out_tok})",
            "model_used": "gemini-1.5-pro",
        }

    except Exception as e:
        ms = int((time.time() - t0) * 1000)
        log.error(f"T3 Gemini failed: {e}")
        return {
            "tier": 3,
            "tier_label": "LLM",
            "reply": f"Gemini AI is not available: {str(e)}. Please ensure vertex_util.py is configured with COIN auth.",
            "table_data": None,
            "chart": None,
            "confidence": 0.0,
            "latency_ms": ms,
            "data_source": "Vertex AI (unavailable)",
            "model_used": "gemini-1.5-pro (offline)",
        }


# ============================================================
# MAIN ROUTER
# ============================================================

def query_scorecard(scorecard: Dict[str, Any], question: str, mode: str = "auto",
                    chat_context: Optional[str] = None) -> Dict[str, Any]:
    """
    Route a question through the 3-tier engine.

    mode: 'auto' | 't1' | 't2' | 't3'
    - auto: tries T1 -> T2 -> T3
    - t1/t2/t3: forces that specific tier
    """
    df = scorecard.get("df")
    schema = scorecard.get("schema", {})
    sheets = scorecard.get("sheets", {})

    # Check for month queries first (any mode)
    if _detect_month_query(question):
        month_result = _handle_month_query(question, scorecard)
        if month_result:
            return month_result

    # -- Forced mode --
    if mode == "t1":
        result = try_pandas_query(question, df, schema, sheets)
        if result:
            return result
        return {
            "tier": 1, "tier_label": "DIRECT",
            "reply": "Could not answer this question using pandas. Try AUTO mode for better results.",
            "table_data": None, "chart": None,
            "confidence": 0.0, "latency_ms": 0,
            "data_source": "pandas", "model_used": "pandas",
        }

    if mode == "t2":
        result = try_semantic_search(question, scorecard)
        if result:
            return _format_t2_through_t3(question, result, scorecard)
        return {
            "tier": 2, "tier_label": "SEMANTIC",
            "reply": "No relevant documents found. Upload documentation files when onboarding for semantic search.",
            "table_data": None, "chart": None,
            "confidence": 0.0, "latency_ms": 0,
            "data_source": "TF-IDF", "model_used": "scikit-learn",
        }

    if mode == "t3":
        return try_llm_query(question, scorecard, chat_context=chat_context)

    # -- AUTO mode: T1 -> T2 -> T3 --
    # Try Tier 1 first
    t1_result = try_pandas_query(question, df, schema, sheets)
    if t1_result and t1_result["confidence"] > 0.7:
        log.info("AUTO: routed to T1 (pandas)")
        return t1_result

    # Try Tier 2
    if _detect_t2_intent(question):
        t2_result = try_semantic_search(question, scorecard)
        if t2_result and t2_result["confidence"] > 0.3:
            log.info("AUTO: routed to T2+T3 (semantic + LLM formatting)")
            return _format_t2_through_t3(question, t2_result, scorecard)

    # Fall back to Tier 3 with all available context
    t1_context = t1_result["reply"] if t1_result else None
    t2_result = try_semantic_search(question, scorecard)
    t2_context = None
    if t2_result:
        raw = t2_result.get("raw_chunks", [])
        t2_context = "\n".join(c.get("content", "")[:300] for c in raw[:3])

    log.info("AUTO: routed to T3 (Gemini)")
    return try_llm_query(question, scorecard, t1_context, t2_context, chat_context=chat_context)
