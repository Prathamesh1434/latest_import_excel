"""
routers/onboard.py -- v7.2

Multi-sheet Excel onboarding, data validation, anomaly detection,
smart question generation, SSE progress, and disk persistence.
"""
import os
import time
import json
import logging
from datetime import datetime
from typing import List, Dict, Any
from fastapi import APIRouter, File, UploadFile, Form, HTTPException, Header
from pathlib import Path

from backend.services.scorecard_registry import (
    add_scorecard, persist_to_disk, delete_scorecard, get_scorecard, refresh_from_disk
)
from backend.services.data_service import (
    process_all_sheets, calculate_kri, validate_upload, load_all_sheets
)
from backend.services.document_service import parse_and_index_documents
from backend.routers.auth import check_role

log = logging.getLogger("onboard")

router = APIRouter()

# SSE progress state (in-memory, per scorecard_id)
_PROGRESS: Dict[str, Dict[str, Any]] = {}


def _set_progress(scorecard_id: str, step: int, label: str, status: str = "active"):
    _PROGRESS[scorecard_id] = {"step": step, "label": label, "status": status}


def _detect_anomalies(df, schema) -> List[Dict[str, Any]]:
    """Auto-detect anomalies in the data."""
    anomalies = []
    rag_cols = schema.get("rag_status", [])
    measure_cols = schema.get("measure", [])

    # 1. Rules with failures (Red status)
    if rag_cols:
        rag_col = rag_cols[0]
        try:
            red_count = len(df[df[rag_col].str.lower() == "red"])
            if red_count > 0:
                anomalies.append({
                    "signal_type": "breach",
                    "severity": "critical" if red_count > 5 else "high",
                    "description": f"{red_count} records with RED status detected",
                    "col": rag_col,
                    "context": f"Total records: {len(df)}, Failure rate: {red_count/len(df)*100:.1f}%",
                })
            amber_count = len(df[df[rag_col].str.lower() == "amber"])
            if amber_count > 0:
                anomalies.append({
                    "signal_type": "warning",
                    "severity": "medium",
                    "description": f"{amber_count} records with AMBER status (at risk)",
                    "col": rag_col,
                    "context": f"At-risk rate: {amber_count/len(df)*100:.1f}%",
                })
        except Exception:
            pass

    # 2. Measure columns with outliers
    for col in measure_cols[:3]:
        try:
            vals = df[col].dropna()
            if len(vals) > 2:
                mean_val = vals.mean()
                std_val = vals.std()
                if std_val > 0:
                    outliers = vals[abs(vals - mean_val) > 2 * std_val]
                    if len(outliers) > 0:
                        anomalies.append({
                            "signal_type": "outlier",
                            "severity": "medium",
                            "description": f"{len(outliers)} outliers in '{col}' (>2 std from mean)",
                            "col": col,
                            "context": f"Mean: {mean_val:.2f}, Std: {std_val:.2f}",
                        })
        except Exception:
            pass

    return anomalies


def _generate_starter_questions(df, schema, sheets=None) -> List[str]:
    """Generate contextual starter questions from actual data columns."""
    questions = []
    rag_cols = schema.get("rag_status", [])
    dim_cols = schema.get("dimension", [])
    measure_cols = schema.get("measure", [])
    id_cols = schema.get("identifier", [])

    if rag_cols:
        questions.append("Show RAG status distribution")
        questions.append("How many rules are failing?")

    if id_cols:
        col = id_cols[0]
        questions.append(f"How many unique {col.replace('_', ' ')}s are there?")
        questions.append(f"List all {col.replace('_', ' ')}s")

    if dim_cols:
        for col in dim_cols[:2]:
            sample_vals = df[col].dropna().unique()[:3]
            if len(sample_vals) > 0:
                questions.append(f"Show data for {col.replace('_', ' ')} = {sample_vals[0]}")

    if measure_cols:
        col = measure_cols[0]
        questions.append(f"What is the average {col.replace('_', ' ')}?")

    if rag_cols and dim_cols:
        questions.append(f"Which {dim_cols[0].replace('_', ' ')} has the most failures?")

    # Sheet-specific questions
    if sheets:
        sheet_names = list(sheets.keys())
        if any("solo" in s for s in sheet_names):
            questions.append("Show me Solo results")
        if any("conso" in s for s in sheet_names):
            questions.append("Show me Consolidated results")
        if len(sheet_names) > 2:
            questions.append("Compare Solo vs Consolidated")

    questions.append("Give me a dashboard summary")
    questions.append("What are the key anomalies?")

    return questions[:10]


def _generate_narrative(df, schema, kpis, anomalies) -> str:
    """Auto-generate a 2-3 sentence summary."""
    parts = []
    total = kpis.get("total", len(df))
    failed = kpis.get("failed", 0)

    parts.append(f"Dataset contains {len(df):,} records across {len(df.columns)} columns.")

    if failed > 0:
        parts.append(f"{failed} rules are failing out of {total} total (KRI: {failed/total*100:.1f}%).")
    else:
        parts.append(f"All {total} rules are passing.")

    if anomalies:
        critical = [a for a in anomalies if a["severity"] == "critical"]
        if critical:
            parts.append(f"{len(critical)} critical anomalies detected requiring attention.")

    return " ".join(parts)


@router.post("/onboard")
async def onboard_scorecard(
    scorecard_id: str = Form(...),
    display_name: str = Form(...),
    legal_entity: str = Form("ALL"),
    kri_id: str = Form(""),
    data_file: UploadFile = File(...),
    doc_files: List[UploadFile] = File([]),
    x_user_id: str = Header(default="PG23137"),
):
    """Onboard a new scorecard with multi-sheet support. Admin role required."""
    if not check_role(x_user_id, "admin"):
        raise HTTPException(status_code=403, detail="Admin role required to onboard scorecards")

    try:
        # Step 1: Parse file
        _set_progress(scorecard_id, 1, f"Parsing {data_file.filename}...")
        data_content = await data_file.read()

        # Step 1b: Validate
        _set_progress(scorecard_id, 1, "Validating file...")
        validation = validate_upload(data_content, data_file.filename)
        if not validation["valid"]:
            errors = "; ".join(validation["errors"])
            _set_progress(scorecard_id, 1, f"Validation failed: {errors}", "error")
            raise HTTPException(status_code=400, detail=f"Validation failed: {errors}")

        # Step 2: Load all sheets and detect columns
        _set_progress(scorecard_id, 2, "Detecting columns and schema...")
        all_sheets, primary_df, schema, visual_config = process_all_sheets(
            data_content, data_file.filename
        )
        sheet_count = len(all_sheets)
        _set_progress(
            scorecard_id, 2,
            f"Found {len(primary_df.columns)} columns, {sheet_count} sheet(s), "
            f"{len(schema.get('measure', []))} measures, {len(schema.get('dimension', []))} dimensions"
        )

        # Step 3: Build visual config (already done in process_all_sheets)
        _set_progress(scorecard_id, 3, "Building visual configuration...")

        # Step 4: Index documents
        docs_parsed = []
        for doc in doc_files:
            if getattr(doc, "filename", None) and doc.filename:
                content = await doc.read()
                if len(content) > 0:
                    docs_parsed.append((doc.filename, content))

        vectorizer, chunks = None, []
        tfidf_matrix = None
        if docs_parsed:
            _set_progress(scorecard_id, 4, f"Indexing {len(docs_parsed)} documents...")
            vectorizer, chunks = parse_and_index_documents(docs_parsed)
            if vectorizer and chunks:
                corpus = [c["content"] for c in chunks]
                tfidf_matrix = vectorizer.transform(corpus)
                _set_progress(scorecard_id, 4, f"Indexed {len(docs_parsed)} files, {len(chunks)} chunks")
        else:
            _set_progress(scorecard_id, 4, "No documents to index")

        # Step 5: Compute KPIs and anomalies
        _set_progress(scorecard_id, 5, "Detecting anomalies...")
        kri_data = calculate_kri(primary_df, schema)
        anomalies = _detect_anomalies(primary_df, schema)
        questions = _generate_starter_questions(primary_df, schema, all_sheets)
        narrative = _generate_narrative(primary_df, schema, kri_data, anomalies)

        # Build KPIs list
        kpis_list = []
        if kri_data:
            total = kri_data.get("total", 0)
            failed = kri_data.get("failed", 0)
            kri_val = kri_data.get("kri", 0)
            kpis_list.append({
                "name": f"KRI Score ({kri_id or scorecard_id})",
                "current_val": kri_val,
                "threshold": 0.05,
                "direction": "lower_is_better",
                "status": "breaching" if kri_val > 0.05 else "on_track",
                "trend": "stable",
                "pct_change": 0,
            })
            kpis_list.append({
                "name": "Pass Rate",
                "current_val": (1 - kri_val),
                "threshold": 0.95,
                "direction": "higher_is_better",
                "status": "on_track" if (1 - kri_val) >= 0.95 else "at_risk",
                "trend": "stable",
                "pct_change": 0,
            })

        capabilities = {
            "time_series": bool(schema.get("date")),
            "geographic": False,
            "rag_status": bool(schema.get("rag_status")),
            "thresholds": bool(schema.get("threshold")),
            "multi_measure": len(schema.get("measure", [])) > 1,
            "multi_sheet": sheet_count > 1,
        }

        # Register
        scorecard_data = {
            "scorecard_id": scorecard_id,
            "display_name": display_name,
            "legal_entity": legal_entity,
            "kri_id": kri_id,
            "df": primary_df,
            "sheets": all_sheets,
            "months": {},
            "schema": schema,
            "visual_config": visual_config,
            "doc_index": vectorizer,
            "tfidf_matrix": tfidf_matrix,
            "doc_chunks": chunks,
            "onboarded_at": datetime.utcnow().isoformat(),
            "row_count": len(primary_df),
            "col_count": len(primary_df.columns),
            "anomalies": anomalies,
            "anomaly_count": len(anomalies),
            "kpis": kpis_list,
            "narrative": narrative,
            "questions": questions,
            "capabilities": capabilities,
            "data_filename": data_file.filename,
            "file_modified": datetime.utcnow().isoformat(),
            "periods": {},
        }

        add_scorecard(scorecard_id, scorecard_data)

        # Step 6: Persist to disk
        _set_progress(scorecard_id, 6, "Persisting to disk...")
        persist_to_disk(scorecard_id)

        # Save uploaded doc files to disk
        from backend.services.scorecard_registry import STORAGE_DIR
        docs_dir = STORAGE_DIR / scorecard_id / "docs"
        docs_dir.mkdir(parents=True, exist_ok=True)
        for doc_name, doc_content in docs_parsed:
            with open(docs_dir / doc_name, "wb") as f:
                f.write(doc_content)

        _set_progress(scorecard_id, 7, "Ready", "done")
        log.info(
            f"Onboarded '{scorecard_id}': {len(primary_df)} rows, "
            f"{sheet_count} sheets, {len(anomalies)} anomalies, {len(questions)} questions"
        )

        return {
            "status": "success",
            "scorecard_id": scorecard_id,
            "source_id": scorecard_id,
            "source_name": display_name,
            "dashboard_type": "CDE Exception Scorecard",
            "extraction_strategy": "csv" if data_file.filename.endswith(".csv") else "excel",
            "total_rows": len(primary_df),
            "total_cols": len(primary_df.columns),
            "onboarded_at": scorecard_data["onboarded_at"],
            "schema_detected": schema,
            "visual_config": visual_config,
            "anomalies": anomalies,
            "anomaly_count": len(anomalies),
            "kpis": kpis_list,
            "narrative": narrative,
            "questions": questions,
            "capabilities": capabilities,
            "dimensions": schema.get("dimension", []),
            "measures": schema.get("measure", []),
            "time_cols": schema.get("date", []),
            "status_cols": schema.get("rag_status", []),
            "entities": [],
            "sheet_count": sheet_count,
            "sheet_names": list(all_sheets.keys()),
            "validation": validation,
        }

    except HTTPException:
        raise
    except Exception as e:
        _set_progress(scorecard_id, 0, str(e), "error")
        log.error(f"Onboard failed for '{scorecard_id}': {e}")
        raise HTTPException(status_code=500, detail=f"Onboarding failed: {str(e)}")


@router.delete("/{scorecard_id}")
async def delete_scorecard_endpoint(scorecard_id: str, x_user_id: str = Header(default="PG23137")):
    """Delete a scorecard. Admin role required."""
    if not check_role(x_user_id, "admin"):
        raise HTTPException(status_code=403, detail="Admin role required to delete scorecards")

    removed = delete_scorecard(scorecard_id)
    if not removed:
        raise HTTPException(status_code=404, detail=f"Scorecard '{scorecard_id}' not found")

    return {"status": "deleted", "scorecard_id": scorecard_id}


@router.post("/{scorecard_id}/refresh")
async def refresh_scorecard(scorecard_id: str, x_user_id: str = Header(default="PG23137")):
    """Re-read data file from disk and recompute schema."""
    if not check_role(x_user_id, "analyst"):
        raise HTTPException(status_code=403, detail="Analyst role or higher required")

    ok = refresh_from_disk(scorecard_id)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Could not refresh '{scorecard_id}'")

    return {"status": "refreshed", "scorecard_id": scorecard_id}


def get_progress(scorecard_id: str) -> Dict[str, Any]:
    """Get current progress for SSE streaming."""
    return _PROGRESS.get(scorecard_id, {"step": 0, "label": "Waiting...", "status": "wait"})
