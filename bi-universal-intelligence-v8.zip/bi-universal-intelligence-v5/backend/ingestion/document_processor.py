"""
ingestion/document_processor.py
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ingests unstructured documents (PDFs, TXT), chunks them, 
generates embeddings via Vertex AI, and persists to ChromaDB.
"""
import io
import os
import uuid
import logging
from typing import List, Dict

try:
    import chromadb
    from pypdf import PdfReader
except ImportError:
    chromadb = None
    PdfReader = None

from backend.services.vertex_service import get_embeddings_for_texts

log = logging.getLogger("document_processor")

CHROMA_PATH = ".data/chroma"
COLLECTION_NAME = "universal_docs"

_chroma_client = None

def get_chroma_collection():
    """Initialises or retrieves the ChromaDB collection."""
    global _chroma_client
    if not chromadb:
        raise RuntimeError("chromadb is not installed. Run: pip install chromadb pypdf")
    
    if _chroma_client is None:
        os.makedirs(CHROMA_PATH, exist_ok=True)
        _chroma_client = chromadb.PersistentClient(path=CHROMA_PATH)
    
    return _chroma_client.get_or_create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"}
    )

def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Extract all text from a PDF byte stream."""
    if not PdfReader:
        raise RuntimeError("pypdf is not installed. Run: pip install pypdf")
    
    reader = PdfReader(io.BytesIO(file_bytes))
    full_text = []
    for page in reader.pages:
        text = page.extract_text()
        if text:
            full_text.append(text)
    return "\n".join(full_text)

def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 150) -> List[str]:
    """Splits massive text into smaller overlapping chunks for RAG."""
    # Very basic character chunking for now
    chunks = []
    start = 0
    text_len = len(text)
    while start < text_len:
        end = start + chunk_size
        chunks.append(text[start:end])
        start += chunk_size - overlap
    return chunks

def process_document(file_bytes: bytes, filename: str, mime_type: str = "application/pdf") -> Dict:
    """
    1. Extracts text from the document.
    2. Chunks it.
    3. Calls Vertex AI for embeddings.
    4. Saves to ChromaDB.
    Returns metadata about the ingested document.
    """
    log.info(f"Processing uploaded document: {filename}")
    
    # 1. Extract
    if "pdf" in mime_type.lower():
        text = extract_text_from_pdf(file_bytes)
    else:
        # Fallback for plain text
        text = file_bytes.decode("utf-8", errors="ignore")
        
    if not text.strip():
        raise ValueError("No extractable text found in document.")

    # 2. Chunk
    chunks = chunk_text(text)
    log.info(f"Document split into {len(chunks)} chunks.")

    # 3. Embed Vectors
    embeddings = get_embeddings_for_texts(chunks)
    if not embeddings or len(embeddings) != len(chunks):
        raise RuntimeError("Failed to generate vectors from Vertex AI.")

    # 4. Store in ChromaDB
    collection = get_chroma_collection()
    
    doc_id = f"doc_{uuid.uuid4().hex[:8]}"
    
    # Prepare Chroma Payload
    ids = [f"{doc_id}_{i}" for i in range(len(chunks))]
    metadatas = [{"source_id": doc_id, "filename": filename, "chunk_idx": i} for i in range(len(chunks))]
    
    collection.add(
        ids=ids,
        embeddings=embeddings,
        documents=chunks,
        metadatas=metadatas
    )
    
    log.info(f"Successfully vectorized and stored {filename} under {doc_id}")
    
    return {
        "source_id": doc_id,
        "name": filename,
        "type": "document",
        "chunks": len(chunks)
    }

def search_documents(query: str, doc_id: str = None, top_k: int = 4) -> List[str]:
    """
    Searches ChromaDB for the most relevant text chunks fitting the query.
    """
    collection = get_chroma_collection()
    query_vector = get_embeddings_for_texts([query])
    if not query_vector:
        return []

    where_clause = {"source_id": doc_id} if doc_id else None
    
    results = collection.query(
        query_embeddings=query_vector,
        n_results=top_k,
        where=where_clause
    )
    
    if not results or not results['documents'] or not results['documents'][0]:
        return []
        
    return results['documents'][0]
