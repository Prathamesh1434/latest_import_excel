import logging
import pandas as pd
import numpy as np

log = logging.getLogger("data_cleanser")

class DataCleanser:
    """
    Sanitizes raw Pandas dataframes extracted from Tableau.
    Solves Tableau's notoriously noisy exports by:
    1. Dropping completely empty layout rows/cols
    2. Re-pivoting "Measure Names" / "Measure Values" structures
    3. Trimming string variables
    4. Casting formatted number strings ($1,234.50) to pure floats
    5. Imputing Nulls to prevent JSON serialization crashes
    """

    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        if df is None or df.empty:
            return pd.DataFrame()

        new_df = df.copy()
        
        # 1. Remove Layout Artifacts
        new_df = self._remove_layout_artifacts(new_df)
        if new_df.empty: return new_df
        
        # 2. Pivot Tableau's annoying "Measure Names" format
        new_df = self._pivot_measure_names(new_df)
        
        # 3. Trim String Whitspace
        new_df = self._trim_strings(new_df)
        
        # 4. Smart Type Coercion (Regex to Float)
        new_df = self._coerce_types(new_df)
        
        # 5. Null Imputation
        new_df = self._impute_nans(new_df)
        
        return new_df

    def _remove_layout_artifacts(self, df: pd.DataFrame) -> pd.DataFrame:
        """Drops columns and rows that are 100% NA/Blank (padding in Tableau)."""
        # Drop fully empty cols and rows
        df = df.dropna(axis=1, how='all')
        df = df.dropna(axis=0, how='all')
        
        # Also drop columns where every value is an empty string
        cols_to_drop = []
        for col in df.columns:
            if df[col].astype(str).str.strip().replace("", np.nan).isna().all():
                cols_to_drop.append(col)
                
        if cols_to_drop:
            df = df.drop(columns=cols_to_drop)
            
        return df

    def _pivot_measure_names(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Tableau often exports multi-metric views identically as:
            [Region], [Measure Names], [Measure Values]
            "US",     "Sales",         1000
            "US",     "Profit",        500
        We want to pivot this back to [Region], [Sales], [Profit].
        """
        cols_lower = [str(c).lower() for c in df.columns]
        
        measure_col = next((c for idx, c in enumerate(df.columns) if cols_lower[idx] == "measure names"), None)
        value_col   = next((c for idx, c in enumerate(df.columns) if cols_lower[idx] == "measure values"), None)
        
        if measure_col and value_col:
            log.info("Detected 'Measure Names' / 'Measure Values' structure. Pivoting dataframe...")
            index_cols = [c for c in df.columns if c not in [measure_col, value_col]]
            
            try:
                # Pivot
                pivoted = df.pivot_table(
                    index=index_cols, 
                    columns=measure_col, 
                    values=value_col, 
                    aggfunc='first'
                ).reset_index()
                
                # Cleanup column name artifacts
                pivoted.columns.name = None
                return pivoted
            except Exception as e:
                log.warning(f"Failed to auto-pivot Measure Names table: {e}")
                
        return df

    def _trim_strings(self, df: pd.DataFrame) -> pd.DataFrame:
        """Trims whitespace from dimension strings to ensure matching ('New York ' == 'New York')."""
        for col in df.columns:
            if pd.api.types.is_string_dtype(df[col]) or pd.api.types.is_object_dtype(df[col]):
                try:
                    df[col] = df[col].astype(str).str.strip()
                except Exception:
                    pass
        return df

    def _coerce_types(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Checks object/string columns for numeric characters representing money or percentages.
        Strips $, €, £, %, and commas, casting them to pure floats.
        """
        for col in df.columns:
            if not pd.api.types.is_numeric_dtype(df[col]):
                sample = df[col].dropna().astype(str).head(10)
                
                # Check if sample looks like formatted numbers ($1,234.50 or 15%)
                if len(sample) > 0 and sample.str.contains(r'^[\$\€\£\s\-]*[\d\,\.]+\s*\%?$', regex=True).all():
                    try:
                        clean_series = df[col].astype(str).str.replace(r'[\$\€\£\,\s]', '', regex=True)
                        is_pct = clean_series.str.endswith('%').all()
                        
                        clean_series = clean_series.str.replace('%', '')
                        numeric_series = pd.to_numeric(clean_series, errors='coerce')
                        
                        if is_pct:
                            numeric_series = numeric_series / 100.0
                            
                        df[col] = numeric_series
                        log.debug(f"Coerced formatted column '{col}' to pure numeric.")
                    except Exception as e:
                        log.debug(f"Could not coerce {col}: {e}")
        return df

    def _impute_nans(self, df: pd.DataFrame) -> pd.DataFrame:
        """Fills NaNs depending on column type to optimize JSON output."""
        for col in df.columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                # Fill missing KPIs with 0
                df[col] = df[col].fillna(0)
            else:
                # Forward-fill categoricals
                df[col] = df[col].ffill()
                # If still NaN at the top, fill with 'Unknown'
                df[col] = df[col].fillna("Unknown")
        return df
