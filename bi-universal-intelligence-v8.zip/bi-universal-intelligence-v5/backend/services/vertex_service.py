"""
services/vertex_service.py — v5

Thin wrapper around vertex_util.py (Citi internal utility).
Imports the pre-configured llm, embeddings, and get_new_token
directly — zero auth duplication.

SETUP:
  1. Copy your vertex_util.py → backend/services/vertex_util.py
  2. Create config/{ENV}/config.yaml (or set ENVIRONMENT=local)
  3. Set CLIENT_ID + CLIENT_SECRET in .env
  4. Done — this file handles the rest

Interface (unchanged from v4):
  chat()  → (reply, chart, in_tok, out_tok, resp_ms)
  ping()  → (ok, ms)
"""

import time
import logging
import json
import re
from typing import List, Dict, Tuple, Optional

from backend.config import MAX_TOKENS, check_vertex

log = logging.getLogger("vertex_service")

# ══════════════════════════════════════════════════════════════════════
# IMPORT FROM YOUR vertex_util.py — the ONLY auth source
# ══════════════════════════════════════════════════════════════════════

_llm = None
_embeddings = None
_initialized = False


def _ensure_init():
    """
    Import llm + embeddings from vertex_util.py on first use.

    vertex_util.py does everything at module level:
      - Reads config.yaml
      - Creates coin_proxy_token_roller
      - Calls init_vertexai()
      - Builds ChatVertexAI → llm
      - Builds VertexAIEmbeddings → embeddings

    We just import the finished objects.
    """
    global _llm, _embeddings, _initialized

    if _initialized:
        return

    log.info("Loading Vertex AI from vertex_util.py…")
    t0 = time.time()

    try:
        from backend.services.vertex_util import llm, embeddings

        _llm = llm
        _embeddings = embeddings
        _initialized = True

        model_name = getattr(_llm, "model_name", getattr(_llm, "model", "unknown"))
        log.info(
            f"  ✓ Vertex AI ready via vertex_util.py "
            f"(model={model_name}, {int((time.time()-t0)*1000)}ms)"
        )

    except ImportError as e:
        log.error(
            f"  ✗ Cannot import from vertex_util.py: {e}\n"
            f"    → Copy your vertex_util.py to backend/services/vertex_util.py\n"
            f"    → Ensure config/{{ENV}}/config.yaml exists\n"
            f"    → Set CLIENT_ID and CLIENT_SECRET in .env"
        )
        raise

    except Exception as e:
        log.error(f"  ✗ vertex_util.py init failed: {type(e).__name__}: {e}")
        raise


# ══════════════════════════════════════════════════════════════════════
# CHART-AWARE SYSTEM PROMPT
# ══════════════════════════════════════════════════════════════════════

CHART_INSTRUCTIONS = """

=== RESPONSE FORMAT ===
You MUST respond with valid JSON only. No markdown, no backticks, no extra text.
Schema:
{
  "reply": "2-3 sentence plain text summary for the user",
  "chart_type": "bar|line|pie|doughnut|kpi|table|text",
  "chart": {
    "title": "Chart title",
    "subtitle": "Period/context",
    ... chart-specific fields
  }
}

CHART TYPE RULES:
- "kpi"      → current values, status check, single metrics
- "bar"      → comparisons, rankings, side-by-side
- "line"     → trends, history, over time
- "pie"      → distribution, composition, share
- "doughnut" → pass/fail splits, percentage of whole
- "table"    → detailed data, lists
- "text"     → explanations, definitions

KPI: {"chart":{"title":"...","subtitle":"...","kpis":[{"label":"UK-K41","value":"8%","subtitle":"Red <70%","trend":"▼ -57.9%","trend_type":"down","color":"red"}]}}
BAR/LINE: {"chart":{"title":"...","subtitle":"...","labels":["Jan","Feb"],"datasets":[{"label":"S1","data":[10,20],"color":"#1565C0"}]}}
PIE: {"chart":{"title":"...","subtitle":"...","labels":["Red","Green"],"data":[4,1],"colors":["#C62828","#2E7D32"]}}
TABLE: {"chart":{"title":"...","subtitle":"...","columns":["KRI","Value"],"rows":[["UK-K41","8%"]]}}
TEXT: "chart": null

IMPORTANT:
- Decimals (0.08) → show as percentages (8%)
- Include reporting period in subtitle
- 2-3 sentences max — chart shows detail
- ONLY valid JSON output
"""


# ══════════════════════════════════════════════════════════════════════
# CHAT — uses _llm from vertex_util.py
# ══════════════════════════════════════════════════════════════════════

def chat(
    system_prompt: str,
    messages: List[Dict],
    max_tokens: int = MAX_TOKENS,
    retries: int = 2,
) -> Tuple[str, Optional[dict], int, int, int]:
    """
    Returns (reply_text, chart_dict_or_none, input_tokens, output_tokens, response_ms)

    Uses ChatVertexAI instance from vertex_util.py — COIN-authenticated.
    """
    _ensure_init()
    if not messages:
        raise ValueError("No messages")

    full_system = system_prompt + CHART_INSTRUCTIONS
    last_err = None

    for attempt in range(retries + 1):
        t0 = time.time()
        try:
            from langchain_core.messages import SystemMessage, HumanMessage, AIMessage

            # Build LangChain message list
            lc_messages = [SystemMessage(content=full_system)]
            for m in messages:
                if m["role"] == "user":
                    lc_messages.append(HumanMessage(content=m["content"]))
                elif m["role"] == "assistant":
                    lc_messages.append(AIMessage(content=m["content"]))

            # Call your pre-configured llm
            response = _llm.invoke(lc_messages)
            raw = response.content or "{}"

            # Parse JSON response
            raw = re.sub(r"```json|```", "", raw).strip()
            data = json.loads(raw)
            reply      = data.get("reply", "No response generated.")
            chart_data = data.get("chart", None)
            resp_ms    = int((time.time() - t0) * 1000)

            # Token counts (best-effort from LangChain response metadata)
            in_tok = out_tok = 0
            if hasattr(response, "response_metadata"):
                usage = (response.response_metadata or {}).get("usage_metadata", {})
                in_tok  = usage.get("prompt_token_count", 0)
                out_tok = usage.get("candidates_token_count", 0)
            elif hasattr(response, "usage_metadata"):
                in_tok  = getattr(response.usage_metadata, "prompt_token_count", 0) or 0
                out_tok = getattr(response.usage_metadata, "candidates_token_count", 0) or 0

            log.info(
                f"Gemini OK: in={in_tok} out={out_tok} ms={resp_ms} "
                f"chart={data.get('chart_type', 'text')}"
            )
            return reply, chart_data, in_tok, out_tok, resp_ms

        except json.JSONDecodeError:
            log.warning(f"JSON parse failed attempt {attempt+1}. Raw: {raw[:200]}")
            return raw[:500] if raw else "Could not parse response.", None, 0, 0, int((time.time()-t0)*1000)

        except Exception as e:
            last_err = e
            if attempt < retries:
                wait = 2 ** attempt
                time.sleep(wait)
                log.warning(f"Gemini attempt {attempt+1} failed: {type(e).__name__}: {e}")

    raise last_err


# ══════════════════════════════════════════════════════════════════════
# PING
# ══════════════════════════════════════════════════════════════════════

def ping() -> Tuple[bool, int]:
    t0 = time.time()
    try:
        _ensure_init()
        from langchain_core.messages import HumanMessage
        r = _llm.invoke([HumanMessage(content="Reply with exactly: ok")])
        return bool(r.content), int((time.time() - t0) * 1000)
    except Exception as e:
        log.warning(f"Gemini ping failed: {e}")
        return False, int((time.time() - t0) * 1000)


# ══════════════════════════════════════════════════════════════════════
# EMBEDDINGS ACCESS (for future RAG)
# ══════════════════════════════════════════════════════════════════════

def get_embeddings():
    """Return the VertexAIEmbeddings instance from vertex_util.py."""
    _ensure_init()
    return _embeddings

def get_embeddings_for_texts(texts: List[str]) -> List[List[float]]:
    """Convert chunks of text into vectors using Vertex AI."""
    _ensure_init()
    if not _embeddings:
        log.error("VertexAI Embeddings not initialized.")
        return []
    
    # embed_documents is standard in langchain_google_vertexai's VertexAIEmbeddings
    try:
        return _embeddings.embed_documents(texts)
    except Exception as e:
        log.error(f"Failed to fetch embeddings: {e}")
        return []
