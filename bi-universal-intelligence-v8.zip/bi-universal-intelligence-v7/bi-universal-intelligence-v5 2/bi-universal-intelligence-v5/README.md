# B&I CDE Intelligence Platform

A standalone enterprise-grade Data Intelligence Platform custom-built for Citi's Banking & International Data Analytics team. This application replaces legacy Tableau API integrations with a zero-friction data portal capable of dynamic CSV/Excel scorecard uploads and AI-powered data reasoning.

## Full-Stack Architecture
The platform is built strictly following the guidelines for a containerized, lightning-fast application without build steps.

**Backend:** FastAPI + Uvicorn (Python 3.11)
**Data Processing:** Pandas, Numpy
**Semantic Engine:** Scikit-Learn (TF-IDF Vectorizer)
**AI Engine:** Vertex AI Gemini Integration via `vertex_util.py` (COIN Auth)
**Frontend:** Pure HTML5, CSS3, Vanilla JS and Chart.js served identically without a compilation step.

## File Hierarchy

```
downloads/
└── bi-universal-intelligence-v5/
    ├── backend/
    │   ├── main.py                     # Initializer mapping router endpoints
    │   ├── config.py                   # ENV variables and structured logger bindings
    │   ├── routers/
    │   │   ├── api.py                  # API Health checks and status endpoints
    │   │   ├── onboard.py              # Central intake (Form+File mapping)
    │   │   ├── data.py                 # Endpoint to extract Schema, KRI, and Data views
    │   │   ├── chat.py                 # POST wrapper triggering Gemini chat
    │   │   └── docs.py                 # Endpoint for semantic document fetching
    │   └── services/
    │       ├── data_service.py         # Parsing CSVs iteratively inside Pandas
    │       ├── document_service.py     # Unpacks text and establishes sklearn cosine similarity models
    │       ├── query_engine.py         # Passes contextual snippets directly into Vertex queries
    │       ├── scorecard_registry.py   # Global in-memory dictionary preserving instance configurations
    │       ├── column_classifier.py    # Auto-detection heuristic mapping (Regex / Datatype mappings)
    │       ├── visual_generator.py     # Parses schema output to direct ChartJS frontend parameters
    │       └── vertex_util.py          # Pre-built model bindings handling M2M authentications
    ├── dashboard.html                  # Single-file HTML serving all dashboards UI functions dynamically
    ├── test_runner.py                  # Script to mock backend data ingest and document scraping tests end-to-end
    └── README.md                       # This file
```

## Running the Application

### 1. Requirements
Ensure the base environment has dependencies satisfied:
```bash
pip install fastapi uvicorn pandas scikit-learn python-multipart openpyxl httpx
```

### 2. Start Application
Launch the backend dynamically locally:
```bash
uvicorn backend.main:app --port 8000
```
Open up your browser to execute the frontend rendering. If working over a server or WSL, run the single-file UI:
```bash
python -m http.server 8080
```
Navigate to `http://localhost:8080/dashboard.html`!

## Testing

A unified `test_runner.py` is included for fast validation (it requires `httpx`). Run it using:
```bash
python test_runner.py
```
This runs deep testing across:
- **Onboarding Pipeline:** Emulates a multi-part file upload carrying dummy exceptions CSV alongside mocked reference text records.
- **Auto-Detection Verification:** Evaluates heuristic data mappings (i.e., mapping Red/Amber/Green variables automatically).
- **Endpoint Simulation:** Triggers mocked KRI rendering computations and filters logic, and initiates internal `query_engine.py` calls simulating Vertex chat.
