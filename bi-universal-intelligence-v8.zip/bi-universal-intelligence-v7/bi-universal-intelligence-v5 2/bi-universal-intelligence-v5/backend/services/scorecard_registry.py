from typing import Dict, Any

# In-memory registry for all onboarded scorecards.
# Format:
# {
#   "scorecard_id": {
#     "scorecard_id": str,
#     "display_name": str,
#     "legal_entity": str,
#     "kri_id": str,
#     "df": pd.DataFrame,
#     "schema": dict,
#     "visual_config": dict,
#     "doc_index": TfidfVectorizer,
#     "doc_chunks": list,
#     "onboarded_at": str,
#     "row_count": int,
#     "col_count": int
#   }
# }
_REGISTRY: Dict[str, Dict[str, Any]] = {}

def add_scorecard(scorecard_id: str, data: Dict[str, Any]) -> None:
    _REGISTRY[scorecard_id] = data

def get_scorecard(scorecard_id: str) -> Dict[str, Any]:
    if scorecard_id not in _REGISTRY:
        raise KeyError(f"Scorecard '{scorecard_id}' not found.")
    return _REGISTRY[scorecard_id]

def delete_scorecard(scorecard_id: str) -> None:
    if scorecard_id in _REGISTRY:
        del _REGISTRY[scorecard_id]

def list_all() -> Dict[str, Dict[str, Any]]:
    return _REGISTRY
