import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from typing import List, Dict, Any, Tuple

def parse_and_index_documents(doc_files: List[Tuple[str, bytes]]) -> Tuple[Any, List[Dict[str, Any]]]:
    """
    Parses document bytes, splits into chunks, and builds a TF-IDF index.
    Returns the vectorizer and the list of document chunks.
    """
    chunks = []
    
    for filename, content in doc_files:
        try:
            text = content.decode('utf-8')
        except UnicodeDecodeError:
            text = content.decode('latin-1')
            
        # simple split by double newline or headers
        paragraphs = text.split('\n\n')
        for i, p in enumerate(paragraphs):
            p = p.strip()
            if p:
                chunks.append({
                    "doc_name": filename,
                    "section": f"Chunk {i}",
                    "content": p
                })
                
    if not chunks:
        return None, []
        
    vectorizer = TfidfVectorizer(stop_words='english')
    corpus = [c['content'] for c in chunks]
    vectorizer.fit(corpus)
    # Store the TF-IDF matrix with the vectorizer optionally, but we can compute on the fly logic
    # Actually, we should store the tfidf_matrix as well for fast search
    return vectorizer, chunks

def search_documents(query: str, vectorizer: TfidfVectorizer, chunks: List[Dict[str, Any]], top_k: int = 3) -> List[Dict[str, Any]]:
    if not vectorizer or not chunks:
        return []
        
    corpus = [c['content'] for c in chunks]
    tfidf_matrix = vectorizer.transform(corpus)
    query_vec = vectorizer.transform([query])
    
    similarities = cosine_similarity(query_vec, tfidf_matrix).flatten()
    top_indices = similarities.argsort()[-top_k:][::-1]
    
    results = []
    for idx in top_indices:
        if similarities[idx] > 0.05: # threshold
            res = chunks[idx].copy()
            res['score'] = similarities[idx]
            results.append(res)
            
    return results
