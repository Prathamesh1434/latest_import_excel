import pandas as pd
from typing import Dict, Any, List
from backend.services.vertex_service import chat
from backend.services.document_service import search_documents
import json

def construct_prompt(question: str, df: pd.DataFrame, schema: Dict[str, list], docs: List[Dict[str, Any]]) -> str:
    preview = df.head(5).to_csv(index=False)
    
    doc_context = ""
    if docs:
        doc_context = "Relevant Documentation:\n"
        for d in docs:
            doc_context += f"From {d['doc_name']} ({d['section']}):\n{d['content']}\n\n"
            
    prompt = f"""
You are an AI assistant for B&I CDE Intelligence Platform.
User Question: {question}

Data Schema: {json.dumps(schema)}
Data Preview (first 5 rows):
{preview}

{doc_context}

Provide a helpful, precise answer based on the data and documentation.
"""
    return prompt

def query_scorecard(scorecard: Dict[str, Any], question: str) -> Dict[str, Any]:
    df = scorecard.get("df")
    schema = scorecard.get("schema", {})
    vectorizer = scorecard.get("doc_index")
    chunks = scorecard.get("doc_chunks", [])
    
    # 1. Search docs
    relevant_docs = []
    if vectorizer and chunks:
        relevant_docs = search_documents(question, vectorizer, chunks)
        
    # 2. Basic pandas matching (optional, here we rely on Gemini for interpretation)
    
    # 3. Gemini prompt
    system_prompt = construct_prompt(question, df, schema, relevant_docs)
    
    try:
        reply, chart, in_tok, out_tok, ms = chat(system_prompt, messages=[{"role": "user", "content": question}])
        return {
            "reply": reply,
            "chart": chart,
            "docs": relevant_docs
        }
    except Exception as e:
        # fallback text if vertex fails or is not configured
        return {
            "reply": f"Error querying LLM: {str(e)}. (Make sure Vertex AI is configured).",
            "chart": None,
            "docs": relevant_docs
        }
