import logging
from backend.config import setup_logging
setup_logging()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend.routers.api import router as api_router
from backend.routers.onboard import router as onboard_router
from backend.routers.data import router as data_router
from backend.routers.chat import router as chat_router
from backend.routers.docs import router as docs_router

log = logging.getLogger("main")

app = FastAPI(
    title="B&I CDE Intelligence Platform",
    description="Standalone Enterprise Data Intelligence Platform",
    version="1.0.0"
)

app.add_middleware(CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

app.include_router(api_router, tags=["API"])
app.include_router(onboard_router, prefix="/scorecards", tags=["Onboard"])
app.include_router(data_router, prefix="/data", tags=["Data"])
app.include_router(chat_router, prefix="/chat", tags=["Chat"])
app.include_router(docs_router, prefix="/docs", tags=["Docs"])

# No need to mount static files here as serving will be done via python -m http.server 8080 as requested
# However, attaching a single health check
@app.get("/")
def root():
    return {"message": "B&I CDE Intelligence Platform API running."}
