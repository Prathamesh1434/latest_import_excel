from fastapi import APIRouter, HTTPException, Request
from backend.services.scorecard_registry import get_scorecard
from backend.services.data_service import calculate_kri
import math
import pandas as pd

router = APIRouter()

@router.get("/{scorecard_id}/schema")
def get_schema(scorecard_id: str):
    sc = get_scorecard(scorecard_id)
    return {
        "schema": sc.get("schema"),
        "visual_config": sc.get("visual_config")
    }

@router.get("/{scorecard_id}/summary")
def get_summary(scorecard_id: str):
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    schema = sc.get("schema")
    
    rag_dist = {}
    if schema and schema.get("rag_status"):
        rag_col = schema["rag_status"][0]
        rag_dist = df[rag_col].value_counts().to_dict()
        
    return {
        "row_count": sc.get("row_count"),
        "col_count": sc.get("col_count"),
        "schema": schema,
        "rag_distribution": rag_dist
    }

@router.get("/{scorecard_id}/filters")
def get_filters(scorecard_id: str):
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    schema = sc.get("schema")
    
    filters = {}
    # Find critical Tableau filters dynamically
    key_fields = ["date", "report_name", "immutable_cde", "product", "legal_entity", "system"]
    for col in df.columns:
        if col.lower() in key_fields or (schema and schema.get("dimension") and col in schema["dimension"]):
            vals = df[col].dropna().unique().tolist()
            if len(vals) < 100:
                filters[col] = vals
    return filters

@router.post("/{scorecard_id}/query")
async def post_query(scorecard_id: str, request: Request):
    sc = get_scorecard(scorecard_id)
    df = sc.get("df").copy()
    
    body = await request.json()
    filters = body.get("filters", {})
    
    for k, v in filters.items():
        if k in df.columns and v:
            if isinstance(v, list):
                # 'All' logic
                if 'All' not in v and 'ALL' not in v:
                    df = df[df[k].isin(v)]
            else:
                if v != 'All' and v != 'ALL':
                    df = df[df[k] == v]
                
    # Return limited rows for table
    return df.head(100).fillna("").to_dict(orient="records")

@router.get("/{scorecard_id}/kri")
def get_kri(scorecard_id: str):
    sc = get_scorecard(scorecard_id)
    return calculate_kri(sc.get("df"), sc.get("schema"))

@router.get("/{scorecard_id}/landing")
def get_landing(scorecard_id: str):
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    schema = sc.get("schema")
    
    kpis = {
        "total_rules": 0,
        "failed_rules": 0,
        "pass_rate": 0
    }
    
    kri_data = calculate_kri(df, schema)
    if kri_data:
        kpis["total_rules"] = kri_data.get("total", len(df["rule_name"].dropna().unique()) if "rule_name" in df.columns else len(df))
        kpis["failed_rules"] = kri_data.get("failed", 0)
        kpis["pass_rate"] = (1 - kri_data.get("kri", 0)) * 100
        
    trends = []
    if schema.get("date") and schema.get("rag_status"):
        date_col = schema["date"][0]
        rag_col = schema["rag_status"][0]
        fail_df = df[df[rag_col].str.lower() == 'red']
        if not fail_df.empty:
            trends = fail_df.groupby(date_col).size().reset_index(name='failures').to_dict(orient='records')
            
    for item in trends:
        for k, v in item.items():
            if isinstance(v, float) and math.isnan(v):
                item[k] = ""
                
    return {
        "kpis": kpis,
        "trends": trends
    }

@router.get("/{scorecard_id}/pivot")
def get_pivot(scorecard_id: str):
    sc = get_scorecard(scorecard_id)
    df = sc.get("df")
    schema = sc.get("schema")
    
    if not schema.get("dimension") or not schema.get("identifier") or not schema.get("rag_status"):
        return {"data": []}
        
    rule_col = "source_system_rule_name" if "source_system_rule_name" in df.columns else schema["identifier"][0] 
    rag_col = schema["rag_status"][0]
    
    cde_col = "immutable_cde" if "immutable_cde" in df.columns else schema["dimension"][0]
    sys_col = "system" if "system" in df.columns else (schema["dimension"][1] if len(schema["dimension"]) > 1 else cde_col)
    
    if cde_col in df.columns and sys_col in df.columns and rag_col in df.columns and rule_col in df.columns:
        grouped = df.groupby([cde_col, sys_col, rag_col])[rule_col].nunique().reset_index(name='count')
        return {"data": grouped.to_dict(orient="records")}
    return {"data": []}

@router.post("/{scorecard_id}/filtered_kpis")
async def get_filtered_kpis(scorecard_id: str, request: Request):
    sc = get_scorecard(scorecard_id)
    df = sc.get("df").copy()
    schema = sc.get("schema")
    
    body = await request.json()
    filters = body.get("filters", {})
    
    for k, v in filters.items():
        if k in df.columns and v:
            if isinstance(v, list):
                if 'All' not in v and 'ALL' not in v:
                    df = df[df[k].isin(v)]
            else:
                if v != 'All' and v != 'ALL':
                    df = df[df[k] == v]
                
    kpis = {
        "total_rules": 0,
        "failed_rules": 0,
        "pass_rate": 0
    }
    
    kri_data = calculate_kri(df, schema)
    if kri_data:
        kpis["total_rules"] = kri_data.get("total", len(df["rule_name"].dropna().unique()) if "rule_name" in df.columns else len(df))
        kpis["failed_rules"] = kri_data.get("failed", 0)
        kpis["pass_rate"] = (1 - kri_data.get("kri", 0)) * 100
        
    rag_dist = {}
    if schema and schema.get("rag_status"):
        rag_col = schema["rag_status"][0]
        rag_dist = df[rag_col].value_counts().to_dict()
        
    return {"kpis": kpis, "rag_distribution": rag_dist}
