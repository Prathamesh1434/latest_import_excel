from fastapi import APIRouter
from backend.services.scorecard_registry import list_all

router = APIRouter()

@router.get("/health")
def health_check():
    scorecards = list_all()
    return {
        "status": "ok",
        "service": "B&I CDE Intelligence Platform",
        "scorecard_count": len(scorecards)
    }

@router.get("/scorecards/list")
def list_scorecards():
    scorecards = list_all()
    res = []
    for sid, data in scorecards.items():
        res.append({
            "scorecard_id": sid,
            "display_name": data.get("display_name"),
            "legal_entity": data.get("legal_entity"),
            "kri_id": data.get("kri_id"),
            "row_count": data.get("row_count"),
            "col_count": data.get("col_count"),
            "onboarded_at": data.get("onboarded_at")
        })
    return res
