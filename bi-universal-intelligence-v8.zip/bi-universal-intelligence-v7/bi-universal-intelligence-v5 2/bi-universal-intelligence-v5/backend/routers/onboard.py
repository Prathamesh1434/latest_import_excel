from fastapi import APIRouter, File, UploadFile, Form, HTTPException
from typing import List
from datetime import datetime
import os
import shutil

from backend.services.scorecard_registry import add_scorecard
from backend.services.data_service import process_scorecard_data
from backend.services.document_service import parse_and_index_documents

router = APIRouter()

@router.post("/onboard")
async def onboard_scorecard(
    scorecard_id: str = Form(...),
    display_name: str = Form(...),
    legal_entity: str = Form("ALL"),
    kri_id: str = Form(""),
    data_file: UploadFile = File(...),
    doc_files: List[UploadFile] = File([])
):
    try:
        # Save files to uploads folder
        upload_dir = f"uploads/{scorecard_id}"
        os.makedirs(upload_dir, exist_ok=True)
        
        # Read and save data file
        data_content = await data_file.read()
        with open(f"{upload_dir}/{data_file.filename}", "wb") as f:
            f.write(data_content)
            
        # Process Data
        df, schema, visual_config = process_scorecard_data(data_content, data_file.filename)
        
        # Process Documents
        docs_parsed = []
        for doc in doc_files:
            if getattr(doc, "filename", None):
                content = await doc.read()
                docs_parsed.append((doc.filename, content))
                # Optional: save it
                os.makedirs(f"{upload_dir}/docs", exist_ok=True)
                with open(f"{upload_dir}/docs/{doc.filename}", "wb") as f:
                    f.write(content)
                    
        vectorizer, chunks = parse_and_index_documents(docs_parsed)
        
        # Register Scorecard
        scorecard_data = {
            "scorecard_id": scorecard_id,
            "display_name": display_name,
            "legal_entity": legal_entity,
            "kri_id": kri_id,
            "df": df,
            "schema": schema,
            "visual_config": visual_config,
            "doc_index": vectorizer,
            "doc_chunks": chunks,
            "onboarded_at": datetime.utcnow().isoformat(),
            "row_count": len(df),
            "col_count": len(df.columns)
        }
        
        add_scorecard(scorecard_id, scorecard_data)
        
        return {
            "status": "success",
            "scorecard_id": scorecard_id,
            "schema_detected": schema,
            "visual_config": visual_config,
            "row_count": len(df),
            "col_count": len(df.columns)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Onboarding failed: {str(e)}")
