from fastapi import APIRouter, Request
from backend.services.scorecard_registry import get_scorecard
from backend.services.query_engine import query_scorecard

router = APIRouter()

@router.post("/query")
async def chat_query(request: Request):
    body = await request.json()
    scorecard_id = body.get("scorecard_id")
    question = body.get("question")
    
    if not scorecard_id or not question:
        return {"reply": "Please provide scorecard_id and question.", "chart": None, "docs": []}
        
    sc = get_scorecard(scorecard_id)
    result = query_scorecard(sc, question)
    return result
