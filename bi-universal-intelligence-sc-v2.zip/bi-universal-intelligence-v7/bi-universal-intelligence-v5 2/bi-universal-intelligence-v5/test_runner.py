import os
import io
import json
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def run_tests():
    print("--- Starting Deep Tests ---")
    
    # 1. Health check
    res = client.get("/health")
    assert res.status_code == 200
    print("[OK] Health check passed.")
    
    # 2. Create dummy CSV data
    csv_data = "rule_id,business_area,exceptions,volume,domain,rag_status,threshold,report_name,date\n" \
               "r1,AreaA,0,100,DomainX,Dark Green,0.05,Rpt1,2026-01-01\n" \
               "r2,AreaB,10,100,DomainY,Red,0.05,Rpt2,2026-01-02\n" \
               "r3,AreaC,2,100,DomainZ,Green,0.05,Rpt1,2026-01-03\n"
               
    dummy_doc = "This is a techno functional document for AreaA. The system processes exceptions daily."
    
    # 3. Test Onboarding
    response = client.post(
        "/scorecards/onboard",
        data={
            "scorecard_id": "test-cde",
            "display_name": "Test Dashboard",
            "legal_entity": "CGML",
            "kri_id": "K1"
        },
        files={
            "data_file": ("data.csv", io.BytesIO(csv_data.encode("utf-8")), "text/csv"),
            "doc_files": ("doc1.txt", io.BytesIO(dummy_doc.encode("utf-8")), "text/plain")
        }
    )
    if response.status_code != 200:
        print(f"[FAIL] Onboard failed: {response.text}")
        return 
    data = response.json()
    assert data["status"] == "success"
    print("[OK] Onboard successful. Schema detected:", data["schema_detected"])
    
    # 4. Test Summary & KRI
    res = client.get("/data/test-cde/summary")
    assert res.status_code == 200
    print("[OK] Summary:", res.json())
    
    res = client.get("/data/test-cde/kri")
    assert res.status_code == 200
    print("[OK] KRI:", res.json())
    
    # 5. Test Filters
    res = client.get("/data/test-cde/filters")
    assert res.status_code == 200
    print("[OK] Filters:", res.json())
    
    # 6. Test Data Query
    res = client.post("/data/test-cde/query", json={"filters": {"business_area": ["AreaA"]}})
    assert res.status_code == 200
    q_data = res.json()
    assert len(q_data) == 1
    assert q_data[0]["business_area"] == "AreaA"
    print("[OK] Data query successful.", q_data)
    
    # 7. Test Document Indexing
    res = client.post("/docs/test-cde/search", json={"query": "techno functional"})
    assert res.status_code == 200
    docs = res.json()
    assert len(docs["results"]) > 0
    print("[OK] Document semantic search successful. Top match:", docs["results"][0]["doc_name"])
    
    # 8. Test Chat (Mocked Vertex)
    res = client.post("/chat/query", json={"scorecard_id": "test-cde", "question": "What is the KRI?"})
    assert res.status_code == 200
    chat_res = res.json()
    assert "reply" in chat_res
    print("[OK] Chat query executed successfully:", chat_res["reply"])

    print("--- All tests passed! ---")

if __name__ == "__main__":
    run_tests()
