"""End-to-end test of all critical features."""
import requests
import json

API = "http://localhost:8000"
HEADERS = {"X-User-ID": "PG23137", "Content-Type": "application/json"}

def test_health():
    print("=== HEALTH ===")
    r = requests.get(f"{API}/health/")
    d = r.json()
    assert d["status"] == "ok", "Health check failed"
    print(f"  Status: {d['status']}, Scorecards: {d['scorecard_count']}, Services: {len(d['services'])}")
    print("  PASS")

def test_login():
    print("\n=== LOGIN ===")
    r = requests.post(f"{API}/auth/login", json={"wwid": "PG23137"})
    d = r.json()
    assert d["role"] == "admin", "Expected admin role"
    print(f"  User: {d['name']}, Role: {d['role']}, Entity: {d['entity']}")

    # Test invalid login
    r2 = requests.post(f"{API}/auth/login", json={"wwid": "INVALID"})
    assert r2.status_code == 403, "Expected 403 for invalid user"
    print("  Invalid login correctly rejected")
    print("  PASS")

def test_onboard():
    print("\n=== ONBOARD ===")
    with open("test_data.csv", "rb") as f:
        r = requests.post(f"{API}/scorecards/onboard",
            data={"scorecard_id": "test-cde", "display_name": "CDE Test Scorecard",
                  "legal_entity": "CGML", "kri_id": "K1"},
            files={"data_file": ("test_data.csv", f, "text/csv")},
            headers={"X-User-ID": "PG23137"})
    assert r.status_code == 200, f"Onboard failed: {r.text}"
    d = r.json()
    print(f"  Status: {d['status']}")
    print(f"  Rows: {d['total_rows']}, Cols: {d['total_cols']}")
    print(f"  Anomalies: {len(d.get('anomalies', []))}")
    print(f"  Questions: {d.get('questions', [])[:3]}")
    print(f"  Schema dimensions: {d.get('schema_detected', {}).get('dimension', [])}")
    print(f"  Narrative: {d.get('narrative', '')[:100]}")
    print("  PASS")

def test_scorecards_list():
    print("\n=== SCORECARDS LIST ===")
    r = requests.get(f"{API}/scorecards/list")
    d = r.json()
    assert len(d) >= 1, "Expected at least 1 scorecard"
    print(f"  Count: {len(d)}")
    for sc in d:
        print(f"  - {sc['scorecard_id']}: {sc['display_name']} ({sc['row_count']}r)")
    print("  PASS")

def test_chat_t1():
    print("\n=== CHAT TIER 1 (PANDAS) ===")
    r = requests.post(f"{API}/chat/query",
        json={"scorecard_id": "test-cde", "question": "how many rules failed?", "mode": "auto"},
        headers=HEADERS)
    d = r.json()
    print(f"  Tier: {d['tier']} ({d['tier_label']})")
    print(f"  Confidence: {d['confidence']}")
    print(f"  Latency: {d['latency_ms']}ms")
    print(f"  Reply: {d['reply'][:150]}")
    assert d["tier"] == 1, f"Expected T1, got T{d['tier']}"
    print("  PASS")

def test_chat_t1_distribution():
    print("\n=== CHAT T1: RAG DISTRIBUTION ===")
    r = requests.post(f"{API}/chat/query",
        json={"scorecard_id": "test-cde", "question": "show rag status distribution", "mode": "auto"},
        headers=HEADERS)
    d = r.json()
    print(f"  Tier: {d['tier']} ({d['tier_label']})")
    print(f"  Reply: {d['reply'][:200]}")
    assert d["tier"] == 1, f"Expected T1, got T{d['tier']}"
    print("  PASS")

def test_chat_t1_forced():
    print("\n=== CHAT T1 FORCED ===")
    r = requests.post(f"{API}/chat/query",
        json={"scorecard_id": "test-cde", "question": "which system has the most exceptions?", "mode": "t1"},
        headers=HEADERS)
    d = r.json()
    print(f"  Tier: {d['tier']} ({d['tier_label']})")
    print(f"  Reply: {d['reply'][:150]}")
    print("  PASS")

def test_filters():
    print("\n=== FILTERS ===")
    r = requests.get(f"{API}/data/test-cde/filters")
    d = r.json()
    print(f"  Filter columns: {list(d.keys())}")
    for k, v in d.items():
        print(f"  - {k}: {v[:5]}{'...' if len(v)>5 else ''}")
    assert len(d) > 0, "Expected at least 1 filter"
    print("  PASS")

def test_data_query():
    print("\n=== DATA QUERY (filter Red) ===")
    r = requests.post(f"{API}/data/test-cde/query",
        json={"filters": {"rag_status": ["Red"]}, "limit": 5},
        headers=HEADERS)
    d = r.json()
    print(f"  Rows returned: {len(d)}")
    if d:
        print(f"  First row keys: {list(d[0].keys())}")
    assert len(d) > 0, "Expected Red rows"
    print("  PASS")

def test_chat_history():
    print("\n=== CHAT HISTORY ===")
    r = requests.get(f"{API}/chat/history/test-cde",
        headers={"X-User-ID": "PG23137"})
    d = r.json()
    print(f"  History entries: {len(d)}")
    print("  PASS")

def test_persistence():
    print("\n=== DISK PERSISTENCE ===")
    import os
    storage_dir = os.path.join(os.path.dirname(__file__) if '__file__' in dir() else '.', "storage", "test-cde")
    files = os.listdir(storage_dir) if os.path.exists(storage_dir) else []
    print(f"  Storage dir: {storage_dir}")
    print(f"  Files: {files}")
    assert "data.csv" in files, "data.csv not persisted"
    assert "metadata.json" in files, "metadata.json not persisted"
    print("  PASS")


if __name__ == "__main__":
    print("B&I CDE Intelligence Platform — End-to-End Tests\n")
    tests = [
        test_health,
        test_login,
        test_onboard,
        test_scorecards_list,
        test_chat_t1,
        test_chat_t1_distribution,
        test_chat_t1_forced,
        test_filters,
        test_data_query,
        test_chat_history,
        test_persistence,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"  FAIL: {e}")
            failed += 1

    print(f"\n{'='*40}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    print(f"{'='*40}")
