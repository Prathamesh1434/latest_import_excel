# B&I CDE Intelligence Platform v7.0

Enterprise-grade standalone data intelligence platform for CDE exception scorecards.
Zero Tableau dependency — upload CSV/Excel, get instant AI-powered insights.

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                    dashboard.html (Vanilla JS)               │
│  ┌─────────┐  ┌──────────────────┐  ┌─────────────────────┐ │
│  │  Left    │  │  Centre Panel    │  │  Right Panel        │ │
│  │  Sidebar │  │  Overview/KPIs   │  │  Intelligence Chat  │ │
│  │  260px   │  │  Data/Schema     │  │  3-Tier Engine      │ │
│  │          │  │  Compare         │  │  360px              │ │
│  └─────────┘  └──────────────────┘  └─────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
                           │ HTTP + SSE
┌──────────────────────────┴───────────────────────────────────┐
│              FastAPI Backend (port 8000)                      │
│  ┌─────────┐ ┌────────┐ ┌───────┐ ┌──────┐ ┌────────┐      │
│  │ auth.py │ │onboard │ │data.py│ │chat  │ │docs.py │      │
│  │ RBAC    │ │ SSE    │ │export │ │3-tier│ │TF-IDF  │      │
│  └─────────┘ └────────┘ └───────┘ └──────┘ └────────┘      │
│                    │                                         │
│  ┌──────────────────────────────────────────────────────┐   │
│  │            scorecard_registry.py                      │   │
│  │    In-Memory Dict + Disk Persistence (storage/)       │   │
│  └──────────────────────────────────────────────────────┘   │
│                    │                                         │
│  ┌────────────┐ ┌──────────────┐ ┌────────────────────┐    │
│  │column_     │ │query_engine  │ │vertex_service.py   │    │
│  │classifier  │ │T1→T2→T3     │ │Gemini (via COIN)   │    │
│  └────────────┘ └──────────────┘ └────────────────────┘    │
└──────────────────────────────────────────────────────────────┘
                           │
┌──────────────────────────┴───────────────────────────────────┐
│                    storage/                                    │
│  ┌─────────────────────────────────────────────────────┐     │
│  │ {scorecard_id}/                                      │     │
│  │   data.csv        ← uploaded data                    │     │
│  │   metadata.json   ← config, schema, KPIs, anomalies │     │
│  │   docs/           ← uploaded documents               │     │
│  │   index/          ← TF-IDF vectorizer + matrix       │     │
│  │   chat_history/   ← per-user chat logs               │     │
│  └─────────────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# 1. Install dependencies
pip install fastapi uvicorn pandas scikit-learn openpyxl python-multipart python-dotenv

# 2. Start backend
uvicorn backend.main:app --port 8000 --reload

# 3. Start frontend (same directory)
python -m http.server 8080

# 4. Open browser
# http://localhost:8080/dashboard.html
```

## Login

- Default admin: **PG23137** (Prathmesh Gayakwad)
- Default analyst: **HK12345** (Hasmukh Katechiya)  
- Default viewer: **VS87309** (Sundararaman V)
- Configure in `users.json`

## Features

### Core
- **Dynamic Onboarding**: Upload CSV/Excel → auto-detect columns, build schema, generate KPIs
- **Disk Persistence**: Scorecards survive server restarts (`storage/` directory)
- **3-Tier Chat Engine**:
  - Tier 1 (PANDAS): Instant data queries — counts, filters, aggregations ($0, <50ms)
  - Tier 2 (SEMANTIC): TF-IDF document search — definitions, processes ($0, <100ms)
  - Tier 3 (GEMINI): AI-powered analysis — narratives, charts (~$0.002, 1-3s)
- **Role-Based Access**: admin / analyst / viewer with UI + API enforcement

### Intelligence
- **Anomaly Detection**: Auto-detect failures, outliers on upload
- **Smart Starter Questions**: Generated from actual data columns/values
- **Cross-Scorecard Comparison**: Side-by-side metrics when 2+ scorecards onboarded
- **Chat History**: Persisted per user per scorecard, survives restarts

### UI
- **Enterprise Design System**: Navy headers, Inter/JetBrains Mono typography
- **Dark Mode**: Toggle with localStorage persistence
- **SSE Progress**: Real-time onboarding steps (not fake animations)
- **Keyboard Shortcuts**: Ctrl+K (search), Ctrl+/ (chat), Escape (close), Ctrl+E (export)
- **Export**: CSV from data table, Chat as .txt

## File Structure

```
bi-universal-intelligence-v5/
├── dashboard.html          ← Frontend (single file, vanilla JS/CSS)
├── dashboard_hub.html      ← Original design reference
├── users.json              ← User/role configuration
├── backend/
│   ├── main.py             ← FastAPI app + lifespan + SSE
│   ├── config.py           ← Environment config + logging
│   ├── routers/
│   │   ├── api.py          ← Health + scorecard listing
│   │   ├── auth.py         ← Login + RBAC
│   │   ├── onboard.py      ← File upload + processing + SSE progress
│   │   ├── data.py         ← Query + filters + export + compare
│   │   ├── chat.py         ← 3-tier chat + history
│   │   └── docs.py         ← Document search
│   └── services/
│       ├── scorecard_registry.py  ← In-memory + disk persistence
│       ├── query_engine.py        ← 3-tier routing (T1→T2→T3)
│       ├── column_classifier.py   ← Auto column detection
│       ├── data_service.py        ← DataFrame processing
│       ├── document_service.py    ← TF-IDF indexing
│       ├── visual_generator.py    ← Chart config generator
│       ├── vertex_service.py      ← Gemini wrapper
│       └── vertex_util.py         ← Mock (replace with COIN auth)
└── storage/                       ← Persistent scorecard data
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Service health + status dots |
| POST | `/auth/login` | WWID login |
| GET | `/scorecards/list` | List all scorecards |
| POST | `/scorecards/onboard` | Upload + onboard scorecard |
| DELETE | `/scorecards/{id}` | Delete scorecard |
| POST | `/scorecards/{id}/refresh` | Re-read data from disk |
| GET | `/data/{id}/summary` | Scorecard summary |
| GET | `/data/{id}/filters` | Dynamic filter options |
| POST | `/data/{id}/query` | Query with filters |
| GET | `/data/{id}/export` | Download CSV |
| GET | `/data/compare` | Compare scorecards |
| POST | `/chat/query` | 3-tier chat query |
| GET | `/chat/history/{id}` | Chat history |
| GET | `/progress/{id}` | SSE onboarding progress |

## Production Setup

Replace `backend/services/vertex_util.py` with your COIN M2M authenticated version:
```python
from your_internal_package import llm, embeddings
```

Set environment variables in `.env`:
```
GOOGLE_PROJECT_ID=your-project
VERTEX_AUTH_MODE=coin
COIN_URL=https://...
COIN_CLIENT_ID=...
COIN_CLIENT_SECRET=...
```
