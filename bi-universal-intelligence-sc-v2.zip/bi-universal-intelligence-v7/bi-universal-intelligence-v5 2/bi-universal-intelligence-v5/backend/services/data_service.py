import pandas as pd
import os
from io import BytesIO
from typing import Tuple, Dict, Any

from backend.services.column_classifier import classify_columns
from backend.services.visual_generator import generate_visual_config

def load_data(file_content: bytes, filename: str) -> pd.DataFrame:
    """Loads CSV or Excel data into a pandas DataFrame."""
    try:
        if filename.endswith(".csv"):
            return pd.read_csv(BytesIO(file_content))
        elif filename.endswith((".xls", ".xlsx")):
            return pd.read_excel(BytesIO(file_content))
        else:
            raise ValueError("Unsupported file format. Please upload CSV or Excel.")
    except Exception as e:
        raise ValueError(f"Error loading file: {e}")

def process_scorecard_data(file_content: bytes, filename: str) -> Tuple[pd.DataFrame, Dict[str, Any], Dict[str, Any]]:
    """Loads data, detects schema, and generates visual configurations."""
    df = load_data(file_content, filename)
    
    # Fill NA for text columns
    for col in df.columns:
        if pd.api.types.is_string_dtype(df[col]):
            df[col] = df[col].fillna("")
            
    schema = classify_columns(df)
    visual_config = generate_visual_config(df, schema)
    
    return df, schema, visual_config
    
def calculate_kri(df: pd.DataFrame, schema: Dict[str, list]) -> Dict[str, Any]:
    """Calculate KRI generic function."""
    res = {}
    if schema.get("rag_status") and schema.get("identifier"):
        rag_col = schema["rag_status"][0]
        id_col = schema["identifier"][0]
        total_rules = df[id_col].nunique()
        failed_rules = df[df[rag_col].str.lower() == 'red'][id_col].nunique()
        res['kri'] = failed_rules / total_rules if total_rules > 0 else 0
        res['failed'] = failed_rules
        res['total']  = total_rules
    return res
