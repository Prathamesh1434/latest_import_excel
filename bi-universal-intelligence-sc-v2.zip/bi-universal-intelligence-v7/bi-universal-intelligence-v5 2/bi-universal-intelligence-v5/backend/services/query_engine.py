"""
services/query_engine.py — v7

Full 3-tier query routing engine:
  Tier 1 (DIRECT/PANDAS)  — $0, <50ms  — pattern-match + pandas ops
  Tier 2 (SEMANTIC/TF-IDF) — $0, <100ms — cosine similarity on indexed docs
  Tier 3 (LLM/GEMINI)     — ~$0.002, 1-3s — Vertex AI with T1+T2 context

Routing: AUTO mode tries T1 → T2 → T3 in order.
Forced mode skips directly to the requested tier.
"""
import time
import re
import json
import logging
import pandas as pd
from typing import Dict, Any, List, Optional, Tuple

log = logging.getLogger("query_engine")

# ══════ TIER 1: PANDAS DIRECT ══════

T1_KEYWORDS = {
    "count": ["how many", "count", "total", "number of"],
    "filter": ["list", "show", "filter", "which", "where"],
    "rank": ["top", "bottom", "highest", "lowest", "max", "min", "best", "worst"],
    "aggregate": ["sum", "average", "mean", "avg", "group by", "group"],
    "distribution": ["distribution", "breakdown", "split", "rag status", "pass rate"],
}


def _detect_t1_intent(question: str) -> Optional[str]:
    """Detect if the question can be answered by pandas. Returns intent or None."""
    q = question.lower().strip()
    for intent, keywords in T1_KEYWORDS.items():
        for kw in keywords:
            if kw in q:
                return intent
    return None


def _extract_column_ref(question: str, columns: List[str]) -> Optional[str]:
    """Try to find a column name referenced in the question."""
    q = question.lower()
    for col in columns:
        if col.lower() in q or col.lower().replace("_", " ") in q:
            return col
    return None


def _extract_value_ref(question: str, df: pd.DataFrame, col: str) -> Optional[str]:
    """Try to find a specific value from a column referenced in the question."""
    q = question.lower()
    try:
        uniques = df[col].dropna().unique()
        for val in uniques:
            if str(val).lower() in q:
                return str(val)
    except Exception:
        pass
    return None


def try_pandas_query(question: str, df: pd.DataFrame, schema: Dict) -> Optional[Dict[str, Any]]:
    """
    Attempt to answer the question using pandas operations.
    Returns result dict with reply, data, confidence — or None if can't answer.
    """
    if df is None or df.empty:
        return None

    t0 = time.time()
    q = question.lower().strip()
    intent = _detect_t1_intent(question)
    if intent is None:
        return None

    columns = list(df.columns)
    rag_cols = schema.get("rag_status", [])
    id_cols = schema.get("identifier", [])
    dim_cols = schema.get("dimension", [])
    measure_cols = schema.get("measure", [])

    reply = ""
    table_data = None
    confidence = 0.85

    try:
        # ── COUNT questions ──
        if intent == "count":
            # "how many rules failed" / "how many rows" / "total rules"
            if any(w in q for w in ["fail", "red", "breach"]):
                if rag_cols:
                    rag_col = rag_cols[0]
                    fail_count = len(df[df[rag_col].str.lower().isin(["red"])])
                    total = len(df)
                    reply = f"There are **{fail_count}** failed (Red) records out of **{total}** total records."
                    confidence = 0.95
                else:
                    return None
            elif any(w in q for w in ["pass", "green", "dark green"]):
                if rag_cols:
                    rag_col = rag_cols[0]
                    pass_count = len(df[df[rag_col].str.lower().isin(["green", "dark green"])])
                    total = len(df)
                    reply = f"There are **{pass_count}** passing (Green/Dark Green) records out of **{total}** total."
                    confidence = 0.95
                else:
                    return None
            elif any(w in q for w in ["rule", "record", "row", "total"]):
                col_ref = _extract_column_ref(question, columns)
                if col_ref:
                    unique_count = df[col_ref].nunique()
                    reply = f"There are **{unique_count}** unique values in `{col_ref}`."
                else:
                    reply = f"The dataset contains **{len(df)}** total records across **{len(columns)}** columns."
                confidence = 0.90
            else:
                col_ref = _extract_column_ref(question, columns)
                if col_ref:
                    unique_count = df[col_ref].nunique()
                    reply = f"There are **{unique_count}** unique values in `{col_ref}`."
                    confidence = 0.85
                else:
                    reply = f"Total records: **{len(df)}**. Total columns: **{len(columns)}**."
                    confidence = 0.80

        # ── FILTER / LIST questions ──
        elif intent == "filter":
            col_ref = _extract_column_ref(question, columns)
            if col_ref:
                val_ref = _extract_value_ref(question, df, col_ref)
                if val_ref:
                    filtered = df[df[col_ref].astype(str).str.lower() == val_ref.lower()]
                    reply = f"Found **{len(filtered)}** records where `{col_ref}` = '{val_ref}'."
                    table_data = filtered.head(20).fillna("").to_dict(orient="records")
                    confidence = 0.92
                else:
                    vals = df[col_ref].value_counts().head(10).to_dict()
                    reply = f"Top values in `{col_ref}`: " + ", ".join(f"**{k}** ({v})" for k, v in vals.items())
                    confidence = 0.85
            elif any(w in q for w in ["fail", "red"]) and rag_cols:
                rag_col = rag_cols[0]
                fails = df[df[rag_col].str.lower() == "red"]
                reply = f"Found **{len(fails)}** failing (Red) records."
                table_data = fails.head(20).fillna("").to_dict(orient="records")
                confidence = 0.90
            else:
                return None

        # ── RANK questions ──
        elif intent == "rank":
            col_ref = _extract_column_ref(question, measure_cols + columns)
            if col_ref and pd.api.types.is_numeric_dtype(df[col_ref]):
                is_top = any(w in q for w in ["top", "highest", "max", "best"])
                n = 5
                nums = re.findall(r"\d+", question)
                if nums:
                    n = min(int(nums[0]), 20)
                sorted_df = df.sort_values(col_ref, ascending=not is_top).head(n)
                direction = "highest" if is_top else "lowest"
                reply = f"**{direction.capitalize()} {n}** records by `{col_ref}`:"
                table_data = sorted_df.fillna("").to_dict(orient="records")
                confidence = 0.90
            else:
                return None

        # ── AGGREGATE questions ──
        elif intent == "aggregate":
            col_ref = _extract_column_ref(question, measure_cols)
            group_col = _extract_column_ref(question, dim_cols)
            if col_ref and group_col:
                if "sum" in q:
                    agg = df.groupby(group_col)[col_ref].sum().reset_index()
                elif any(w in q for w in ["average", "mean", "avg"]):
                    agg = df.groupby(group_col)[col_ref].mean().reset_index()
                else:
                    agg = df.groupby(group_col)[col_ref].sum().reset_index()
                reply = f"Aggregation of `{col_ref}` grouped by `{group_col}`:"
                table_data = agg.head(20).to_dict(orient="records")
                confidence = 0.88
            elif col_ref:
                total = df[col_ref].sum()
                avg = df[col_ref].mean()
                reply = f"`{col_ref}`: Sum = **{total:,.2f}**, Average = **{avg:,.2f}**, Count = **{df[col_ref].count()}**"
                confidence = 0.85
            else:
                return None

        # ── DISTRIBUTION questions ──
        elif intent == "distribution":
            if rag_cols:
                rag_col = rag_cols[0]
                dist = df[rag_col].value_counts().to_dict()
                total = sum(dist.values())
                reply = "**RAG Status Distribution:**\n" + "\n".join(
                    f"- {k}: **{v}** ({v/total*100:.1f}%)" for k, v in dist.items()
                )
                confidence = 0.95
            else:
                col_ref = _extract_column_ref(question, dim_cols + columns)
                if col_ref:
                    dist = df[col_ref].value_counts().head(10).to_dict()
                    reply = f"**Distribution of `{col_ref}`:**\n" + "\n".join(
                        f"- {k}: **{v}**" for k, v in dist.items()
                    )
                    confidence = 0.85
                else:
                    return None

        else:
            return None

        ms = int((time.time() - t0) * 1000)
        log.info(f"T1 PANDAS: intent={intent}, conf={confidence:.2f}, {ms}ms")

        return {
            "tier": 1,
            "tier_label": "DIRECT",
            "reply": reply,
            "table_data": table_data,
            "chart": None,
            "confidence": confidence,
            "latency_ms": ms,
            "data_source": f"pandas ({len(df)} rows)",
            "model_used": "pandas",
        }

    except Exception as e:
        log.warning(f"T1 pandas query failed: {e}")
        return None


# ══════ TIER 2: SEMANTIC SEARCH ══════

T2_KEYWORDS = [
    "what is", "how does", "explain", "process", "architecture",
    "steps", "logic", "formula", "calculation", "workflow",
    "module", "define", "definition", "document", "policy",
    "procedure", "guideline", "standard", "requirement",
]


def _detect_t2_intent(question: str) -> bool:
    """Check if question looks like a documentation/semantic query."""
    q = question.lower()
    return any(kw in q for kw in T2_KEYWORDS)


def try_semantic_search(question: str, scorecard: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Attempt to answer using TF-IDF indexed documents.
    Returns result dict or None.
    """
    from backend.services.document_service import search_documents

    vectorizer = scorecard.get("doc_index")
    chunks = scorecard.get("doc_chunks", [])

    if not vectorizer or not chunks:
        return None

    t0 = time.time()

    results = search_documents(question, vectorizer, chunks)

    if not results or results[0].get("score", 0) < 0.1:
        return None

    ms = int((time.time() - t0) * 1000)
    top_score = results[0]["score"]

    reply_parts = []
    for i, r in enumerate(results[:3], 1):
        reply_parts.append(
            f"**Source {i}:** `{r['doc_name']}` (Section: {r['section']}, Relevance: {r['score']:.0%})\n{r['content'][:300]}"
        )

    reply = "\n\n".join(reply_parts)
    confidence = min(top_score + 0.3, 0.95)

    log.info(f"T2 SEMANTIC: top_score={top_score:.3f}, conf={confidence:.2f}, {ms}ms, {len(results)} results")

    return {
        "tier": 2,
        "tier_label": "SEMANTIC",
        "reply": reply,
        "table_data": None,
        "chart": None,
        "confidence": confidence,
        "latency_ms": ms,
        "data_source": f"TF-IDF ({len(chunks)} chunks)",
        "model_used": "scikit-learn TfidfVectorizer",
        "docs": results,
    }


# ══════ TIER 3: LLM (GEMINI) ══════

def try_llm_query(question: str, scorecard: Dict[str, Any], t1_context: Optional[str] = None, t2_context: Optional[str] = None) -> Dict[str, Any]:
    """
    Call Vertex AI Gemini with context from T1 and T2.
    Always returns a result (this is the fallback tier).
    """
    from backend.services.vertex_service import chat as vertex_chat

    df = scorecard.get("df")
    schema = scorecard.get("schema", {})

    t0 = time.time()

    # Build context
    preview = ""
    if df is not None:
        preview = df.head(5).to_csv(index=False)

    context_parts = [f"Data Schema: {json.dumps(schema)}"]
    context_parts.append(f"Data Preview (first 5 rows):\n{preview}")

    if t1_context:
        context_parts.append(f"Pandas Analysis Result:\n{t1_context}")
    if t2_context:
        context_parts.append(f"Relevant Documentation:\n{t2_context}")

    system_prompt = f"""You are an AI assistant for the B&I CDE Intelligence Platform.
You answer questions about data quality scorecards, KRIs, and CDE exception reports.

{chr(10).join(context_parts)}

User Question: {question}

Provide a helpful, precise answer based on the data and documentation above."""

    try:
        reply, chart, in_tok, out_tok, resp_ms = vertex_chat(
            system_prompt,
            messages=[{"role": "user", "content": question}]
        )
        ms = int((time.time() - t0) * 1000)

        log.info(f"T3 GEMINI: in={in_tok} out={out_tok}, {ms}ms")

        return {
            "tier": 3,
            "tier_label": "LLM",
            "reply": reply,
            "table_data": None,
            "chart": chart,
            "confidence": 0.75,
            "latency_ms": ms,
            "data_source": f"Vertex AI Gemini (in={in_tok}, out={out_tok})",
            "model_used": "gemini-1.5-pro",
        }

    except Exception as e:
        ms = int((time.time() - t0) * 1000)
        log.error(f"T3 Gemini failed: {e}")
        return {
            "tier": 3,
            "tier_label": "LLM",
            "reply": f"⚠️ Gemini AI is not available: {str(e)}. Please ensure vertex_util.py is configured with COIN auth.",
            "table_data": None,
            "chart": None,
            "confidence": 0.0,
            "latency_ms": ms,
            "data_source": "Vertex AI (unavailable)",
            "model_used": "gemini-1.5-pro (offline)",
        }


# ══════ MAIN ROUTER ══════

def query_scorecard(scorecard: Dict[str, Any], question: str, mode: str = "auto") -> Dict[str, Any]:
    """
    Route a question through the 3-tier engine.

    mode: 'auto' | 't1' | 't2' | 't3'
    - auto: tries T1 → T2 → T3
    - t1/t2/t3: forces that specific tier
    """
    df = scorecard.get("df")
    schema = scorecard.get("schema", {})

    # ── Forced mode ──
    if mode == "t1":
        result = try_pandas_query(question, df, schema)
        if result:
            return result
        return {
            "tier": 1, "tier_label": "DIRECT",
            "reply": "Could not answer this question using pandas. Try AUTO mode for better results.",
            "table_data": None, "chart": None,
            "confidence": 0.0, "latency_ms": 0,
            "data_source": "pandas", "model_used": "pandas",
        }

    if mode == "t2":
        result = try_semantic_search(question, scorecard)
        if result:
            return result
        return {
            "tier": 2, "tier_label": "SEMANTIC",
            "reply": "No relevant documents found. Try uploading documentation files when onboarding.",
            "table_data": None, "chart": None,
            "confidence": 0.0, "latency_ms": 0,
            "data_source": "TF-IDF", "model_used": "scikit-learn",
        }

    if mode == "t3":
        return try_llm_query(question, scorecard)

    # ── AUTO mode: T1 → T2 → T3 ──
    # Try Tier 1 first
    t1_result = try_pandas_query(question, df, schema)
    if t1_result and t1_result["confidence"] > 0.7:
        log.info("AUTO: routed to T1 (pandas)")
        return t1_result

    # Try Tier 2
    if _detect_t2_intent(question):
        t2_result = try_semantic_search(question, scorecard)
        if t2_result and t2_result["confidence"] > 0.3:
            log.info("AUTO: routed to T2 (semantic)")
            return t2_result

    # Fall back to Tier 3 with context from T1+T2
    t1_context = t1_result["reply"] if t1_result else None
    t2_result = try_semantic_search(question, scorecard)
    t2_context = t2_result["reply"] if t2_result else None

    log.info("AUTO: routed to T3 (Gemini)")
    return try_llm_query(question, scorecard, t1_context, t2_context)
