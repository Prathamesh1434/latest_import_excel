"""
services/scorecard_registry.py — v7

In-memory registry with full disk persistence.
On onboard: saves DataFrame, metadata, docs, TF-IDF index to storage/.
On startup: main.py calls restore_all_from_disk() to reload everything.
"""
import os
import json
import pickle
import logging
import pandas as pd
from datetime import datetime
from typing import Dict, Any, Optional, List
from pathlib import Path

log = logging.getLogger("scorecard_registry")

STORAGE_DIR = Path(__file__).parent.parent.parent / "storage"

# ══════ IN-MEMORY REGISTRY ══════
_REGISTRY: Dict[str, Dict[str, Any]] = {}


def add_scorecard(scorecard_id: str, data: Dict[str, Any]) -> None:
    """Add a scorecard to the in-memory registry."""
    _REGISTRY[scorecard_id] = data
    log.info(f"Registry: added '{scorecard_id}' ({data.get('row_count', 0)} rows, {data.get('col_count', 0)} cols)")


def get_scorecard(scorecard_id: str) -> Dict[str, Any]:
    """Get a scorecard from the registry. Raises KeyError if not found."""
    if scorecard_id not in _REGISTRY:
        raise KeyError(f"Scorecard '{scorecard_id}' not found in registry.")
    return _REGISTRY[scorecard_id]


def delete_scorecard(scorecard_id: str) -> bool:
    """Remove a scorecard from memory and disk."""
    removed = False
    if scorecard_id in _REGISTRY:
        del _REGISTRY[scorecard_id]
        removed = True
        log.info(f"Registry: removed '{scorecard_id}' from memory")

    # Remove from disk
    sc_dir = STORAGE_DIR / scorecard_id
    if sc_dir.exists():
        import shutil
        shutil.rmtree(sc_dir, ignore_errors=True)
        log.info(f"Registry: removed '{scorecard_id}' from disk")
        removed = True

    return removed


def list_all() -> Dict[str, Dict[str, Any]]:
    """Return the full registry dict."""
    return _REGISTRY


def list_summary() -> List[Dict[str, Any]]:
    """Return a safe summary list (no DataFrames or large objects)."""
    result = []
    for sid, data in _REGISTRY.items():
        result.append({
            "scorecard_id": sid,
            "display_name": data.get("display_name", sid),
            "legal_entity": data.get("legal_entity", "ALL"),
            "kri_id": data.get("kri_id", ""),
            "row_count": data.get("row_count", 0),
            "col_count": data.get("col_count", 0),
            "onboarded_at": data.get("onboarded_at", ""),
            "anomaly_count": data.get("anomaly_count", 0),
            "file_modified": data.get("file_modified", ""),
        })
    return result


# ══════ DISK PERSISTENCE ══════

def persist_to_disk(scorecard_id: str) -> None:
    """Persist a scorecard from memory to storage/{scorecard_id}/."""
    if scorecard_id not in _REGISTRY:
        log.warning(f"Cannot persist '{scorecard_id}': not in registry")
        return

    data = _REGISTRY[scorecard_id]
    sc_dir = STORAGE_DIR / scorecard_id
    sc_dir.mkdir(parents=True, exist_ok=True)

    # 1. Save DataFrame as CSV
    df = data.get("df")
    if df is not None:
        df.to_csv(sc_dir / "data.csv", index=False)

    # 2. Save metadata (everything except df, vectorizer, tfidf_matrix)
    meta = {
        "scorecard_id": scorecard_id,
        "display_name": data.get("display_name", ""),
        "legal_entity": data.get("legal_entity", "ALL"),
        "kri_id": data.get("kri_id", ""),
        "onboarded_at": data.get("onboarded_at", ""),
        "row_count": data.get("row_count", 0),
        "col_count": data.get("col_count", 0),
        "schema": data.get("schema", {}),
        "visual_config": data.get("visual_config", {}),
        "anomalies": data.get("anomalies", []),
        "anomaly_count": data.get("anomaly_count", 0),
        "kpis": data.get("kpis", []),
        "narrative": data.get("narrative", ""),
        "questions": data.get("questions", []),
        "capabilities": data.get("capabilities", {}),
        "file_modified": data.get("file_modified", ""),
        "data_filename": data.get("data_filename", ""),
    }
    with open(sc_dir / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, default=str)

    # 3. Save TF-IDF index
    idx_dir = sc_dir / "index"
    idx_dir.mkdir(exist_ok=True)

    vectorizer = data.get("doc_index")
    if vectorizer is not None:
        with open(idx_dir / "tfidf_vectorizer.pkl", "wb") as f:
            pickle.dump(vectorizer, f)

    tfidf_matrix = data.get("tfidf_matrix")
    if tfidf_matrix is not None:
        with open(idx_dir / "tfidf_matrix.pkl", "wb") as f:
            pickle.dump(tfidf_matrix, f)

    chunks = data.get("doc_chunks", [])
    if chunks:
        with open(idx_dir / "doc_chunks.json", "w", encoding="utf-8") as f:
            json.dump(chunks, f, indent=2)

    log.info(f"Persisted '{scorecard_id}' to {sc_dir}")


def restore_all_from_disk() -> int:
    """Scan storage/ and restore all scorecards into memory. Returns count."""
    if not STORAGE_DIR.exists():
        STORAGE_DIR.mkdir(parents=True, exist_ok=True)
        log.info("Created storage/ directory")
        return 0

    restored = 0
    for sc_dir in STORAGE_DIR.iterdir():
        if not sc_dir.is_dir():
            continue

        scorecard_id = sc_dir.name
        meta_path = sc_dir / "metadata.json"
        data_path = sc_dir / "data.csv"

        if not meta_path.exists():
            log.warning(f"Skipping {scorecard_id}: no metadata.json")
            continue

        try:
            # Load metadata
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)

            # Load DataFrame
            df = None
            if data_path.exists():
                df = pd.read_csv(data_path)
                # Fill NAs for string columns
                for col in df.columns:
                    if pd.api.types.is_string_dtype(df[col]):
                        df[col] = df[col].fillna("")

            # Load TF-IDF index
            vectorizer = None
            tfidf_matrix = None
            chunks = []

            idx_dir = sc_dir / "index"
            if (idx_dir / "tfidf_vectorizer.pkl").exists():
                with open(idx_dir / "tfidf_vectorizer.pkl", "rb") as f:
                    vectorizer = pickle.load(f)
            if (idx_dir / "tfidf_matrix.pkl").exists():
                with open(idx_dir / "tfidf_matrix.pkl", "rb") as f:
                    tfidf_matrix = pickle.load(f)
            if (idx_dir / "doc_chunks.json").exists():
                with open(idx_dir / "doc_chunks.json", "r", encoding="utf-8") as f:
                    chunks = json.load(f)

            # Reconstruct registry entry
            entry = {
                "scorecard_id": scorecard_id,
                "display_name": meta.get("display_name", scorecard_id),
                "legal_entity": meta.get("legal_entity", "ALL"),
                "kri_id": meta.get("kri_id", ""),
                "df": df,
                "schema": meta.get("schema", {}),
                "visual_config": meta.get("visual_config", {}),
                "doc_index": vectorizer,
                "tfidf_matrix": tfidf_matrix,
                "doc_chunks": chunks,
                "onboarded_at": meta.get("onboarded_at", ""),
                "row_count": meta.get("row_count", 0),
                "col_count": meta.get("col_count", 0),
                "anomalies": meta.get("anomalies", []),
                "anomaly_count": meta.get("anomaly_count", 0),
                "kpis": meta.get("kpis", []),
                "narrative": meta.get("narrative", ""),
                "questions": meta.get("questions", []),
                "capabilities": meta.get("capabilities", {}),
                "file_modified": meta.get("file_modified", ""),
                "data_filename": meta.get("data_filename", ""),
            }
            _REGISTRY[scorecard_id] = entry
            restored += 1
            log.info(f"Restored '{scorecard_id}' from disk ({meta.get('row_count', 0)} rows)")

        except Exception as e:
            log.error(f"Failed to restore '{scorecard_id}': {e}")

    log.info(f"Restored {restored} scorecards from disk")
    return restored


def refresh_from_disk(scorecard_id: str) -> bool:
    """Re-read the CSV from disk if the file has changed."""
    sc_dir = STORAGE_DIR / scorecard_id
    data_path = sc_dir / "data.csv"
    if not data_path.exists():
        return False

    if scorecard_id not in _REGISTRY:
        return False

    try:
        from backend.services.column_classifier import classify_columns
        from backend.services.visual_generator import generate_visual_config

        df = pd.read_csv(data_path)
        for col in df.columns:
            if pd.api.types.is_string_dtype(df[col]):
                df[col] = df[col].fillna("")

        schema = classify_columns(df)
        visual_config = generate_visual_config(df, schema)

        _REGISTRY[scorecard_id]["df"] = df
        _REGISTRY[scorecard_id]["schema"] = schema
        _REGISTRY[scorecard_id]["visual_config"] = visual_config
        _REGISTRY[scorecard_id]["row_count"] = len(df)
        _REGISTRY[scorecard_id]["col_count"] = len(df.columns)
        _REGISTRY[scorecard_id]["file_modified"] = datetime.utcnow().isoformat()

        persist_to_disk(scorecard_id)
        log.info(f"Refreshed '{scorecard_id}' from disk ({len(df)} rows)")
        return True
    except Exception as e:
        log.error(f"Failed to refresh '{scorecard_id}': {e}")
        return False
