"""Test pivot, aggregate, and MoM comparison endpoints."""
import requests
import json

API = "http://localhost:8000"
HEADERS = {"X-User-ID": "PG23137", "Content-Type": "application/json"}

def test_pivot_config():
    print("=== PIVOT CONFIG ===")
    r = requests.get(f"{API}/data/test-cde/pivot/config")
    d = r.json()
    print(f"  Row candidates: {d['row_candidates']}")
    print(f"  Value candidates: {d['value_candidates']}")
    print(f"  Agg functions: {d['agg_functions']}")
    assert len(d["row_candidates"]) > 0
    assert len(d["value_candidates"]) > 0
    print("  PASS")

def test_pivot():
    print("\n=== PIVOT: SUM exceptions by system ===")
    r = requests.post(f"{API}/data/test-cde/pivot",
        json={"rows": ["system"], "values": ["exceptions"], "agg_func": "sum"},
        headers=HEADERS)
    d = r.json()
    print(f"  Pivot rows: {len(d['pivot_data'])}")
    print(f"  Pivot columns: {d['pivot_columns']}")
    print(f"  Chart type: {d['chart_data']['chart_type']}")
    print(f"  Chart title: {d['chart_data']['title']}")
    for row in d["pivot_data"]:
        print(f"    {row}")
    print("  PASS")

def test_pivot_cross():
    print("\n=== PIVOT: MEAN quality_score by system × rag_status ===")
    r = requests.post(f"{API}/data/test-cde/pivot",
        json={"rows": ["system"], "columns": ["rag_status"], "values": ["quality_score"], "agg_func": "mean"},
        headers=HEADERS)
    d = r.json()
    print(f"  Pivot rows: {len(d['pivot_data'])}")
    print(f"  Columns: {d['pivot_columns']}")
    for row in d["pivot_data"]:
        print(f"    {row}")
    print("  PASS")

def test_aggregate():
    print("\n=== AGGREGATE: count by legal_entity ===")
    r = requests.post(f"{API}/data/test-cde/aggregate",
        json={"group_by": ["legal_entity"], "agg": "count"},
        headers=HEADERS)
    d = r.json()
    print(f"  Results: {d['data']}")
    print(f"  Chart: {d['chart']['chart_type']}")
    assert len(d["data"]) > 0
    print("  PASS")

def test_upload_period():
    print("\n=== UPLOAD PERIOD: 2026-01 ===")
    import pandas as pd
    # Create a "previous month" with different data
    import io
    data = {
        "rule_id": ["R001","R002","R003","R004","R005"],
        "source_system_rule_name": ["Accuracy Check","Completeness","Timeliness","Validity","Uniqueness"],
        "immutable_cde": ["Account Balance","Trade Date","Client Name","Product Type","Currency"],
        "system": ["MERIDIAN","MERIDIAN","MERIDIAN","EAGLE","EAGLE"],
        "rag_status": ["Green","Green","Green","Green","Red"],
        "exceptions": [0, 0, 0, 0, 3],
        "total_records": [1000, 1000, 1000, 1000, 1000],
        "quality_score": [100, 100, 100, 100, 97.0],
        "date": ["2026-01"]*5,
        "legal_entity": ["CGML"]*5,
    }
    df = pd.DataFrame(data)
    buf = io.BytesIO()
    df.to_csv(buf, index=False)
    buf.seek(0)

    r = requests.post(f"{API}/data/test-cde/upload-period",
        data={"period_label": "2026-01"},
        files={"data_file": ("prev.csv", buf, "text/csv")},
        headers={"X-User-ID": "PG23137"})
    d = r.json()
    print(f"  Status: {d['status']}, Rows: {d['row_count']}")
    assert d["status"] == "ok"
    print("  PASS")

def test_list_periods():
    print("\n=== LIST PERIODS ===")
    r = requests.get(f"{API}/data/test-cde/periods")
    d = r.json()
    print(f"  Periods: {len(d)}")
    for p in d:
        print(f"    - {p['period_label']}: {p['row_count']} rows")
    assert len(d) >= 1
    print("  PASS")

def test_mom_compare():
    print("\n=== MOM COMPARE: 2026-01 vs current ===")
    r = requests.post(f"{API}/data/test-cde/mom-compare",
        json={"period_a": "2026-01", "period_b": "current"},
        headers=HEADERS)
    d = r.json()
    print(f"  Period A: {d['period_a']['label']} ({d['period_a']['rows']}r)")
    print(f"  Period B: {d['period_b']['label']} ({d['period_b']['rows']}r)")
    s = d["summary"]
    print(f"  New rows: {s['new_rows']}, Removed: {s['removed_rows']}, Changed: {s['changed_rows']}")
    print(f"  Status flips: {s['total_status_flips']}")
    if d.get("rag_comparison"):
        rc = d["rag_comparison"]
        print(f"  RAG A: {rc['period_a']}")
        print(f"  RAG B: {rc['period_b']}")
    print(f"  Charts: {len(d.get('charts', []))}")
    for ch in d.get("charts", []):
        print(f"    - {ch['title']} ({ch['chart_type']})")
    if s.get("status_flips_detail"):
        for f in s["status_flips_detail"][:5]:
            print(f"    Flip: {f['key']}: {f['from']} -> {f['to']}")
    print("  PASS")


if __name__ == "__main__":
    print("B&I CDE Platform -- New Feature Tests\n")
    tests = [
        test_pivot_config,
        test_pivot,
        test_pivot_cross,
        test_aggregate,
        test_upload_period,
        test_list_periods,
        test_mom_compare,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"  FAIL: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    print(f"\n{'='*40}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    print(f"{'='*40}")
