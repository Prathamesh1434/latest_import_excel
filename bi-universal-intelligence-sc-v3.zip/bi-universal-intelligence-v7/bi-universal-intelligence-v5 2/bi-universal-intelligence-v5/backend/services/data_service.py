"""
services/data_service.py -- v7.2

Multi-sheet Excel loading, auto-detection of sheet purpose (raw vs pivot),
data validation, and KRI calculation.
"""
import re
import logging
import pandas as pd
from io import BytesIO
from typing import Tuple, Dict, Any, List, Optional

from backend.services.column_classifier import classify_columns
from backend.services.visual_generator import generate_visual_config

log = logging.getLogger("data_service")


# ============================================================
# MULTI-SHEET EXCEL LOADING
# ============================================================

def load_all_sheets(file_content: bytes, filename: str) -> Dict[str, pd.DataFrame]:
    """
    Load ALL sheets from an Excel file (or single CSV).
    Returns dict of {sheet_label: DataFrame}.
    For CSV files, returns {"raw": df}.
    """
    if filename.lower().endswith(".csv"):
        df = pd.read_csv(BytesIO(file_content))
        _fill_string_na(df)
        return {"raw": df}

    if not filename.lower().endswith((".xls", ".xlsx")):
        raise ValueError(f"Unsupported file format: {filename}")

    xls = pd.ExcelFile(BytesIO(file_content))
    sheet_names = xls.sheet_names
    log.info(f"Excel '{filename}' has {len(sheet_names)} sheets: {sheet_names}")

    raw_sheets = {}
    for name in sheet_names:
        try:
            df = pd.read_excel(xls, sheet_name=name)
            if df.empty or len(df.columns) < 2:
                log.info(f"  Skipping empty/tiny sheet '{name}'")
                continue
            _fill_string_na(df)
            raw_sheets[name] = df
        except Exception as e:
            log.warning(f"  Failed to read sheet '{name}': {e}")

    if not raw_sheets:
        raise ValueError("No valid sheets found in Excel file")

    # Classify sheets
    classified = _classify_sheets(raw_sheets)
    log.info(f"Classified sheets: {list(classified.keys())}")
    return classified


def _fill_string_na(df: pd.DataFrame):
    """Fill NA for string columns."""
    for col in df.columns:
        if pd.api.types.is_string_dtype(df[col]):
            df[col] = df[col].fillna("")


def _classify_sheets(raw_sheets: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
    """
    Auto-detect sheet purpose:
    - Sheet with most rows -> "raw" (primary data)
    - Sheets with pivot-like structure -> classify by name (solo, conso, cgme, etc.)
    - Unknown sheets kept with their original name
    """
    if len(raw_sheets) == 1:
        name = list(raw_sheets.keys())[0]
        return {"raw": raw_sheets[name]}

    # Find the primary raw data sheet (most rows)
    sorted_by_rows = sorted(raw_sheets.items(), key=lambda x: len(x[1]), reverse=True)
    primary_name, primary_df = sorted_by_rows[0]

    result = {"raw": primary_df}

    # Classify remaining sheets
    for name, df in raw_sheets.items():
        if name == primary_name:
            continue

        label = _detect_sheet_label(name, df, primary_df)
        result[label] = df

    return result


def _detect_sheet_label(sheet_name: str, df: pd.DataFrame, primary_df: pd.DataFrame) -> str:
    """
    Detect what a sheet represents by name and structure.
    Returns a label like 'pivot_solo', 'pivot_conso', 'pivot_cgme', etc.
    """
    name_lower = sheet_name.lower().strip()

    # Name-based matching (fuzzy)
    solo_patterns = ["solo", "sol", "individual", "single"]
    conso_patterns = ["conso", "consolidated", "combined", "merged", "group"]
    cgme_patterns = ["cgme", "cgm-e", "cgm_e"]
    cgml_patterns = ["cgml", "cgm-l", "cgm_l"]
    cgmfl_patterns = ["cgmfl", "cgm-fl", "cgm_fl"]
    pivot_patterns = ["pivot", "summary", "agg", "crosstab"]

    is_pivot = any(p in name_lower for p in pivot_patterns) or len(df) < len(primary_df) * 0.3

    if any(p in name_lower for p in solo_patterns):
        return "pivot_solo" if is_pivot else "solo"
    if any(p in name_lower for p in conso_patterns):
        return "pivot_conso" if is_pivot else "consolidated"
    if any(p in name_lower for p in cgme_patterns):
        return "pivot_cgme" if is_pivot else "cgme"
    if any(p in name_lower for p in cgml_patterns):
        return "pivot_cgml" if is_pivot else "cgml"
    if any(p in name_lower for p in cgmfl_patterns):
        return "pivot_cgmfl" if is_pivot else "cgmfl"

    # Structure-based: if much fewer rows than primary, treat as pivot
    if is_pivot:
        # Try to guess from column content
        return f"pivot_{_sanitize_name(sheet_name)}"

    return _sanitize_name(sheet_name)


def _sanitize_name(name: str) -> str:
    """Sanitize sheet name to a safe label."""
    return re.sub(r"[^a-z0-9_]", "_", name.lower().strip()).strip("_")[:40]


# ============================================================
# LEGACY SINGLE-SHEET LOADING (backward compat)
# ============================================================

def load_data(file_content: bytes, filename: str) -> pd.DataFrame:
    """Load CSV or Excel data into a pandas DataFrame (first sheet only)."""
    try:
        if filename.lower().endswith(".csv"):
            df = pd.read_csv(BytesIO(file_content))
        elif filename.lower().endswith((".xls", ".xlsx")):
            df = pd.read_excel(BytesIO(file_content))
        else:
            raise ValueError("Unsupported file format. Please upload CSV or Excel.")
        _fill_string_na(df)
        return df
    except Exception as e:
        raise ValueError(f"Error loading file: {e}")


# ============================================================
# DATA PROCESSING
# ============================================================

def process_scorecard_data(file_content: bytes, filename: str) -> Tuple[pd.DataFrame, Dict[str, Any], Dict[str, Any]]:
    """Loads data, detects schema, and generates visual configurations."""
    df = load_data(file_content, filename)
    schema = classify_columns(df)
    visual_config = generate_visual_config(df, schema)
    return df, schema, visual_config


def process_all_sheets(file_content: bytes, filename: str) -> Tuple[Dict[str, pd.DataFrame], pd.DataFrame, Dict[str, Any], Dict[str, Any]]:
    """
    Load all sheets, pick primary, classify columns, generate visuals.
    Returns: (all_sheets, primary_df, schema, visual_config)
    """
    all_sheets = load_all_sheets(file_content, filename)
    primary_df = all_sheets.get("raw", list(all_sheets.values())[0])
    schema = classify_columns(primary_df)
    visual_config = generate_visual_config(primary_df, schema)
    return all_sheets, primary_df, schema, visual_config


# ============================================================
# DATA VALIDATION
# ============================================================

def validate_upload(file_content: bytes, filename: str, max_size_mb: int = 50) -> Dict[str, Any]:
    """
    Run validation checks on uploaded file before onboarding.
    Returns a validation report with errors, warnings, and info.
    """
    report = {
        "valid": True,
        "errors": [],
        "warnings": [],
        "info": [],
    }

    # File size
    size_mb = len(file_content) / (1024 * 1024)
    report["info"].append(f"File size: {size_mb:.1f} MB")
    if size_mb > max_size_mb:
        report["warnings"].append(f"Large file ({size_mb:.1f} MB). Processing may be slow.")

    try:
        sheets = load_all_sheets(file_content, filename)
    except Exception as e:
        report["valid"] = False
        report["errors"].append(f"Cannot read file: {str(e)}")
        return report

    report["info"].append(f"Sheets detected: {len(sheets)} ({', '.join(sheets.keys())})")

    primary = sheets.get("raw", list(sheets.values())[0])

    # Row count
    row_count = len(primary)
    report["info"].append(f"Primary sheet: {row_count} rows, {len(primary.columns)} columns")
    if row_count == 0:
        report["errors"].append("Primary sheet has 0 rows")
        report["valid"] = False
    elif row_count > 1_000_000:
        report["warnings"].append(f"Very large dataset ({row_count:,} rows). Performance may degrade.")

    # Column count
    col_count = len(primary.columns)
    if col_count < 3:
        report["warnings"].append(f"Only {col_count} columns detected. Data may be incomplete.")
    elif col_count > 100:
        report["warnings"].append(f"{col_count} columns detected. Consider trimming unused columns.")

    # Duplicate column names
    dupes = primary.columns[primary.columns.duplicated()].tolist()
    if dupes:
        report["errors"].append(f"Duplicate column names: {dupes}")
        report["valid"] = False

    # All-null columns
    null_cols = [col for col in primary.columns if primary[col].isna().all()]
    if null_cols:
        report["warnings"].append(f"All-null columns (consider removal): {null_cols[:5]}")

    # Date format detection
    for col in primary.columns:
        if "date" in col.lower() or "month" in col.lower():
            sample = primary[col].dropna().head(5).astype(str).tolist()
            report["info"].append(f"Date column '{col}' samples: {sample}")

    # Sheet summaries
    for sheet_name, sheet_df in sheets.items():
        if sheet_name != "raw":
            report["info"].append(f"Sheet '{sheet_name}': {len(sheet_df)} rows, {len(sheet_df.columns)} columns")

    return report


# ============================================================
# KRI CALCULATION
# ============================================================

def calculate_kri(df: pd.DataFrame, schema: Dict[str, list]) -> Dict[str, Any]:
    """Calculate KRI generic function."""
    res = {}
    if schema.get("rag_status") and schema.get("identifier"):
        rag_col = schema["rag_status"][0]
        id_col = schema["identifier"][0]
        total_rules = df[id_col].nunique()
        failed_rules = df[df[rag_col].str.lower() == "red"][id_col].nunique()
        res["kri"] = failed_rules / total_rules if total_rules > 0 else 0
        res["failed"] = failed_rules
        res["total"] = total_rules
    return res
